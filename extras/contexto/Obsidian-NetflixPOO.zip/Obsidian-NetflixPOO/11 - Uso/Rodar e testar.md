---
tags: [netflix, uso, testes]
---

# Rodar e testar

*Seção 11 da documentação: Passo a passo para rodar e testar*


## 11.1 Pré-requisitos (em cada computador)

- [ ] **Java 11 ou superior** (recomendado Java 17: https://adoptium.net). Confira com `java -version`.
- [ ] **MySQL Server** instalado e **ligado** (porta 3306). Saber o usuário (normalmente `root`) e a senha definidos na instalação.
- [ ] Não precisa de Workbench, nem de JDK, nem de editar código.

## 11.2 Abrir o sistema

1. Dê dois cliques em `V2/Netflix.jar` (ou em `V2/Abrir Netflix.bat`, que mostra mensagens de erro se algo faltar).
2. Na **tela de conexão**, confira servidor `localhost`, porta `3306`, usuário `root`, digite a **senha do seu MySQL** e clique em **Conectar**.
3. Na primeira vez o sistema cria o banco `netflix` com os dados de exemplo. Os dados ficam salvos em `config.properties` e na próxima vez a tela já vem preenchida.
4. Abre o **menu principal**.

> Antes da apresentação, clique em **Restaurar dados de exemplo** para voltar ao estado inicial.

## 11.3 Roteiro de testes (na ordem do menu)

**1. Planos**
1. **Listar:** ao abrir, aparecem Basico, Padrao e Premium.
2. **Inserir:** Nome `Familia`, Valor `29,90`, Qualidade `HD`, Telas `3`, Download `Sim` → "Plano inserido com sucesso!".
3. **Atualizar:** clique na linha Familia, mude o valor para `34,90` → Atualizar.
4. **Eliminar:** selecione Familia → Eliminar → Sim.
5. **FK:** tente eliminar **Premium** (tem conta) → "Não foi possível eliminar...".

**2. Contas**
1. Coluna **Plano** mostra "3 - Premium" (INNER JOIN), não só "3".
2. **Inserir:** escolha um plano, E-mail `teste@email.com`, Senha `123` → sucesso.
3. **E-mail único:** insira o mesmo e-mail de novo → erro (UNIQUE).
4. **País:** digite `BRA` → "O país deve ter 2 letras".
5. **Combo atualiza:** insira um plano na tela 1 com a tela 2 aberta; depois de qualquer ação na tela 2 o plano novo aparece no combo.

**3. Perfis**
1. Coluna **Conta** mostra "1 - ana.silva@email.com".
2. **Inserir** com PIN vazio → sucesso. PIN `12` → "O PIN deve ter exatamente 4 dígitos."

**4. Títulos**
1. Filme com Duração `120` → sucesso. Série com Duração **vazia** → sucesso e célula vazia (NULL).
2. Ano `abc` → "deve ser um número inteiro".

**5. Histórico de Visualização (CRUD principal + JOIN)**
1. Colunas Perfil e Título mostram **"1 - Ana"** e **"1 - Stranger Things"** (INNER JOIN).
2. **Inserir:** Perfil `3 - Kids`, Título `3 - Our Planet`, Minuto `30`, Dispositivo `Tablet`.
3. **Atualizar:** clique na linha; os combos se posicionam sozinhos. Mude Minuto para `45`, Concluído `Sim`.
4. **Regra:** Última visualização antes do Início → erro.
5. **Eliminar** a linha criada.
6. **CASCADE:** em Perfis, elimine **Pedro**; volte ao Histórico: as linhas dele sumiram.

**6. Relatório** (botão **Relatório** da tela de Histórico)
1. Abre com o período 2025-01-01 até hoje: as 6 visualizações e os totais.
2. Período `2025-06-01` a `2025-06-05` → 3 linhas.
3. Perfil `1 - Ana` → só as visualizações da Ana.
4. Data final antes da inicial → erro de validação.
5. **Salvar .txt** → escolha onde salvar e abra o arquivo.

## 11.4 Resumo do que cada teste comprova

| Teste | O que prova |
|---|---|
| Conectar e o menu abrir | JDBC + criação automática do banco |
| Listar ao abrir | `SELECT` + `ResultSet` → objetos → `DefaultTableModel` |
| Inserir / Atualizar / Eliminar | `PreparedStatement` com INSERT, UPDATE e DELETE |
| "3 - Premium" na tabela de Contas | INNER JOIN conta + plano |
| Eliminar plano em uso | integridade referencial (FK) |
| E-mail repetido | restrição `UNIQUE` |
| País com 3 letras, PIN com 2 dígitos, datas trocadas | regras de negócio no Controller |
| Série sem duração | tratamento de NULL (`Integer`, `setNull`, `wasNull`) |
| Histórico com nomes | INNER JOIN com 5 tabelas (histórico, perfil, título, conta e plano); a tabela mostra também as colunas Conta e Plano |
| Eliminar perfil e o histórico sumir | `ON DELETE CASCADE` |
| Relatório por período / perfil + totais + .txt | relatório da rotina principal |

## 11.5 Problemas comuns

| Sintoma | Causa e solução |
|---|---|
| Dois cliques no jar não fazem nada | Java não instalado ou o `.jar` não está associado ao Java. Use o `Abrir Netflix.bat` para ver a mensagem |
| "Não foi possível conectar ao MySQL" | MySQL desligado (Serviços do Windows → MySQL80 → Iniciar) ou senha errada |
| Quero voltar aos dados originais | Menu → **Restaurar dados de exemplo** |
| Quero trocar a senha salva | A tela de conexão aparece sempre ao abrir; ou apague o `config.properties` |
| Erro de data | Datas: `aaaa-mm-dd`; data com hora: `aaaa-mm-dd hh:mm` |
| Mudei o código e nada mudou | Rode `Netflix/build.bat` para gerar o jar de novo |

---
⬅ [[Gerar a build]] · [[00 - Painel]] · [[Perguntas do professor]] ➡
