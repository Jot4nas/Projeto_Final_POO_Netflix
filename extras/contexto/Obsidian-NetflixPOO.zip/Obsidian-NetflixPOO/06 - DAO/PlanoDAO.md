---
tags: [netflix, codigo, dao, classe]
---

# PlanoDAO

*Seção 5.2: PlanoDAO (referência: os outros seguem o mesmo molde)* · Pasta: [[Pacote dao]]


**`inserir(Plano p)`**
- `String sql = "INSERT INTO plano (nome, descricao, valor_mensal, qualidade_maxima, telas_simultaneas, permite_download, data_criacao) VALUES (?, ?, ?, ?, ?, ?, ?)";`: 7 colunas, 7 `?` (o id o banco gera).
- `try (Connection con = ConnectionFactory.getConnection(); PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS))`: abre a conexão e prepara o comando; `RETURN_GENERATED_KEYS` pede o id gerado.
- `ps.setString(1, p.getNome())` ... `ps.setDate(7, Date.valueOf(p.getDataCriacao()))`: preenche cada `?` na ordem (`setString` aceita `null` e grava NULL; `setBoolean` vira 0/1).
- `ps.executeUpdate();`: **executa o INSERT**.
- `try (ResultSet chaves = ps.getGeneratedKeys()) { if (chaves.next()) { p.setIdPlano(chaves.getInt(1)); } }`: lê o id novo e guarda no objeto.

**`listar()`**
- `SELECT ... FROM plano ORDER BY id_plano`; `List<Plano> lista = new ArrayList<>();`
- `try (... ResultSet rs = ps.executeQuery())` e `while (rs.next()) { lista.add(montarPlano(rs)); }`.
- `return lista;` fica depois do `try`: quando roda, `rs`, `ps` e `con` já foram fechados.

**`atualizar(Plano p)`**: `UPDATE plano SET nome = ?, ... WHERE id_plano = ?`; os 7 primeiros `?` como no insert e `ps.setInt(8, p.getIdPlano())` no `WHERE`. **Sem o WHERE, todos os planos seriam alterados.**

**`eliminar(int idPlano)`**: `DELETE FROM plano WHERE id_plano = ?`. Se o plano tiver contas, o MySQL recusa (FK) e lança `SQLException`.

**`montarPlano(ResultSet rs)`** (privado): `new Plano()` e um `setX(rs.getX("coluna"))` por coluna. Evita repetir código.

---
⬅ [[Conceitos de DAO e JDBC]] · [[00 - Painel]] · [[ContaDAO]] ➡
