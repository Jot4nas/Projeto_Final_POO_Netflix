---
tags: [netflix, codigo, dao, classe]
---

# ContaDAO

*Seção 5.3: ContaDAO (mudou: listar com INNER JOIN)* · Pasta: [[Pacote dao]]


Mesma estrutura. `inserir`/`atualizar`/`eliminar` iguais à V1 (`ps.setInt(1, c.getIdPlano())` grava a FK; `setTimestamp(6, Timestamp.valueOf(...))` para a data com hora). **`listar()` agora faz JOIN**:

```sql
SELECT c.id_conta, c.id_plano, c.email, c.senha_hash, c.telefone, c.pais,
       c.data_cadastro, c.status, p.nome AS nome_plano
FROM conta c INNER JOIN plano p ON p.id_plano = c.id_plano
ORDER BY c.id_conta
```

- `c` e `p` são apelidos; `p.nome AS nome_plano` traz o nome do plano.
- `c.setNomePlano(rs.getString("nome_plano"));`: lê a coluna que veio do JOIN. A tela mostra **"3 - Premium"**.
- `eliminar` falha se a conta ainda tiver perfis (FK).

---
⬅ [[PlanoDAO]] · [[00 - Painel]] · [[PerfilDAO]] ➡
