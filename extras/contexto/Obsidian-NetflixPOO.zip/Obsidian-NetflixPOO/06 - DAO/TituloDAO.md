---
tags: [netflix, codigo, dao, classe]
---

# TituloDAO

*Seção 5.5: TituloDAO* · Pasta: [[Pacote dao]]


Igual à V1, com cuidado para `duracao_minutos` NULL:
- `preencher(ps, t)`: método auxiliar que preenche os 9 `?` comuns ao INSERT e ao UPDATE. Para a duração: `if (t.getDuracaoMinutos() == null) { ps.setNull(6, Types.INTEGER); } else { ps.setInt(6, t.getDuracaoMinutos()); }`. `setInt` não aceita `null`, por isso `setNull` informando o tipo SQL.
- `listar`: `int duracao = rs.getInt("duracao_minutos"); t.setDuracaoMinutos(rs.wasNull() ? null : duracao);`. `getInt` devolve 0 quando é NULL; `wasNull()` diz se o último valor lido era NULL.

---
⬅ [[PerfilDAO]] · [[00 - Painel]] · [[HistoricoVisualizacaoDAO]] ➡
