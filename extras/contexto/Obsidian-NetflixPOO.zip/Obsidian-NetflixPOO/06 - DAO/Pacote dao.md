---
tags: [netflix, codigo, dao]
---

# Pacote dao

*Seção 5 da documentação: Pacote dao*


DAO (Data Access Object) é a **única camada que escreve SQL**. Cada DAO cuida de uma tabela e traduz entre objetos Java e linhas do banco.

## Notas desta pasta

- [[Conceitos de DAO e JDBC]]: Conceitos que o professor vai cobrar
- [[PlanoDAO]]: PlanoDAO (referência: os outros seguem o mesmo molde)
- [[ContaDAO]]: ContaDAO (mudou: listar com INNER JOIN)
- [[PerfilDAO]]: PerfilDAO (mudou: listar com INNER JOIN)
- [[TituloDAO]]: TituloDAO
- [[HistoricoVisualizacaoDAO]]: HistoricoVisualizacaoDAO (CRUD principal + consultas do relatório)

---
⬅ [[Pacote model]] · [[00 - Painel]] · [[Conceitos de DAO e JDBC]] ➡
