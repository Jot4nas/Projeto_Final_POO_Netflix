---
tags: [leia-me]
---

# Vault do Obsidian do projeto

Notas do projeto final de POO: o sistema Netflix (Java + Swing + MySQL), explicado classe por classe.

## Como abrir
1. Instale o Obsidian (obsidian.md).
2. "Abrir pasta como vault" → escolha esta pasta `Obsidian-NetflixPOO`.
3. Comece por [[00 - Painel]] e depois [[HANDOFF_CONTEXTO]].
4. `Ctrl+G` abre o grafo.

## Como as notas são feitas
As notas das pastas numeradas são **geradas** a partir de `Projeto/DOCUMENTACAO.md` pelo script `_gerar_vault.py`.
Para mudar o conteúdo, edite o `DOCUMENTACAO.md` e rode:

```
python _gerar_vault.py
```

O script recria as pastas numeradas, o Painel e o LEIA-ME, e não mexe no `workspace.json` nem na nota HANDOFF_CONTEXTO.

## Grafo em 3D (opcional)
Configurações → Plugins da comunidade → Ativar → Procurar "3D Graph" → Instalar → Ativar. Depois, pela paleta de comandos (`Ctrl+P`), rode "3D Graph: Open 3D Graph".

Ligações: [[00 - Painel]]
