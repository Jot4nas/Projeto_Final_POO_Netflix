"""
Gera o vault do Obsidian (esta pasta) a partir de Projeto/DOCUMENTACAO.md.

Uso:  python _gerar_vault.py        (dentro da pasta do vault, Obsidian-NetflixPOO)

Organizacao (no estilo do vault do datathon):
- pastas numeradas por tema, cada uma com uma cor (no explorador e no grafo);
- 00 - Painel (mapa do vault + status), LEIA-ME e HANDOFF_CONTEXTO na raiz;
- uma nota por classe nas pastas de codigo; notas curtas de conceitos de POO;
- configuracao do Obsidian (.obsidian: tema, snippets de CSS, cores do grafo).

As notas das pastas numeradas sao GERADAS: edite o DOCUMENTACAO.md e rode o script
de novo (nao edite essas notas a mao). O script nao toca em workspace.json.
"""
import json
import re
import shutil
from pathlib import Path

VAULT = Path(__file__).resolve().parent
DOC = VAULT.parent / "DOCUMENTACAO.md"
CLAUDE_MD = VAULT.parent.parent / "CLAUDE.md"

INICIO = "00 - Painel"
HANDOFF = "HANDOFF_CONTEXTO"
DATA = "30/10/2026"

# pasta -> cor (a mesma no explorador e no grafo)
PASTAS = [
    ("01 - Proposta", "#4cc9f0"),
    ("02 - Visão geral", "#4895ef"),
    ("03 - Banco de dados", "#7b61ff"),
    ("04 - Util", "#6a4cff"),
    ("05 - Model", "#9d4edd"),
    ("06 - DAO", "#b5179e"),
    ("07 - Controller", "#f72585"),
    ("08 - View", "#ff8fab"),
    ("09 - Integração Java-MySQL", "#2ec4b6"),
    ("10 - Conceitos de POO", "#56cfe1"),
    ("11 - Uso", "#48bfe3"),
    ("12 - Apresentação", "#c77dff"),
]
PASTAS_GERADAS = [p for p, _ in PASTAS] + ["01 Projeto", "02 Código", "03 Uso", "04 Apresentação"]
VERMELHO = "#e50914"  # vermelho da Netflix: titulos e notas-chave

# numero da secao -> (pasta, nome da nota, dividir por subsecao?, tags)
SECOES = {
    "0": ("02 - Visão geral", "O que mudou da V1 para a V2", False, ["projeto"]),
    "1": ("02 - Visão geral", "Visão geral", False, ["projeto", "mvc"]),
    "2": ("03 - Banco de dados", "Banco de dados", False, ["banco", "sql"]),
    "3": ("04 - Util", "Pacote util", True, ["codigo", "util"]),
    "4": ("05 - Model", "Pacote model", False, ["codigo", "model"]),
    "5": ("06 - DAO", "Pacote dao", True, ["codigo", "dao"]),
    "6": ("07 - Controller", "Pacote controller", True, ["codigo", "controller"]),
    "7": ("08 - View", "Pacote view", True, ["codigo", "view"]),
    "8": ("09 - Integração Java-MySQL", "Integração Java-MySQL", False, ["jdbc", "banco"]),
    "9": ("10 - Conceitos de POO", "Conceitos de POO", False, ["poo"]),
    "10": ("11 - Uso", "Gerar a build", False, ["uso", "build"]),
    "11": ("11 - Uso", "Rodar e testar", False, ["uso", "testes"]),
    "12": ("12 - Apresentação", "Perguntas do professor", True, ["apresentacao"]),
    "13": ("12 - Apresentação", "Correções da revisão", False, ["revisao", "qualidade"]),
}

# subsecoes das secoes divididas -> nome da nota
SUB = {
    "3.1": "ConnectionFactory", "3.2": "CriadorBanco", "3.3": "Conversor",
    "5.1": "Conceitos de DAO e JDBC", "5.2": "PlanoDAO", "5.3": "ContaDAO", "5.4": "PerfilDAO",
    "5.5": "TituloDAO", "5.6": "HistoricoVisualizacaoDAO",
    "6.1": "PlanoController", "6.2": "Controllers de Conta, Perfil e Titulo", "6.3": "HistoricoController",
    "6.4": "RelatorioController", "6.5": "ConexaoController",
    "7.1": "Conceitos de Swing", "7.2": "Main", "7.3": "TelaConexao", "7.4": "TelaPrincipal",
    "7.5": "TelaCrud", "7.6": "Telas filhas", "7.7": "TelaRelatorio",
    "12.1": "Perguntas - Fluxo geral", "12.2": "Perguntas - Banco de dados", "12.3": "Perguntas - util",
    "12.4": "Perguntas - model", "12.5": "Perguntas - dao", "12.6": "Perguntas - controller",
    "12.7": "Perguntas - view", "12.8": "Perguntas - Mostre no código",
}

# nome de classe (entre crases no texto) -> nota para onde o link aponta
LINKS = {nome: nome for nome in SUB.values() if " " not in nome}
LINKS.update({n: "Pacote model" for n in ["Plano", "Conta", "Perfil", "Titulo", "HistoricoVisualizacao"]})
LINKS.update({n: "Controllers de Conta, Perfil e Titulo" for n in ["ContaController", "PerfilController", "TituloController"]})
LINKS.update({n: "Telas filhas" for n in ["TelaPlano", "TelaConta", "TelaPerfil", "TelaTitulo", "TelaHistorico"]})

ALIASES = {
    "Pacote model": ["Plano", "Conta", "Perfil", "Titulo", "HistoricoVisualizacao"],
    "Controllers de Conta, Perfil e Titulo": ["ContaController", "PerfilController", "TituloController"],
    "Telas filhas": ["TelaPlano", "TelaConta", "TelaPerfil", "TelaTitulo", "TelaHistorico"],
}

# Diagramas Mermaid (o Obsidian desenha sozinho) colocados logo abaixo do titulo
DIAGRAMAS = {
    "Visão geral": """```mermaid
flowchart LR
    V["View<br/>telas Swing"] --> C["Controller<br/>valida e aplica regras"]
    C --> D["DAO<br/>SQL com PreparedStatement"]
    D --> B[("MySQL")]
    M["Model<br/>Plano, Conta, Perfil..."] -.-> V & C & D
```""",
    "Banco de dados": """```mermaid
erDiagram
    PLANO ||--o{ CONTA : "id_plano"
    CONTA ||--o{ PERFIL : "id_conta"
    PERFIL ||--o{ HISTORICO_VISUALIZACAO : "id_perfil"
    TITULO ||--o{ HISTORICO_VISUALIZACAO : "id_titulo"
```""",
    "TelaCrud": """```mermaid
classDiagram
    JFrame <|-- TelaCrud
    TelaCrud <|-- TelaPlano
    TelaCrud <|-- TelaConta
    TelaCrud <|-- TelaPerfil
    TelaCrud <|-- TelaTitulo
    TelaCrud <|-- TelaHistorico
    class TelaCrud {
        <<abstract>>
        #carregarTabela()
        #inserir() String
        #atualizar(id) String
        #eliminar(id) String
        #carregarCombos()
        #definirPadroes()
    }
```""",
    "Integração Java-MySQL": """```mermaid
sequenceDiagram
    actor U as Usuário
    U->>TelaPlano: clica em Inserir
    TelaPlano->>PlanoController: inserir(textos dos campos)
    PlanoController->>PlanoController: valida e converte (Conversor)
    PlanoController->>PlanoDAO: inserir(objeto Plano)
    PlanoDAO->>MySQL: INSERT com PreparedStatement
    MySQL-->>PlanoDAO: id gerado
    PlanoDAO-->>PlanoController: ok
    PlanoController-->>TelaPlano: "Plano inserido com sucesso!"
    TelaPlano-->>U: JOptionPane + tabela recarregada
```""",
}

# ---------------------------------------------------------------------------
# Notas escritas a mao (no estilo "09 - Conceitos" do vault do datathon)
# ---------------------------------------------------------------------------
REQUISITOS = """**O que é:** o resumo do enunciado do professor (`Proposta/Trabalho Pratico POO Final.pdf`) e onde cada exigência está no nosso projeto.

> [!regra] Mínimo para entregar
> **4 CRUDs simples completos + 1 CRUD principal completo + 1 consulta com JOIN + 1 relatório da rotina principal.** Obrigatórios: Java, POO, JFrame/Swing, MySQL, JDBC, MVC, banco relacional, chaves primárias e estrangeiras. Não vale concentrar a lógica nos botões do JFrame.

## Onde está cada exigência

| Exigência da proposta | Onde está no projeto |
|---|---|
| 4 CRUDs simples (inserir, listar, alterar, excluir) | Plano, Conta, Perfil e Título: [[Telas filhas]] |
| 1 CRUD principal relacionando outras tabelas | Histórico de Visualização (FKs para Perfil e Título): [[HistoricoVisualizacaoDAO]], [[HistoricoController]] |
| Consulta com JOIN mostrando nomes, não códigos | `listarComNomes()` em [[HistoricoVisualizacaoDAO]] (3 tabelas), além do JOIN em [[ContaDAO]] e [[PerfilDAO]] |
| Relatório da rotina principal | [[TelaRelatorio]] + [[RelatorioController]]: visualizações por período e por perfil, com totais e **Salvar .txt** |
| Java + POO | [[Conceitos de POO]]: herança (`TelaCrud`), polimorfismo, classe abstrata, encapsulamento, sobrecarga e sobrescrita |
| MVC | pacotes `model`, `view`, `controller` (+ `dao` para o SQL): [[Visão geral]] |
| MySQL + JDBC, PK, FK, dados de demonstração, script SQL | [[Banco de dados]] e [[Integração Java-MySQL]] (`Projeto/Netflix/sql/netflix.sql`) |

## Nota (2,5 pontos no total)

| Parte | Critério | Valor |
|---|---|---|
| **A) Sistema** (1,5) | 4 CRUDs simples funcionando | 0,40 |
| | CRUD da rotina principal | 0,40 |
| | Banco MySQL, relacionamentos e JOIN | 0,25 |
| | POO e padrão MVC | 0,20 |
| | Relatório da rotina principal | 0,15 |
| | Organização e funcionamento geral | 0,10 |
| **B) Apresentação individual** (1,0) | 2 perguntas sobre o sistema, **0,5 cada** | 1,00 |

> [!decisao] A apresentação não é um extra
> Os 1,0 ponto da apresentação já estão dentro dos 2,5. Quem não responde às duas perguntas perde até 1,0 mesmo com o sistema perfeito. Por isso **todo membro do grupo** precisa dominar o código: veja [[Perguntas do professor]].

O professor quer ver o fluxo completo: **Cadastro → Relacionamento → Rotina principal → Consulta com JOIN → Relatório.**

Ligações: [[Visão geral]] · [[Rodar e testar]] · [[Perguntas do professor]]"""

CONCEITOS = {
    "Classe e objeto": (
        "A **classe** é o gabarito (atributos e métodos). O **objeto** é uma instância criada com `new`, com identidade, estado (valores dos atributos) e comportamento (métodos).",
        "`Plano`, `Conta`, `Perfil`, `Titulo` e `HistoricoVisualizacao` são classes; cada linha do banco vira um objeto. `new Plano()` no `PlanoDAO`, `new PlanoController()` na `TelaPlano`, `new TelaPlano()` no menu.",
        ["Encapsulamento", "Mensagem", "Pacote model"]),
    "Encapsulamento": (
        "Esconder os atributos (`private`) e deixar que só os métodos do próprio objeto os leiam ou alterem (`getX`/`setX`).",
        "Todos os atributos dos models são `private`, com getters e setters. A validação fica concentrada no `Conversor` e nos controllers.",
        ["Visibilidade", "Classe e objeto", "Pacote model"]),
    "Visibilidade": (
        "`private`: só a classe; `protected`: a classe e as subclasses; `public`: todos (a interface do objeto).",
        "Atributos `private` nos models; `protected` em `TelaCrud` (`modelo`, `tabela`, `adicionarCampo`, `valor`) para as telas filhas; métodos `public` nos DAOs e controllers; auxiliares `private` como `montar(...)`.",
        ["Encapsulamento", "Herança", "TelaCrud"]),
    "Herança": (
        "Uma subclasse herda atributos e métodos da superclasse (relação \"é-um\"). Java só permite herança simples de classes.",
        "`TelaPlano extends TelaCrud extends JFrame`. `super(titulo, colunas)` no construtor da filha chama o da `TelaCrud`, que chama `super(titulo)` do `JFrame`. `TelaPrincipal`, `TelaConexao` e `TelaRelatorio` herdam direto de `JFrame`.",
        ["Polimorfismo", "Classe abstrata", "TelaCrud"]),
    "Polimorfismo": (
        "Mesma mensagem, comportamentos diferentes conforme a classe do objeto; e tratar objetos específicos como da classe genérica (como o `ControleDePonto` dos slides, que recebe um `Funcionario`).",
        "(1) `TelaCrud` chama `inserir()`, `atualizar(id)`, `eliminar(id)` e `carregarTabela()` sem saber qual tela está aberta. (2) O mapa `campos` guarda `JTextField` e `JComboBox` como `JComponent`; `valor()` usa `instanceof JComboBox`. (3) `adicionarCampo(String, JComponent)` aceita qualquer componente.",
        ["Late binding", "Sobrescrita e sobrecarga", "Classe abstrata", "TelaCrud"]),
    "Classe abstrata": (
        "Classe que não se instancia e pode ter métodos sem corpo, que as filhas são obrigadas a implementar.",
        "`abstract class TelaCrud` tem 4 métodos abstratos: `carregarTabela()`, `inserir()`, `atualizar(String id)` e `eliminar(String id)`. É o padrão Template Method: a base monta o fluxo e as filhas preenchem os \"buracos\".",
        ["Herança", "Polimorfismo", "TelaCrud"]),
    "Sobrescrita e sobrecarga": (
        "**Sobrescrita** (`@Override`): a subclasse redefine um método herdado. **Sobrecarga**: mesmo nome com parâmetros diferentes na mesma classe (como `somar()` e `somar(double, double)` na aula).",
        "Sobrescrita: `carregarTabela()`, `carregarCombos()` e `definirPadroes()` nas telas, `isCellEditable` no modelo da tabela, `toString()` nos models. Sobrecarga: construtor vazio e completo de cada model; `definirValor(String, String)` e `definirValor(JComponent, String)` em `TelaCrud`.",
        ["Polimorfismo", "Herança", "Telas filhas"]),
    "Late binding": (
        "Acoplamento tardio: o método que responde a uma mensagem é escolhido em **tempo de execução**, pela classe real do objeto.",
        "A chamada `inserir()` dentro de `TelaCrud` só é resolvida quando a tela está rodando: se a `TelaPlano` está aberta, executa a versão dela.",
        ["Polimorfismo", "Classe abstrata", "TelaCrud"]),
    "Mensagem": (
        "Um objeto (emissor) pede um serviço a outro (receptor) chamando um método. A mensagem tem seletor (nome) e parâmetros; quem sabe **como** fazer é o receptor.",
        "`controller.inserir(nome, ...)`: a tela envia, o `PlanoController` sabe como validar e gravar. O mesmo vale do controller para o DAO: `dao.inserir(plano)`.",
        ["Classe e objeto", "Pacote controller", "PlanoController"]),
    "Associação e agregação": (
        "**Associação** liga classes com multiplicidade (1, 0..*). **Agregação** é \"tem-um\": uma classe contém outra como parte.",
        "Plano 1..* Conta, Conta 1..* Perfil, Perfil *..* Título (resolvido pela classe associativa `HistoricoVisualizacao`). No código a ligação é a FK. Agregação: `TelaPlano` tem um `PlanoController`, que tem um `PlanoDAO`.",
        ["Banco de dados", "Pacote model", "HistoricoVisualizacaoDAO"]),
    "Abstração": (
        "Ficar só com o essencial para a aplicação e ignorar o resto.",
        "A Netflix real tem 13 tabelas no modelo do grupo; o sistema usa o recorte de 5 entidades com só os atributos de que precisa.",
        ["Classe e objeto", "Banco de dados", "Visão geral"]),
}


def separar(linhas, prefixo):
    """Divide as linhas em blocos que comecam com o titulo `prefixo` (ignora blocos de codigo)."""
    blocos, atual, dentro_codigo = [], [], False
    for linha in linhas:
        if linha.startswith("```"):
            dentro_codigo = not dentro_codigo
        if not dentro_codigo and linha.startswith(prefixo):
            blocos.append(atual)
            atual = []
        atual.append(linha)
    blocos.append(atual)
    return blocos[0], blocos[1:]  # (texto antes do 1o titulo, blocos)


def numero(titulo):
    m = re.match(r"#+\s+(\d+(?:\.\d+)?)", titulo)
    return m.group(1) if m else None


def texto_titulo(titulo):
    """'### 3.1 `ConnectionFactory` (mudou na V2)' -> 'ConnectionFactory (mudou na V2)'"""
    t = re.sub(r"^#+\s+\d+(\.\d+)?\.?\s*", "", titulo).strip()
    return t.replace("`", "")


def nota_da_secao(num):
    if num in SUB:
        return SUB[num]
    base = num.split(".")[0]
    return SECOES[base][1] if base in SECOES else None


def link(nota, texto, em_tabela):
    if nota == texto:
        return f"[[{nota}]]"
    return f"[[{nota}\\|{texto}]]" if em_tabela else f"[[{nota}|{texto}]]"


def ligar(linhas, nota_atual):
    """Troca `Classe` por [[Classe]] e 'secao 3.2' por link, fora dos blocos de codigo."""
    saida, dentro_codigo = [], False
    for linha in linhas:
        if linha.startswith("```"):
            dentro_codigo = not dentro_codigo
            saida.append(linha)
            continue
        if dentro_codigo:
            saida.append(linha)
            continue
        em_tabela = linha.lstrip().startswith("|")

        def trocar_classe(m):
            nome, resto = m.group(1), m.group(2) or ""
            nota = LINKS.get(nome)
            if not nota or nota == nota_atual:
                return m.group(0)
            return link(nota, nome, em_tabela) + (f"`{resto}`" if resto else "")

        def trocar_secao(m):
            nota = nota_da_secao(m.group(2))
            if not nota or nota == nota_atual:
                return m.group(0)
            return link(nota, m.group(1) + m.group(2), em_tabela)

        linha = re.sub(r"`([A-Za-z]+)(\.[^`]*)?`", trocar_classe, linha)
        linha = re.sub(r"(seção )(\d+(?:\.\d+)?)", trocar_secao, linha)
        linha = re.sub(r"\[([^\]]+)\]\(#[^)]*\)", r"\1", linha)  # links internos do .md original
        saida.append(linha)
    return saida


def subir_titulos(linhas, niveis):
    """Diminui o nivel dos titulos (ex.: ### -> ##) fora dos blocos de codigo."""
    saida, dentro_codigo = [], False
    for linha in linhas:
        if linha.startswith("```"):
            dentro_codigo = not dentro_codigo
        if not dentro_codigo and re.match(r"#{2,6} ", linha):
            linha = linha[niveis:]
        saida.append(linha)
    return saida


def limpar_fim(linhas):
    while linhas and linhas[-1].strip() in ("", "---"):
        linhas.pop()
    return linhas


notas = []  # (pasta, nome, tags, corpo, contexto) na ordem de leitura


def adicionar(pasta, nome, tags, corpo, contexto=""):
    notas.append((pasta, nome, tags, corpo, contexto))


# ---------- le a documentacao e monta as notas ----------
texto = DOC.read_text(encoding="utf-8").replace("\r\n", "\n")
_, secoes = separar(texto.split("\n"), "## ")

for bloco in secoes:
    num = numero(bloco[0])
    if num not in SECOES:  # Sumario: o Painel substitui
        continue
    pasta, nome, dividir, tags = SECOES[num]
    corpo = limpar_fim(bloco[1:])
    subtitulo = f"*Seção {num} da documentação: {texto_titulo(bloco[0])}*"

    if not dividir:
        adicionar(pasta, nome, tags, ligar(subir_titulos(corpo, 1), nome), subtitulo)
        continue

    intro, subs = separar(corpo, "### ")
    lista = []
    for sub in subs:
        sub_num = numero(sub[0])
        lista.append(f"- [[{SUB[sub_num]}]]: {texto_titulo(sub[0])}")
    hub = limpar_fim(intro) + ["", "## Notas desta pasta", ""] + lista
    adicionar(pasta, nome, tags, ligar(hub, nome), subtitulo)

    for sub in subs:
        sub_num = numero(sub[0])
        sub_nome = SUB[sub_num]
        contexto = f"*Seção {sub_num}: {texto_titulo(sub[0])}* · Pasta: [[{nome}]]"
        corpo_sub = ligar(subir_titulos(limpar_fim(sub[1:]), 2), sub_nome)
        eh_classe = sub_nome[0].isupper() and " " not in sub_nome
        adicionar(pasta, sub_nome, tags + ["classe"] if eh_classe else tags, corpo_sub, contexto)

# nota escrita a mao: requisitos da proposta (primeira pasta)
adicionar("01 - Proposta", "Requisitos da proposta", ["proposta", "requisitos"],
          ligar(REQUISITOS.split("\n"), "Requisitos da proposta"), f"*Resumo do enunciado do professor*")

# ordena pela pasta (01, 02, ...), mantendo a ordem de leitura dentro de cada pasta
ordem_pastas = {p: i for i, (p, _) in enumerate(PASTAS)}
notas.sort(key=lambda n: ordem_pastas[n[0]])

# ---------- limpa as notas geradas antes ----------
for pasta in PASTAS_GERADAS:
    shutil.rmtree(VAULT / pasta, ignore_errors=True)
for arquivo in [INICIO, "00 Início", "CLAUDE - contexto da sessão"]:
    (VAULT / f"{arquivo}.md").unlink(missing_ok=True)

# ---------- escreve as notas ----------
ordem = [INICIO] + [n[1] for n in notas]


def navegacao(nome):
    i = ordem.index(nome)
    anterior = f"[[{ordem[i - 1]}]]" if i > 0 else ""
    proxima = f"[[{ordem[i + 1]}]]" if i + 1 < len(ordem) else ""
    return " · ".join(p for p in [f"⬅ {anterior}" if anterior else "", f"[[{INICIO}]]",
                                   f"{proxima} ➡" if proxima else ""] if p)


def escrever(pasta, nome, tags, corpo, contexto, nav=True, titulo=None):
    frente = ["---", f"tags: [{', '.join(tags)}]"]
    if nome in ALIASES:
        frente.append(f"aliases: [{', '.join(ALIASES[nome])}]")
    frente.append("---")

    partes = frente + ["", f"# {titulo or nome}", ""]
    if contexto:
        partes += [contexto, ""]
    if nome in DIAGRAMAS:
        partes += [DIAGRAMAS[nome], ""]
    partes += corpo + [""]
    if nav:
        partes += ["---", navegacao(nome), ""]

    destino = VAULT / pasta / f"{nome}.md" if pasta else VAULT / f"{nome}.md"
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text("\n".join(partes), encoding="utf-8")


for pasta, nome, tags, corpo, contexto in notas:
    escrever(pasta, nome, ["netflix"] + tags, corpo, contexto)

# notas de conceitos (curtas, com "Ligações" no fim)
for nome, (o_que_e, onde, ligacoes) in CONCEITOS.items():
    corpo = ligar([f"**O que é:** {o_que_e}", "", f"**Onde está no projeto:** {onde}", "",
                   "Ligações: " + " · ".join(f"[[{l}]]" for l in ligacoes + ["Conceitos de POO"])], nome)
    escrever("10 - Conceitos de POO", nome, ["netflix", "conceito", "poo"], corpo, "", nav=False)

# ---------- 00 - Painel ----------
por_pasta = {}
for pasta, nome, _, _, _ in notas:
    por_pasta.setdefault(pasta, []).append(nome)
por_pasta["10 - Conceitos de POO"] = por_pasta.get("10 - Conceitos de POO", []) + list(CONCEITOS)

mapa = []
for pasta, _ in PASTAS:
    nomes = por_pasta.get(pasta, [])
    mapa.append(f"- **{pasta}:** " + ", ".join(f"[[{n}]]" for n in nomes))

painel = [
    "> [!tip] Comece por aqui",
    "> Novo no projeto? Leia [[Visão geral]] e [[Requisitos da proposta]]. Para continuar em outro chat do Claude: [[" + HANDOFF + "]].",
    "> **Antes da apresentação:** [[Rodar e testar]] e [[Perguntas do professor]].",
    "",
    "> [!codigo] O caminho de um clique",
    "> [[TelaCrud]] → [[PlanoController]] → [[PlanoDAO]] → [[ConnectionFactory]] → MySQL. Rotina principal: [[HistoricoVisualizacaoDAO]] (INNER JOIN), [[HistoricoController]] e [[Telas filhas|TelaHistorico]]. Relatório: [[RelatorioController]] e [[TelaRelatorio]].",
    "",
    "> [!fonte] Tecnologias",
    "> Java 11+ · Swing (`JFrame`, `JTable`, `DefaultTableModel`) · JDBC com `PreparedStatement` · MySQL 8 · MVC com DAO. Driver: `mysql-connector-j-9.3.0` (já dentro do `Netflix.jar`).",
    "",
    "> [!decisao] O que mudou em 30/10/2026",
    "> Pasta `V2` virou `Projeto` no GitHub · descrição do plano gerada automaticamente (`PlanoController.gerarDescricao`) · `Netflix.jar` refeito · sistema testado contra um MySQL de verdade (79 verificações automáticas passaram).",
    "",
    "> [!warning] Ainda falta",
    "> Abrir o `Netflix.jar` e testar a interface com a senha do MySQL de cada computador. Treinar as perguntas: cada aluno responde 2 (0,5 ponto cada).",
    "",
    "> [!info] Datas e links",
    "> [Repositório no GitHub](https://github.com/lebedeff-dev/Projeto_Final_POO) · Proposta: [[Requisitos da proposta]]",
    "",
    "## Mapa do vault",
    *mapa,
    "- **Raiz:** [[LEIA-ME]], [[" + HANDOFF + "]]",
    "",
    "Para abrir o grafo, use `Ctrl+G`. As cores separam as pastas.",
    "",
    "## Roteiro de estudo para a apresentação",
    "",
    "1. [[Visão geral]]: o que o sistema faz e como o MVC está dividido.",
    "2. [[Banco de dados]]: tabelas, PK, FK e o INNER JOIN.",
    "3. Siga o clique: [[TelaCrud]] → [[PlanoController]] → [[PlanoDAO]] → [[ConnectionFactory]].",
    "4. Rotina principal e relatório: [[HistoricoVisualizacaoDAO]], [[HistoricoController]], [[RelatorioController]], [[TelaRelatorio]].",
    "5. [[Integração Java-MySQL]]: o que o professor mais cobra.",
    "6. [[Conceitos de POO]] e [[Perguntas do professor]].",
    "",
    "## Status",
    "- [x] 4 CRUDs simples completos (Plano, Conta, Perfil, Título)",
    "- [x] CRUD principal completo (Histórico de Visualização)",
    "- [x] Consulta com INNER JOIN mostrando nomes",
    "- [x] Relatório da rotina principal (por período e por perfil, com .txt)",
    "- [x] Banco MySQL com PK, FK, dados de exemplo e script SQL",
    "- [x] Tela de conexão e banco criado automaticamente",
    "- [x] `Netflix.jar` pronto e código no GitHub",
    "- [x] Documentação completa e este vault",
    "- [x] Testes automáticos contra MySQL (conexão, CRUDs, regras, JOIN, relatório)",
    "- [ ] Testar a interface (cliques) no computador da apresentação",
    "- [ ] Todos do grupo treinarem as [[Perguntas do professor|perguntas]]",
]
painel = ligar(painel, INICIO)
escrever("", INICIO, ["painel", "netflix"], painel, "", nav=False, titulo="🏠 Netflix POO: sistema de gerenciamento")

# ---------- LEIA-ME ----------
leia_me = [
    "Notas do projeto final de POO: o sistema Netflix (Java + Swing + MySQL), explicado classe por classe.",
    "",
    "## Como abrir",
    "1. Instale o Obsidian (obsidian.md).",
    "2. \"Abrir pasta como vault\" → escolha esta pasta `Obsidian-NetflixPOO`.",
    "3. Comece por [[" + INICIO + "]] e depois [[" + HANDOFF + "]].",
    "4. `Ctrl+G` abre o grafo.",
    "",
    "## Como as notas são feitas",
    "As notas das pastas numeradas são **geradas** a partir de `Projeto/DOCUMENTACAO.md` pelo script `_gerar_vault.py`.",
    "Para mudar o conteúdo, edite o `DOCUMENTACAO.md` e rode:",
    "",
    "```",
    "python _gerar_vault.py",
    "```",
    "",
    "O script recria as pastas numeradas, o Painel e o LEIA-ME, e não mexe no `workspace.json` nem na nota HANDOFF_CONTEXTO.",
    "",
    "## Grafo em 3D (opcional)",
    "Configurações → Plugins da comunidade → Ativar → Procurar \"3D Graph\" → Instalar → Ativar. Depois, pela paleta de comandos (`Ctrl+P`), rode \"3D Graph: Open 3D Graph\".",
    "",
    "Ligações: [[" + INICIO + "]]",
]
escrever("", "LEIA-ME", ["leia-me"], ligar(leia_me, "LEIA-ME"), "", nav=False, titulo="Vault do Obsidian do projeto")

# ---------- HANDOFF_CONTEXTO (copia do CLAUDE.md; nunca apaga o que ja existe) ----------
destino_handoff = VAULT / f"{HANDOFF}.md"
if CLAUDE_MD.exists():
    claude = CLAUDE_MD.read_text(encoding="utf-8").replace("\r\n", "\n")
    destino_handoff.write_text(
        "---\ntags: [netflix, handoff, contexto]\n---\n\n"
        "> Cópia do `CLAUDE.md` da raiz do projeto (o original não vai para o Git).\n"
        "> Para continuar em outro chat: anexe ou cole esta nota no começo da conversa.\n\n"
        + claude.strip() + f"\n\n---\n[[{INICIO}]]\n", encoding="utf-8")
elif not destino_handoff.exists():
    destino_handoff.write_text(f"---\ntags: [netflix, handoff]\n---\n\n(CLAUDE.md não encontrado)\n\n[[{INICIO}]]\n",
                               encoding="utf-8")

# ---------- configuracao do Obsidian (.obsidian) ----------
OBS = VAULT / ".obsidian"
(OBS / "snippets").mkdir(parents=True, exist_ok=True)


def gravar_json(nome, dados):
    (OBS / nome).write_text(json.dumps(dados, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


gravar_json("app.json", {})
gravar_json("appearance.json", {"theme": "obsidian", "enabledCssSnippets": ["cerebro-grafo", "cores-do-projeto"]})
gravar_json("core-plugins.json", {
    "file-explorer": True, "global-search": True, "switcher": True, "graph": True, "backlink": True,
    "canvas": True, "outgoing-link": True, "tag-pane": True, "properties": False, "page-preview": True,
    "daily-notes": True, "templates": True, "note-composer": True, "command-palette": True,
    "slash-command": False, "editor-status": True, "bookmarks": True, "markdown-importer": False,
    "zk-prefixer": False, "random-note": False, "outline": True, "word-count": True, "slides": False,
    "audio-recorder": False, "workspaces": False, "file-recovery": True, "publish": False, "sync": False,
    "footnotes": False, "bases": True, "webviewer": False})


def rgb(hex_):
    return int(hex_.lstrip("#"), 16)


grupos = [{"query": f'path:"{INICIO}" OR path:"LEIA-ME" OR path:"{HANDOFF}"', "color": {"a": 1, "rgb": rgb(VERMELHO)}}]
grupos += [{"query": f'path:"{p}"', "color": {"a": 1, "rgb": rgb(c)}} for p, c in PASTAS]
gravar_json("graph.json", {
    "collapse-filter": True, "search": "", "showTags": False, "showAttachments": False,
    "hideUnresolved": True, "showOrphans": True, "collapse-color-groups": False, "colorGroups": grupos,
    "collapse-display": True, "showArrow": False, "textFadeMultiplier": -1.5, "nodeSizeMultiplier": 1.35,
    "lineSizeMultiplier": 0.45, "collapse-forces": True, "centerStrength": 0.62, "repelStrength": 13,
    "linkStrength": 0.85, "linkDistance": 110, "scale": 0.63, "close": False})

CEREBRO = """/* Grafo com cara de cérebro: fundo escuro com brilho no centro, sinapses suaves. */
.workspace-leaf-content[data-type="graph"] .view-content,
.workspace-leaf-content[data-type="localgraph"] .view-content {
  background: radial-gradient(circle at 50% 45%, #1b1440 0%, #0d0b1f 45%, #050510 100%);
}
.graph-view.color-fill { color: #9d8cff; }
.graph-view.color-fill-focused { color: #ffd60a; }
.graph-view.color-fill-highlight { color: #ff4d9d; }
.graph-view.color-circle { color: #ffffff; }
.graph-view.color-line { color: rgba(140, 160, 255, 0.28); }
.graph-view.color-line-highlight { color: #ffd60a; }
.graph-view.color-text { color: #e8e6ff; }
.workspace-leaf-content[data-type="graph"] canvas {
  filter: drop-shadow(0 0 3px rgba(130, 120, 255, 0.55)) drop-shadow(0 0 10px rgba(255, 77, 157, 0.18));
}
"""
(OBS / "snippets" / "cerebro-grafo.css").write_text(CEREBRO, encoding="utf-8")

css = ["/* Cores do projeto: cada pasta tem a mesma cor no explorador e no grafo.",
       "   Gerado por _gerar_vault.py (as cores ficam na lista PASTAS do script). */", "",
       ":root {", f"  --nf-vermelho: {VERMELHO};", "  --nf-azul: #465eff;"]
css += [f"  --c{i + 1:02d}: {c};" for i, (_, c) in enumerate(PASTAS)]
css += ["}", "", "/* ---------- Explorador: uma cor por pasta ---------- */",
        ".nav-folder-title { border-left: 3px solid transparent; border-radius: 4px; }"]
for i, (p, _) in enumerate(PASTAS):
    css.append(f'.nav-folder-title[data-path$="{p}"] {{ --pasta: var(--c{i + 1:02d}); '
               f'border-left-color: var(--pasta); background: color-mix(in srgb, var(--pasta) 10%, transparent); '
               f'font-weight: 600; }}')
    css.append(f'.nav-folder-title[data-path$="{p}"] .nav-folder-title-content::before {{ content: "●  "; color: var(--pasta); }}')
css += ["", "/* Notas-chave na raiz em vermelho Netflix */",
        f'.nav-file-title[data-path$="{INICIO}.md"], .nav-file-title[data-path$="{HANDOFF}.md"], '
        '.nav-file-title[data-path$="LEIA-ME.md"] {',
        "  color: var(--nf-vermelho); font-weight: 700;", "}", "",
        "/* ---------- Títulos ---------- */",
        ".markdown-rendered h1, .cm-header-1 {",
        "  color: var(--nf-vermelho);",
        "  border-bottom: 2px solid color-mix(in srgb, var(--nf-vermelho) 50%, transparent);",
        "  padding-bottom: .2em;", "}",
        ".markdown-rendered h2, .cm-header-2 { color: #7ea1ff; }",
        ".theme-light .markdown-rendered h1, .theme-light .cm-header-1 { color: #b20710; }",
        ".theme-light .markdown-rendered h2, .theme-light .cm-header-2 { color: #3557e0; }",
        ".markdown-rendered h3, .cm-header-3 { color: #2ec4b6; }", "",
        "/* ---------- Tabelas ---------- */",
        ".markdown-rendered table { border-radius: 8px; overflow: hidden; }",
        ".markdown-rendered thead th {",
        "  background: color-mix(in srgb, var(--nf-azul) 28%, transparent);",
        "  border-bottom: 2px solid var(--nf-vermelho);", "}",
        ".markdown-rendered tbody tr:nth-child(even) { background: color-mix(in srgb, var(--nf-azul) 7%, transparent); }", "",
        "/* ---------- Tags como pílulas ---------- */",
        "a.tag { border-radius: 999px; padding: 1px 8px;",
        "  background: color-mix(in srgb, var(--nf-azul) 22%, transparent); color: var(--text-normal); }", "",
        "/* ---------- Callouts do projeto ---------- */",
        "/* Uso:  > [!regra]  |  > [!metrica]  |  > [!codigo]  |  > [!fonte]  |  > [!bug]  |  > [!decisao] */",
        '.callout[data-callout="regra"]   { --callout-color: 229, 9, 20;    --callout-icon: lucide-shield-check; }',
        '.callout[data-callout="metrica"] { --callout-color: 6, 214, 160;   --callout-icon: lucide-bar-chart-3; }',
        '.callout[data-callout="codigo"]  { --callout-color: 106, 76, 255;  --callout-icon: lucide-code-2; }',
        '.callout[data-callout="fonte"]   { --callout-color: 72, 191, 227;  --callout-icon: lucide-book-open; }',
        '.callout[data-callout="bug"]     { --callout-color: 239, 71, 111;  --callout-icon: lucide-bug; }',
        '.callout[data-callout="decisao"] { --callout-color: 247, 37, 133;  --callout-icon: lucide-git-branch; }',
        ".callout { border-radius: 10px; }", ""]
(OBS / "snippets" / "cores-do-projeto.css").write_text("\n".join(css), encoding="utf-8")

total = len(notas) + len(CONCEITOS) + 3
print(f"{total} notas geradas em {VAULT}")
