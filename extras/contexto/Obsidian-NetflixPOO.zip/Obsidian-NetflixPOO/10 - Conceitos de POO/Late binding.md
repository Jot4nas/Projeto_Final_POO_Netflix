---
tags: [netflix, conceito, poo]
---

# Late binding

**O que é:** Acoplamento tardio: o método que responde a uma mensagem é escolhido em **tempo de execução**, pela classe real do objeto.

**Onde está no projeto:** A chamada `inserir()` dentro de [[TelaCrud]] só é resolvida quando a tela está rodando: se a [[Telas filhas|TelaPlano]] está aberta, executa a versão dela.

Ligações: [[Polimorfismo]] · [[Classe abstrata]] · [[TelaCrud]] · [[Conceitos de POO]]
