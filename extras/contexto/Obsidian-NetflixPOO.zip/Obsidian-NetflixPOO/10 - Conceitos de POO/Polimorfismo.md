---
tags: [netflix, conceito, poo]
---

# Polimorfismo

**O que é:** Mesma mensagem, comportamentos diferentes conforme a classe do objeto; e tratar objetos específicos como da classe genérica (como o `ControleDePonto` dos slides, que recebe um `Funcionario`).

**Onde está no projeto:** (1) [[TelaCrud]] chama `inserir()`, `atualizar(id)`, `eliminar(id)` e `carregarTabela()` sem saber qual tela está aberta. (2) O mapa `campos` guarda `JTextField` e `JComboBox` como `JComponent`; `valor()` usa `instanceof JComboBox`. (3) `adicionarCampo(String, JComponent)` aceita qualquer componente.

Ligações: [[Late binding]] · [[Sobrescrita e sobrecarga]] · [[Classe abstrata]] · [[TelaCrud]] · [[Conceitos de POO]]
