---
tags: [netflix, conceito, poo]
---

# Classe e objeto

**O que é:** A **classe** é o gabarito (atributos e métodos). O **objeto** é uma instância criada com `new`, com identidade, estado (valores dos atributos) e comportamento (métodos).

**Onde está no projeto:** [[Pacote model|Plano]], [[Pacote model|Conta]], [[Pacote model|Perfil]], [[Pacote model|Titulo]] e [[Pacote model|HistoricoVisualizacao]] são classes; cada linha do banco vira um objeto. `new Plano()` no [[PlanoDAO]], `new PlanoController()` na [[Telas filhas|TelaPlano]], `new TelaPlano()` no menu.

Ligações: [[Encapsulamento]] · [[Mensagem]] · [[Pacote model]] · [[Conceitos de POO]]
