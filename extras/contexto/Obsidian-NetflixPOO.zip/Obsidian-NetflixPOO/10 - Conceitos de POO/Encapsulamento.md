---
tags: [netflix, conceito, poo]
---

# Encapsulamento

**O que é:** Esconder os atributos (`private`) e deixar que só os métodos do próprio objeto os leiam ou alterem (`getX`/`setX`).

**Onde está no projeto:** Todos os atributos dos models são `private`, com getters e setters. A validação fica concentrada no [[Conversor]] e nos controllers.

Ligações: [[Visibilidade]] · [[Classe e objeto]] · [[Pacote model]] · [[Conceitos de POO]]
