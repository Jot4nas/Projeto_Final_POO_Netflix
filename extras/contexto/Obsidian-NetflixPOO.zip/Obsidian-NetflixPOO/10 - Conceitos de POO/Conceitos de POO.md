---
tags: [netflix, poo]
---

# Conceitos de POO

*Seção 9 da documentação: Conceitos de POO (dos slides do professor) aplicados ao projeto*


## 9.1 Mapa conceito → código

| Conceito | Definição do curso | Onde aparece |
|---|---|---|
| **Abstração** | ficar só com o essencial | a Netflix real reduzida a 5 entidades com os atributos que o sistema usa |
| **Objeto** | identidade, estado, comportamento | `Plano p = new Plano(...)`: referência/idPlano, valores dos atributos, métodos |
| **Classe** | "gabarito" de objetos | [[Pacote model\|Plano]], [[Pacote model\|Conta]], [[Pacote model\|Perfil]], [[Pacote model\|Titulo]], [[Pacote model\|HistoricoVisualizacao]] |
| **Instanciação** | `new` cria um objeto | `new Plano()` no DAO, `new PlanoController()` na tela, `new TelaPlano()` no menu |
| **Mensagem** | um objeto pede um serviço a outro | `controller.inserir(nome, ...)`: a tela pede, o Controller sabe fazer |
| **Visibilidade** | private / protected / public | atributos `private` nos models; `protected` em [[TelaCrud]] (`modelo`, `tabela`, `adicionarCampo`) |
| **Encapsulamento** | atributos só mudam pelos métodos | atributos `private` + `getX`/`setX` |
| **Herança** | subclasse herda (é-um) | `TelaPlano extends TelaCrud extends JFrame` |
| **Generalização / especialização** | a superclasse concentra o comum | [[TelaCrud]] é o geral; cada tela especializa com seus campos |
| **Polimorfismo** | mesma mensagem, comportamentos diferentes | [[TelaCrud]] chama `inserir()` e roda a versão da tela aberta (9.2) |
| **Late binding** | método decidido em tempo de execução | a chamada `inserir()` em [[TelaCrud]] só é resolvida quando a tela roda |
| **Classe abstrata** | não se instancia; obriga as filhas a implementar | `abstract class TelaCrud` com 4 métodos abstratos |
| **Sobrescrita (@Override)** | a subclasse redefine um método herdado | `carregarTabela()`, `carregarCombos()`, `definirPadroes()` nas telas; `isCellEditable` |
| **Sobrecarga** | mesmo nome, parâmetros diferentes | construtores vazio e completo dos models; `definirValor(String, String)` e `definirValor(JComponent, String)` |
| **Associação e multiplicidade** | ligação com cardinalidade | Plano 1..* Conta; Conta 1..* Perfil; Perfil *..* Título via [[Pacote model\|HistoricoVisualizacao]] |
| **Agregação ("tem-um")** | uma classe tem outra como parte | [[Telas filhas\|TelaPlano]] tem um [[PlanoController]], que tem um [[PlanoDAO]] |
| **Classe associativa** | resolve N:N guardando dados da relação | [[Pacote model\|HistoricoVisualizacao]] (minuto, dispositivo, datas) |
| **Membros estáticos** | pertencem à classe | [[ConnectionFactory]]`.getConnection()`, [[CriadorBanco]], [[Conversor]], [[RelatorioController]]`.TODOS` |

## 9.2 Polimorfismo: três exemplos no projeto

1. **Métodos abstratos de [[TelaCrud]] (o mais claro).** A base chama `inserir()`, `atualizar(id)`, `eliminar(id)`, `carregarTabela()` e `carregarCombos()` sem saber qual tela está aberta. Na [[Telas filhas|TelaPlano]] eles chamam [[PlanoController]]; na [[Telas filhas|TelaTitulo]], [[Controllers de Conta, Perfil e Titulo|TituloController]]. É como o `sacar()` de `ContaCorrente` e `ContaPoupanca` da aula.
2. **`Map<String, JComponent> campos`.** O mapa guarda `JTextField` e `JComboBox` como `JComponent` (superclasse comum). Em `valor()` usamos `c instanceof JComboBox` para descobrir o tipo real, como o slide usa `func instanceof Gerente`.
3. **Variáveis do tipo da superclasse.** `JComponent componente` em `adicionarCampo(String rotulo, JComponent componente)` aceita qualquer componente específico: "tratar um Gerente como Funcionário".

## 9.3 Herança: a cadeia completa

```
Object <- Component <- Container <- Window <- Frame <- JFrame <- TelaCrud (abstract) <- TelaPlano
                                                                                   <- TelaConta
                                                                                   <- TelaPerfil
                                                                                   <- TelaTitulo
                                                                                   <- TelaHistorico
JFrame <- TelaPrincipal, TelaConexao, TelaRelatorio   (direto, não são cadastros)
```

- `super(titulo, colunas)` no construtor da filha chama o construtor de [[TelaCrud]], que chama `super(titulo)` de `JFrame`.

---
⬅ [[Integração Java-MySQL]] · [[00 - Painel]] · [[Gerar a build]] ➡
