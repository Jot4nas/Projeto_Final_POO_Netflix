---
tags: [netflix, conceito, poo]
---

# Sobrescrita e sobrecarga

**O que é:** **Sobrescrita** (`@Override`): a subclasse redefine um método herdado. **Sobrecarga**: mesmo nome com parâmetros diferentes na mesma classe (como `somar()` e `somar(double, double)` na aula).

**Onde está no projeto:** Sobrescrita: `carregarTabela()`, `carregarCombos()` e `definirPadroes()` nas telas, `isCellEditable` no modelo da tabela, `toString()` nos models. Sobrecarga: construtor vazio e completo de cada model; `definirValor(String, String)` e `definirValor(JComponent, String)` em [[TelaCrud]].

Ligações: [[Polimorfismo]] · [[Herança]] · [[Telas filhas]] · [[Conceitos de POO]]
