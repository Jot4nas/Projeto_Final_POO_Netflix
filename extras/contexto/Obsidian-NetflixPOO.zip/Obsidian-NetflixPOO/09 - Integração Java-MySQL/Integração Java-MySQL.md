---
tags: [netflix, jdbc, banco]
---

# Integração Java-MySQL

*Seção 8 da documentação: Integração Java ↔ MySQL (o que o professor mais cobra)*

```mermaid
sequenceDiagram
    actor U as Usuário
    U->>TelaPlano: clica em Inserir
    TelaPlano->>PlanoController: inserir(textos dos campos)
    PlanoController->>PlanoController: valida e converte (Conversor)
    PlanoController->>PlanoDAO: inserir(objeto Plano)
    PlanoDAO->>MySQL: INSERT com PreparedStatement
    MySQL-->>PlanoDAO: id gerado
    PlanoDAO-->>PlanoController: ok
    PlanoController-->>TelaPlano: "Plano inserido com sucesso!"
    TelaPlano-->>U: JOptionPane + tabela recarregada
```


## 8.1 As cinco peças da integração

```
1. Driver     mysql-connector-j-9.3.0.jar (dentro do Netflix.jar)   o "tradutor" Java <-> MySQL
2. Conexão    ConnectionFactory.getConnection()  ->  objeto Connection
3. Comando    String sql com "?"  ->  PreparedStatement (con.prepareStatement(sql))
4. Execução   executeUpdate() (INSERT/UPDATE/DELETE)  ou  executeQuery() (SELECT -> ResultSet)
5. Conversão  objeto -> colunas (ps.setX)   e   linha -> objeto (rs.getX + setX do model)
```

## 8.2 A conexão em detalhe

| Pedaço da URL | Significado |
|---|---|
| `jdbc:mysql://` | protocolo: JDBC falando com MySQL (o driver "reconhece" esse prefixo) |
| `localhost` | o servidor está neste computador (configurável na tela de conexão) |
| `3306` | porta padrão do MySQL |
| `/netflix` | banco a usar (equivale ao `USE netflix;`) |
| `?useSSL=false...` | parâmetros extras |

- `DriverManager.getConnection(URL, USUARIO, SENHA)` procura entre os drivers carregados um que entenda a URL e abre a conexão.
- Cada DAO abre uma conexão **por operação** e fecha ao terminar (try-with-resources). Simples e seguro para um trabalho acadêmico; sistemas grandes usam um *pool* de conexões.

## 8.3 "set" para gravar, "get" para ler

| Coluna | Atributo / tipo Java | Gravar (`PreparedStatement`) | Ler (`ResultSet`) |
|---|---|---|---|
| `plano.valor_mensal` | `valorMensal` / BigDecimal | `setBigDecimal` | `getBigDecimal` |
| `plano.permite_download` | `permiteDownload` / boolean | `setBoolean` | `getBoolean` |
| `conta.id_plano` (FK) | `idPlano` / int | `setInt` | `getInt` |
| `conta.telefone` | `telefone` / String (null) | `setString` (null → NULL) | `getString` (NULL → null) |
| `titulo.duracao_minutos` | `duracaoMinutos` / Integer (null) | `setInt` ou `setNull(i, Types.INTEGER)` | `getInt` + `wasNull()` |
| (JOIN) `plano.nome AS nome_plano` | `nomePlano` / String | não grava | `getString("nome_plano")` |
| (JOIN) `perfil.nome AS nome_perfil` | `nomePerfil` / String | não grava | `getString("nome_perfil")` |
| (JOIN) `conta.email AS email_conta` | `emailConta` / String | não grava | `getString("email_conta")` |
| (JOIN) `plano.nome AS nome_plano` | `nomePlano` / String | não grava | `getString("nome_plano")` |

No `PreparedStatement` o primeiro parâmetro é a **posição do `?`** (começa em 1); no `ResultSet` pode ser o **nome da coluna**.

## 8.4 Exemplo rastreado: INSERIR um plano

O usuário digita Nome `Familia`, Valor `29,90`, Qualidade `HD`, Telas `2` (escolhida na lista 1, 2 ou 4), Download `Sim` e clica em **Inserir**. (A Descrição não é digitada: a tela mostra "Duas telas, qualidade HD", gerada pelo Controller.)

1. **View:** `mostrarResultado(inserir())`; [[Telas filhas|TelaPlano]]`.inserir()` chama `controller.inserir("Familia", "29,90", "HD", "2", "Sim")`.
2. **Controller (`montar`):** `"Familia"` → `obrigatorio`; `"3"` → `paraInt` (e precisa ser ≥ 1) e, com a qualidade, vira a descrição `gerarDescricao("3", "HD")` = "Duas telas, qualidade HD"; `"29,90"` → `paraDecimal` = 29.90; `"Sim"` → `true`; data → `LocalDate`.
3. **DAO:** `INSERT INTO plano (...) VALUES (?, ?, ?, ?, ?, ?, ?)` com `setString(1,"Familia")`, `setString(2,"Duas telas, qualidade HD")`, `setBigDecimal(3, 29.90)`, `setString(4,"HD")`, `setInt(5,3)`, `setBoolean(6,true)` → 1, `setDate(7, ...)`.
4. **Execução:** `executeUpdate()`; o MySQL gera `id_plano = 4`; `getGeneratedKeys()` devolve o 4.
5. **Volta:** "Plano inserido com sucesso!" → `JOptionPane` → `recarregar()`.

## 8.5 Exemplo rastreado: o INNER JOIN do histórico

No banco a linha guarda só números: `id_visualizacao=1, id_perfil=1, id_titulo=1, minuto_parada=55`. O `listarComNomes()` devolve:

| id_visualizacao | id_perfil | id_titulo | minuto_parada | nome_perfil | nome_titulo | email_conta | nome_plano |
|---|---|---|---|---|---|---|---|
| 1 | 1 | 1 | 55 | Ana | Stranger Things | ana.silva@email.com | Premium |

O DAO cria o objeto com `setNomePerfil("Ana")` e `setNomeTitulo("Stranger Things")`; a tela mostra **"1 - Ana"** e **"1 - Stranger Things"**.

## 8.6 Exemplo rastreado: o RELATÓRIO

Filtro: 01/06/2025 a 05/06/2025, perfil "Todos".
1. [[TelaRelatorio]]`.gerar()` → [[RelatorioController]]`.gerar("01/06/2025", "05/06/2025", "Todos")`.
2. Controller: converte as datas, confere que a final não é anterior à inicial, `idPerfil = 0`.
3. DAO: `SELECT_COM_NOMES + "WHERE DATE(h.data_inicio) BETWEEN ? AND ? ORDER BY h.data_inicio"` (sem o filtro de perfil, porque é 0).
4. Resultado: 3 visualizações (Ana/Stranger Things, Ana/Ainda Estou Aqui, Pedro/Round 6).
5. `resumo(...)`: "Total de visualizações: 3 | Concluídas: 1 | Em andamento: 2 | Minutos assistidos: 237".

## 8.7 Quando o banco recusa: o caminho do erro até a tela

```
MySQL recusa (ou está desligado) -> SQLException
  -> o DAO não trata: "throws SQLException" repassa
  -> o Controller captura (catch) e devolve uma String com a mensagem
  -> a View mostra a String em um JOptionPane
```

| O que o usuário faz | Quem recusa | Mensagem |
|---|---|---|
| Eliminar um plano que tem contas | MySQL (FK) | "Não foi possível eliminar (o plano pode estar em uso...)" |
| Conta com e-mail repetido | MySQL (UNIQUE) | "Erro no banco de dados (e-mail já cadastrado?)..." |
| Nome vazio | Controller ([[Conversor]]`.obrigatorio`), antes do banco | "O campo 'Nome' é obrigatório." |
| `abc` no Ano | Controller ([[Conversor]]`.paraInt`) | "O campo 'Ano lançamento' deve ser um número inteiro." |
| Data final antes da inicial no relatório | [[RelatorioController]]`.gerar` | "A data final não pode ser anterior à data inicial." |
| MySQL desligado ou senha errada ao abrir | [[ConexaoController]]`.conectar` | "Não foi possível conectar ao MySQL..." |

Boa prática: validar no Controller **antes** de ir ao banco e, mesmo assim, deixar o banco como última defesa (PK, FK, UNIQUE, NOT NULL, ENUM).

## 8.8 Comparação com o exemplo da disciplina (`DAO` / `ManterAluno`)

| Exemplo da aula | No nosso projeto | Diferença |
|---|---|---|
| `class DAO` com `abrirBanco()` | [[ConnectionFactory]]`.getConnection()` | a conexão virou classe própria e é devolvida |
| `fecharBanco()` fecha só o `pst` | try-with-resources | fecha conexão, statement e resultset sozinho |
| `ManterAluno extends DAO` | [[PlanoDAO]] etc. sem herança | cada DAO pega sua conexão |
| `Class.forName("com.mysql.jdbc.Driver")` | driver carregado sozinho (JDBC 4) | a classe antiga não existe no conector 9.x |
| `inserir`, `deletarAluno`, `editarAluno`, `PesquisarTudo` | `inserir`, `eliminar`, `atualizar`, `listar` | iguais: PreparedStatement com `?` |
| `JOptionPane` dentro do DAO | mensagem devolvida pelo Controller | o DAO não mostra janelas (MVC) |
| botão chama `ManterAluno` direto | botão chama o Controller | a proposta proíbe lógica nos eventos do botão |
| `DefaultTableModel m = (DefaultTableModel) jTable.getModel(); m.addRow(...)` | `modelo.addRow(new Object[]{...})` | igual |

---
⬅ [[TelaRelatorio]] · [[00 - Painel]] · [[Conceitos de POO]] ➡
