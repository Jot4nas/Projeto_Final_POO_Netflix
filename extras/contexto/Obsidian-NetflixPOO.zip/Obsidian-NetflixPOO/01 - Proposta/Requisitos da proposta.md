---
tags: [netflix, proposta, requisitos]
---

# Requisitos da proposta

*Resumo do enunciado do professor*

**O que é:** o resumo do enunciado do professor (`Proposta/Trabalho Pratico POO Final.pdf`) e onde cada exigência está no nosso projeto.

> [!regra] Mínimo para entregar
> **4 CRUDs simples completos + 1 CRUD principal completo + 1 consulta com JOIN + 1 relatório da rotina principal.** Obrigatórios: Java, POO, JFrame/Swing, MySQL, JDBC, MVC, banco relacional, chaves primárias e estrangeiras. Não vale concentrar a lógica nos botões do JFrame.

## Onde está cada exigência

| Exigência da proposta | Onde está no projeto |
|---|---|
| 4 CRUDs simples (inserir, listar, alterar, excluir) | Plano, Conta, Perfil e Título: [[Telas filhas]] |
| 1 CRUD principal relacionando outras tabelas | Histórico de Visualização (FKs para Perfil e Título): [[HistoricoVisualizacaoDAO]], [[HistoricoController]] |
| Consulta com JOIN mostrando nomes, não códigos | `listarComNomes()` em [[HistoricoVisualizacaoDAO]] (5 tabelas: histórico, perfil, título, conta e plano), além do JOIN em [[ContaDAO]] e [[PerfilDAO]] |
| Relatório da rotina principal | [[TelaRelatorio]] + [[RelatorioController]]: visualizações por período e por perfil, com totais e **Salvar .txt** |
| Java + POO | [[Conceitos de POO]]: herança ([[TelaCrud]]), polimorfismo, classe abstrata, encapsulamento, sobrecarga e sobrescrita |
| MVC | pacotes `model`, `view`, `controller` (+ `dao` para o SQL): [[Visão geral]] |
| MySQL + JDBC, PK, FK, dados de demonstração, script SQL | [[Banco de dados]] e [[Integração Java-MySQL]] (`Projeto/Netflix/sql/netflix.sql`) |

## Nota (2,5 pontos no total)

| Parte | Critério | Valor |
|---|---|---|
| **A) Sistema** (1,5) | 4 CRUDs simples funcionando | 0,40 |
| | CRUD da rotina principal | 0,40 |
| | Banco MySQL, relacionamentos e JOIN | 0,25 |
| | POO e padrão MVC | 0,20 |
| | Relatório da rotina principal | 0,15 |
| | Organização e funcionamento geral | 0,10 |
| **B) Apresentação individual** (1,0) | 2 perguntas sobre o sistema, **0,5 cada** | 1,00 |

> [!decisao] A apresentação não é um extra
> Os 1,0 ponto da apresentação já estão dentro dos 2,5. Quem não responde às duas perguntas perde até 1,0 mesmo com o sistema perfeito. Por isso **todo membro do grupo** precisa dominar o código: veja [[Perguntas do professor]].

O professor quer ver o fluxo completo: **Cadastro → Relacionamento → Rotina principal → Consulta com JOIN → Relatório.**

Ligações: [[Visão geral]] · [[Rodar e testar]] · [[Perguntas do professor]]

---
⬅ [[00 - Painel]] · [[00 - Painel]] · [[O que mudou da V1 para a V2]] ➡
