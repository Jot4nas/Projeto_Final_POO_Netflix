---
tags: [netflix, roteiro, apresentacao, v2]
---

# Roteiro de apresentação · V2 (versão simples, aparência padrão do Swing)

> [!info] Como usar
> Siga na ordem: é a ordem da proposta (**cadastros → relacionamento → rotina principal → JOIN → relatório**). Tempo total: ~10 a 12 min. Cada passo diz **o que clicar**, **o que falar** e **o que o professor pode perguntar**. Cada pessoa deve saber explicar **qualquer** parte (a nota é individual).

## 0 · Antes de começar (faça antes da aula)

- [ ] MySQL ligado (porta 3306) e a senha do `root` à mão.
- [ ] Abrir `V2\Netflix.jar` (dois cliques) ou `Abrir Netflix.bat`. Se nada abrir, o `.bat` mostra o erro (falta Java).
- [ ] Ter o `Obsidian` e o NetBeans/pasta `src` abertos para mostrar código se pedirem.
- [ ] Se o banco estiver bagunçado: **Restaurar dados** (volta aos dados de exemplo).

## 1 · Abertura (30 s)

> "Fizemos um sistema de gerenciamento no estilo Netflix em **Java Swing** com **MySQL** via **JDBC**, em **MVC**. Ele tem 4 cadastros simples (Planos, Contas, Perfis, Títulos), o cadastro principal que é o **Histórico de Visualização**, uma consulta com **INNER JOIN** e um **relatório por período**."

Se quiserem ver, mostre a árvore do projeto: pacotes `model`, `view`, `controller`, `dao`, `util`.

## 2 · Tela de conexão e criação do banco (1 min)

1. Tela **"Netflix - Conectar ao MySQL"**: Servidor `localhost`, Porta `3306`, Usuário `root`, Senha.
2. Clique **Conectar**.
3. Fale: "O sistema **cria o banco e as tabelas sozinho** na primeira vez, lendo o `netflix.sql` de dentro do jar; salva a conexão no `config.properties`."

> [!codigo] Pode perguntar
> - **Onde está o script SQL?** `sql/netflix.sql` (PK, FK, dados de exemplo). O `CriadorBanco` lê, tira os comentários `--`, separa por `;` e executa cada comando.
> - **Quem faz a conexão?** `util/Conexao` (DriverManager + `Properties`). A View só chama o `ConexaoController`.

## 3 · Menu principal (20 s)

Mostre os botões **1. Planos … 5. Histórico de Visualização** e **Restaurar dados**. "O menu só abre as telas; não tem regra de negócio." A barra do topo (Início, Planos…) é a mesma em todas as telas (`BarraNavegacao`) e a troca usa o `Navegador` com um fade curto.

## 4 · CRUD simples: Planos (1,5 min) — *os outros três funcionam igual*

1. Abra **Planos** (3 linhas: Básico, Padrão, Premium).
2. **Inserir:** Nome `Familia`, Valor mensal `49.90`, Qualidade `4K`, Telas `4` (lista: 1, 2 ou 4), Download `Sim` → **Inserir** → mensagem de sucesso, linha nova.
3. **Salvar:** clique na linha → os dados sobem para o formulário → mude o valor para `54.90` → **Salvar**.
4. **Validação (mostre um erro de propósito):** valor `-5` → "O valor mensal deve ser maior que zero."; `abc` → "O campo 'Valor mensal' deve ser um número (ex.: 39.90)." O formulário **não** é apagado.
5. **Remover:** clique em `Familia` → **Remover** → pergunta "Remover o registro selecionado?" → **Sim**.
6. **Regra de integridade:** selecione **Premium** (tem conta) → Remover → "Não é possível remover este plano: há contas que usam ele..." (erro 1451 da chave estrangeira tratado no Controller).

> [!codigo] Pode perguntar
> - **Onde fica a validação?** No `Controller` (e a conversão de texto em número/data no `Conversor`, em `util`, que lança `IllegalArgumentException`). **Não** no botão.
> - **O botão tem lógica?** Não. `btnInserir.addActionListener(e -> mostrarResultado(inserir()))` chama o método da tela filha, que chama o Controller.
> - **Como a tabela é preenchida?** `DefaultTableModel`: `setRowCount(0)` apaga e `addRow(Object[])` adiciona.
> - **O que é DAO?** Só SQL com `PreparedStatement` (evita SQL injection). Devolve objetos `Model`.

## 5 · Relacionamentos (1 min)

- **Contas:** combo **Plano** (preenchido do banco: chave estrangeira). Insira `teste@email.com`, senha `1234`, telefone, país `BR`, data, status `Ativa`.
  - Validações: e-mail repetido → "Já existe uma conta com esse e-mail." (erro 1062, coluna `UNIQUE`); país com 2 letras → "O país deve ter 2 letras (ex.: BR)."
  - Tente **eliminar** `ana.silva` (tem perfis) → "Não é possível remover esta conta: ela ainda tem perfis..."
- **Perfis:** combo **Conta**; PIN com 4 dígitos ("O PIN deve ter exatamente 4 dígitos."); perfil infantil `Sim/Nao`. Remover um perfil apaga também o histórico dele (`ON DELETE CASCADE`) e a mensagem avisa.
- **Títulos:** Tipo (`Filme/Serie/...`), Classificação (`L…18`), Duração (vazia para série; usa `setNull` no banco).

> [!codigo] Pode perguntar
> - **Como o combo de FK é carregado?** `carregarCombos()` (gancho da `TelaCrud`) chama o Controller e `preencherCombo(...)` coloca itens `"1 - Premium"`. Ao salvar, o Controller extrai o ID antes do ` - `.
> - **Por que `setNull`?** Série não tem duração; gravamos `NULL` em vez de 0.

## 6 · Rotina principal: Histórico de Visualização (2 min)

1. Abra **Histórico** (6 linhas). Note as colunas **Conta** e **Plano** no final: vêm do **INNER JOIN**.
2. **Inserir:** Perfil `Ana`, Título `Ainda Estou Aqui`, Minuto de parada `90`, Concluído `Nao`, Dispositivo `TV`.
3. **Regras de negócio (no Controller):**
   - Minuto maior que a duração do título (137) → "O minuto de parada (200) não pode passar da duração do título (137 min)."
   - Minuto negativo → "O minuto de parada não pode ser negativo."
4. **Salvar** (marque `Concluído = Sim`) e **Remover** (apague o que criou).

> [!codigo] Pode perguntar
> - **Por que o histórico é o "principal"?** Liga **Perfil** × **Título** (relacionamento muitos-para-muitos) e guarda os dados da visualização (início, minuto, dispositivo).
> - **Onde está o JOIN?** `HistoricoVisualizacaoDAO.listarComNomes()`: **5 tabelas** (`historico_visualizacao`, `perfil`, `conta`, `plano` e `titulo`), com aliases.
> - **O `ON DELETE CASCADE`?** Só nas FKs do histórico (apagar um perfil/título apaga o histórico). Nas outras, o Controller bloqueia com mensagem.
> - **Por que `duracaoDoTitulo` no controller?** Para validar o minuto de parada; busca a duração pelo ID do título.

## 7 · INNER JOIN (30 s)

Volte à tabela do Histórico: "Esta listagem **não vem de uma tabela só**: o DAO junta 5 tabelas com `INNER JOIN` para mostrar nome do perfil, título, e-mail da conta e plano em vez de só números." Abra `HistoricoVisualizacaoDAO` e mostre o `SELECT ... FROM historico_visualizacao h INNER JOIN perfil p ... INNER JOIN conta c ... INNER JOIN plano pl ... INNER JOIN titulo t ...`.

## 8 · Relatório (1,5 min)

1. Na tela de **Histórico**, clique no botão **Relatório** (ao lado de Inserir, Salvar, Remover e Limpar).
2. Data inicial `01/01/2025` (formato dd/mm/aaaa), final = hoje (já preenchidas), Perfil = **Todos** → **Gerar relatório**.
3. Mostre a tabela e o **resumo** (total de minutos / registros).
4. Filtre por um perfil (`Ana`) e gere de novo. Teste data final **antes** da inicial → "A data final não pode ser anterior à data inicial."
5. **Salvar .txt** → `JFileChooser` (janela de salvar) → escolha o local → mensagem "Relatório salvo em: ..." → abra o arquivo (cada linha traz perfil, e-mail da conta, plano, título e minuto).

> [!codigo] Pode perguntar
> - **De onde vêm os dados?** `RelatorioController` → DAO com o JOIN e `WHERE DATE(h.data_inicio) BETWEEN ? AND ?` (+ filtro de perfil); o BETWEEN inclui as duas datas.
> - **Como grava o arquivo?** `Files.write(Path.of(caminho), texto.getBytes(UTF_8))` dentro de `try/catch (IOException)`; o texto é montado com `StringBuilder`.
> - **A View calcula algo?** Não. O total vem do Controller.

## 9 · Restaurar dados e fechamento (30 s)

**Restaurar dados** (menu) → confirmação → "Banco recriado com os dados de exemplo!". "Isso roda o `netflix.sql` de novo." Feche mostrando: "Código em `model`, `view`, `controller`, `dao`, `util`; nenhuma regra nos eventos dos botões; PK, FK e dados de exemplo no `netflix.sql`."

## Perguntas gerais que costumam cair (resposta curta)

| Pergunta | Resposta |
|---|---|
| O que é MVC? | Separar em Model (dados), View (telas) e Controller (regras); aqui com DAO para o SQL |
| Qual a diferença entre DAO e Controller? | DAO fala com o banco; Controller valida e coordena; a View só mostra |
| `PreparedStatement` × `Statement` | O primeiro usa `?` (parâmetros) e evita SQL injection |
| O que é `try-with-resources`? | Fecha Connection/Statement/ResultSet sozinho no fim |
| O que é herança aqui? | As 5 telas herdam de `TelaCrud` (Template Method) |
| Polimorfismo? | `TelaCrud` chama `inserir()`; cada filha tem o seu |
| Encapsulamento? | Atributos `private` e getters/setters nos `Model` |
| Onde ficam os dados do banco? | `config.properties` (não vai ao GitHub) |
| Por que a senha está em texto? | Simplificação didática (`senha_hash` guarda o texto); em produção usaria hash (BCrypt) |

> [!warning] Ponto fraco que admitimos
> Senha em texto puro. Fale antes de perguntarem e diga como corrigir (hash).

---
⬅ [[00 - Painel]] · [[Roteiro - V3]] · [[Perguntas prováveis do professor]] · [[Fora da aula - Índice]]
