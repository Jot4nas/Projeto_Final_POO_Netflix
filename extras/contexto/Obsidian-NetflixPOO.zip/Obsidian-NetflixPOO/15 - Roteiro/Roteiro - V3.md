---
tags: [netflix, roteiro, apresentacao, v3]
---

# Roteiro de apresentação · V3 (front-end personalizado)

> [!info] Como usar
> A V3 tem **a mesma lógica da V2** (Model, DAO, Controller, JOIN, relatório). Muda só a **View**: tema escuro, capas, avatares, cartões. Por isso o roteiro é o da [[Roteiro - V2]] com as telas da V3. Tempo: ~12 min. **Regra de ouro:** se perguntarem "onde está a regra?", a resposta é sempre *Controller*, não o visual.

## 0 · Antes de começar

- [ ] MySQL ligado e senha à mão.
- [ ] Abrir `V3-visual\Netflix.jar` (a pasta `capas` ao lado do jar mostra os pôsteres; **sem ela** as capas são desenhadas em código e tudo funciona igual).
- [ ] Se o banco estiver bagunçado: Início → **Restaurar dados**.

## 1 · Abertura (30 s)

> "É o mesmo sistema da primeira versão, só que com a interface feita por nós em Java2D: tema escuro, capas, avatares e cartões. **Nenhuma linha de Controller, DAO ou Model mudou.** As visões leem o mesmo `DefaultTableModel` da tabela."

## 2 · Conexão e Início (1,5 min)

1. Tela de conexão (estilizada): servidor `localhost`, porta `3306`, usuário, senha → **Conectar**. (Cria o banco sozinho na 1ª vez.)
2. Abre o **Início**: destaque ("EM DESTAQUE") + "Populares na Netflix" + "Continuar assistindo como <perfil>".
3. **Clique em outra capa** → o destaque muda (título, meta em verde, sinopse). Mostre o contorno branco na capa escolhida.
4. Na fileira "Continuar assistindo", mostre a **barra de progresso** vermelha: `minuto de parada ÷ duração`; concluído = 100%.
5. Mostre a barra do topo (NETFLIX, Início, Planos…, Restaurar dados) e **passe o mouse**: hover e foco com Tab.

> [!codigo] Pode perguntar
> - **De onde vêm as capas?** `Capa.desenhar`: arquivo `capas/NOME.jpg|png` (lido com `ImageIO`, guardado em cache) ou, se não houver, desenhada com `GradientPaint` + título. Ver [[V3 - Capa e Icone]].
> - **Quem decide o "perfil mais recente"?** A tela percorre o histórico e guarda o de maior `dataUltimaVisualizacao` (`isAfter`). Os dados vêm do `HistoricoController.listarComNomes()`.
> - **O Início tem SQL?** Não: só chama `TituloController` e `HistoricoController`.

## 3 · Planos (1,5 min)

1. Abra **Planos**: visão **Visual** (tabela comparativa dos planos) e botão **Tabela** (a `JTable`).
2. Alterne **Visual | Tabela**: "são os mesmos dados do `DefaultTableModel`; muda só o desenho (`CardLayout`)".
3. Selecione um plano → painel **Detalhes** à direita com o formulário. Insira `Familia` (valor `49.90`, `4K`, 4 telas, `Sim`, `2026-01-10`) → **Inserir**.
4. Erros: valor `-5` → "O valor mensal deve ser maior que zero."; tente eliminar **Premium** → "Não é possível eliminar este plano: há contas que usam ele...".
5. Elimine `Familia` (confirmação **Sim**).

## 4 · Contas e Perfis (2 min)

- **Contas:** visão em **cartões** (e-mail, plano, status). Combo **Plano** (FK). Insira uma conta; repita o e-mail → "Já existe uma conta com esse e-mail." Tente eliminar `ana.silva` → "ainda tem perfis".
- **Perfis:** **avatares** coloridos (a cor vem do `hashCode` do ID); perfil infantil mostra "KiDS"; o último avatar **"Novo perfil"** limpa o formulário (`acoes.novo()`). PIN de 4 dígitos.
- Clique num avatar → o formulário **sobe** os dados (mesmo listener da V2). Eliminar um perfil apaga o histórico dele (cascade) e avisa.

## 5 · Títulos (30 s)

Só **Tabela** (a aba não tem visão: `criarVisao` devolve `null`). Mostre Tipo (`Filme/Serie/...`), Classificação e Duração vazia para série (`NULL` no banco).

## 6 · Histórico de Visualização — rotina principal (2 min)

1. Abra **Histórico**: linhas com **miniatura**, perfil, título, **conta e plano** (vêm do JOIN) e progresso.
2. **Inserir:** Perfil `Ana`, Título `Ainda Estou Aqui`/`Alerta Vermelho`, Início `2026-05-01 20:00`, Última `2026-05-01 21:30`, Minuto `90`, Concluído `Nao`, Dispositivo `TV`.
3. Regras no Controller: última antes do início; minuto negativo; minuto maior que a duração ("O minuto de parada (200) não pode passar da duração do título (118 min).").
4. **Atualizar** (Concluído = Sim) e **Eliminar**.
5. Volte ao Início: a fileira "Continuar assistindo" **mudou** (porque os dados mudaram no banco).

> [!codigo] Pode perguntar
> - **INNER JOIN?** `HistoricoVisualizacaoDAO.listarComNomes()`: 5 tabelas (histórico, perfil, conta, plano, título) com aliases. Ver [[HistoricoVisualizacaoDAO]].
> - **Por que as colunas Conta/Plano ficam no fim da tabela?** Não têm campo no formulário; a `TelaCrud` copia só as colunas com campo (`aoSelecionar`).

## 7 · Relatório (1,5 min)

1. Na tela de **Histórico**, clique no botão **Relatório** (ao lado de Inserir, Atualizar, Eliminar e Limpar). Datas (`2025-01-01` até hoje) e perfil **Todos** → **Gerar relatório**.
2. Mostre os "**chips**" (total de visualizações e de minutos) e a tabela estilizada.
3. Filtre por perfil; teste data final anterior → "A data final não pode ser anterior à data inicial."
4. **Salvar .txt** → `JFileChooser` → "Relatório salvo em: ...".

## 8 · Restaurar dados e fechamento (30 s)

Início → **Restaurar dados** → confirma → "Banco recriado com os dados de exemplo!" e a tela inteira é **redesenhada** (`montarTela()`).

> "Resumo: 4 CRUDs + CRUD principal + JOIN + relatório, MVC, sem regra nos botões. A V3 só troca a View."

## Detalhes de código que o professor pode pegar (só da V3)

| Pergunta | Resposta curta |
|---|---|
| Como desenhou os botões? | `Tema.Botao extends JButton`, `paintComponent` com `Graphics2D.fillRoundRect` + estados hover/pressionado/foco. [[V3 - Java2D e desenho]] |
| O que é Nimbus/`UIManager`? | Aparência (Look and Feel) do Java + troca global de cores. [[V3 - Nimbus, UIManager e renderers]] |
| O que é um renderer? | Objeto que a `JTable` usa para desenhar cada célula (linhas alternadas, seleção vermelha) |
| Para que serve a cache de imagens? | Não reler o disco a cada repintura (`HashMap<String, BufferedImage>`) |
| `Scrollable`? | Interface para o painel rolar só na vertical, acompanhando a largura (`PainelRolavel`) |
| `Visao.Acoes`? | Interface de *callback*: a visão avisa a tela sem depender dela |
| Por que `Visao` é abstrata? | Define `atualizar()` e `marcar()`; cada aba implementa. Polimorfismo |
| Por que `iniciar()` no fim do construtor filho? | Os atributos da filha (o controller) ainda não existem quando a mãe roda |
| `invokeLater`? | Executa na thread da interface depois do que está em andamento (o `Main` abre a tela e a rolagem ao topo usam) |
| Fade entre telas? | `Navegador`: glass pane + `javax.swing.Timer` a cada 16 ms. [[Timer, glass pane e fade]] |

---
⬅ [[00 - Painel]] · [[Roteiro - V2]] · [[Perguntas prováveis do professor]] · [[Código V3 - Índice]]
