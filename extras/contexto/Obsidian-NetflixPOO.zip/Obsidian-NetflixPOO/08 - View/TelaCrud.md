---
tags: [netflix, codigo, view, classe]
---

# TelaCrud

*Seção 7.5: TelaCrud (tela base, abstract)* · Pasta: [[Pacote view]]

```mermaid
classDiagram
    JFrame <|-- TelaCrud
    TelaCrud <|-- TelaPlano
    TelaCrud <|-- TelaConta
    TelaCrud <|-- TelaPerfil
    TelaCrud <|-- TelaTitulo
    TelaCrud <|-- TelaHistorico
    class TelaCrud {
        <<abstract>>
        #carregarTabela()
        #inserir() String
        #atualizar(id) String
        #eliminar(id) String
        #carregarCombos()
        #definirPadroes()
    }
```


Padrão **Template Method**: a classe base define o esqueleto (layout, botões, fluxo) e as filhas preenchem os "buracos" (métodos abstratos). Isso é **herança** e **polimorfismo**: quando a base chama `inserir()`, executa a versão da tela filha aberta.

**Atributos**
- `protected final DefaultTableModel modelo;` e `protected final JTable tabela;`: `protected` = as filhas acessam.
- `private final Map<String, JComponent> campos = new LinkedHashMap<>();`: liga cada rótulo ("Nome") ao seu campo. `LinkedHashMap` mantém a ordem; `JComponent` é a superclasse de `JTextField` e `JComboBox`.
- `private final JPanel painelForm = new JPanel(new GridLayout(0, 2, 5, 5));`: formulário em 2 colunas.

**Construtor `protected TelaCrud(String titulo, String[] colunas)`**
- `super(titulo);`: chama o construtor de `JFrame` (título da janela).
- `modelo = new DefaultTableModel(colunas, 0) { @Override public boolean isCellEditable(...) { return false; } };`: cria o modelo; as chaves criam uma **classe anônima** que sobrescreve `isCellEditable` (tabela só de leitura).
- `tabela = new JTable(modelo); tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);`.

**Métodos que as filhas implementam**
- Abstratos: `carregarTabela()`, `String inserir()`, `String atualizar(String id)`, `String eliminar(String id)`.
- Ganchos opcionais (vêm vazios): `carregarCombos()` (**novo**: preenche os combos de FK) e `definirPadroes()` (valores iniciais).

**Campos do formulário**
- `adicionarCampo(rotulo, componente)`: guarda no mapa e coloca rótulo e campo no painel.
- `preencherCombo(JComboBox<String> combo, List<String> opcoes)` (**novo**): `combo.removeAllItems()` e `addItem` para cada opção.
- `valor(rotulo)`: lê um campo como texto. `c instanceof JComboBox` descobre o tipo real; combo → `getSelectedItem().toString()`; caixa de texto → `((JTextField) c).getText()` (o *cast* trata o componente como caixa de texto).
- `definirValor(String rotulo, String texto)` e `definirValor(JComponent c, String texto)`: mesmo nome, parâmetros diferentes = **sobrecarga**. No combo: `setSelectedItem(texto)` seleciona o item igual ao texto (ex.: `"3 - Premium"`).

**`iniciar()`** (chamado no **final** do construtor da filha, porque no construtor da base o `controller` da filha ainda não existe):
- `btnInserir.addActionListener(e -> mostrarResultado(inserir()));`: chama o `inserir()` da filha (que chama o Controller) e mostra a mensagem.
- `btnAtualizar.addActionListener(e -> mostrarResultado(atualizar(idSelecionado())));`.
- `btnEliminar.addActionListener(e -> confirmarEliminar());` e `btnLimpar.addActionListener(e -> limpar());`.
- `tabela.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting() && tabela.getSelectedRow() >= 0) { aoSelecionar(); } });`: ao clicar numa linha, copia para o formulário. `getValueIsAdjusting()` é `true` enquanto a seleção ainda muda.
- `add(painelForm, BorderLayout.NORTH); add(new JScrollPane(tabela), BorderLayout.CENTER); add(painelBotoes, BorderLayout.SOUTH);`: formulário em cima, tabela no meio (com rolagem), botões embaixo.
- `setDefaultCloseOperation(DISPOSE_ON_CLOSE)`: fecha só esta janela.
- `recarregar(true);`: carrega combos e tabela e deixa o formulário com os valores iniciais.

**Demais métodos (privados)**
- `aoSelecionar()`: percorre os campos e copia as células da linha: `modelo.getValueAt(linha, coluna++)`, começando na coluna 1 (a 0 é o ID). **Convenção:** colunas da tabela = ID + um campo por coluna, na mesma ordem. Como a tabela mostra `"3 - Premium"` e o combo tem `"3 - Premium"`, funciona para FK também.
- `confirmarEliminar()`: se nenhuma linha está selecionada, chama `mostrarResultado(eliminar(""))` direto (o Controller avisa "Selecione um registro") sem perguntar nada; senão `showConfirmDialog` e, só com **Sim**, `mostrarResultado(eliminar(idSelecionado()))`.
- `mostrarResultado(String mensagem)`: mostra a mensagem num `JOptionPane` e chama `recarregar(deuCerto)`, onde `deuCerto = mensagem.contains("sucesso")`. Assim o formulário só é limpo quando a ação funcionou.
- `recarregar(boolean limparFormulario)`: `modelo.setRowCount(0);` e, dentro de `try`, `carregarCombos(); carregarTabela();`. `catch (RuntimeException e)` mostra o erro (ex.: MySQL desligado). Se `limparFormulario` for `true`, termina com `limpar()`. Se for `false` (depois de um erro), recarregar os combos os volta ao primeiro item e a tabela perde a seleção; por isso o método guarda a escolha de cada combo e o ID da linha selecionada e restaura os dois no fim. O atributo `recarregandoTabela` impede que a re-seleção da linha sobrescreva o formulário com os valores da tabela.
- `limpar()`: caixas de texto ficam vazias, combos voltam ao primeiro item, `tabela.clearSelection()` e `definirPadroes()`.
- `idSelecionado()`: ID (coluna 0) da linha selecionada, ou `""` (o Controller avisa "Selecione um registro").

---
⬅ [[TelaPrincipal]] · [[00 - Painel]] · [[Telas filhas]] ➡
