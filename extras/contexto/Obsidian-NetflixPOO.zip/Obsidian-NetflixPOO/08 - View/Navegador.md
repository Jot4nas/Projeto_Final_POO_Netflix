---
tags: [netflix, view, navegacao, v2]
---

# Navegador (`view/Navegador.java`) · V2

*A classe que troca de tela sem deixar janelas empilhadas.*

## Para que serve
Cada botão da [[BarraNavegacao]] abre outra tela. Em vez de abrir **outra janela por cima**, o `Navegador` abre a nova **no mesmo lugar e tamanho** e fecha a antiga, com um fade curto.

## Linha a linha

| Trecho | O que faz |
|---|---|
| `public final class Navegador` + construtor `private` | Classe **utilitária**: só tem métodos `static`, ninguém precisa (nem pode) criar objeto. `final` impede herança |
| `ir(JFrame atual, JFrame nova)` | Método chamado pelos botões: `Navegador.ir(this, new TelaPlano())` |
| `nova.setBounds(atual.getBounds())` | Copia posição e tamanho da janela atual |
| `nova.setExtendedState(atual.getExtendedState())` | Se a atual estava maximizada, a nova também fica |
| `mostrarComFade(nova)` | Mostra a nova com a transição |
| `atual.dispose()` | Fecha **só** a janela antiga (libera os recursos) |
| `trocar(origem, nova)` | Igual ao `ir`, mas centraliza (`setLocationRelativeTo(null)`). Usado **só da tela de conexão para o menu** |
| `new Veu(cor)` | Painel transparente (classe interna `private static final`) com a cor de fundo da tela |
| `nova.setGlassPane(veu)` + `veu.setVisible(true)` | Coloca o véu **por cima** do conteúdo; enquanto visível, bloqueia cliques |
| `new Timer(16, null)` | `javax.swing.Timer`: dispara a cada 16 ms (~60 quadros/s) na thread da interface |
| `veu.alfa -= 0.11f` | A cada passo, o véu fica mais transparente (de 1 a 0 em 9 passos ≈ 150 ms) |
| `relogio.stop()` + `veu.setVisible(false)` | Fim: para o timer e tira o véu |

> [!info] Detalhe de cada peça
> A explicação completa do `Timer`, do glass pane e do `Color(r,g,b,alfa)` está em [[Timer, glass pane e fade]] (pasta *14 - Fora da aula*).

> [!decisao] Por que não `Window.setOpacity`?
> Lança `IllegalComponentStateException` em janela com barra de título do Windows. Por isso o fade é feito **dentro** da janela.

> [!codigo] Como responder
> **"A navegação tem regra de negócio?"** — "Não. É só View: cria a tela nova (`new TelaPlano()`), que por sua vez chama o seu Controller."
>
> **"Por que o construtor é privado?"** — "É uma classe só de métodos estáticos; não faz sentido criar objetos dela."

---
⬅ [[Pacote view]] · [[BarraNavegacao]] · [[TelaPrincipal]]
