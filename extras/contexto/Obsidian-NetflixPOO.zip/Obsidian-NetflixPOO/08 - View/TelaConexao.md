---
tags: [netflix, codigo, view, classe]
---

# TelaConexao

*Seção 7.3: TelaConexao (nova)* · Pasta: [[Pacote view]]


- Campos `JTextField` para servidor, porta, usuário e `JPasswordField` para senha, já preenchidos com `controller.servidorSalvo()` etc.
- `GridLayout(0, 2, 5, 5)`: duas colunas (rótulo, campo).
- `getRootPane().setDefaultButton(btnConectar)`: apertar Enter clica em Conectar.
- `conectar()`: `String erro = controller.conectar(...)`; `new String(campoSenha.getPassword())` converte a senha (o `JPasswordField` devolve `char[]`). `if (erro == null) { dispose(); new TelaPrincipal().setVisible(true); }` fecha esta tela e abre o menu; senão mostra o erro.

---
⬅ [[Main]] · [[00 - Painel]] · [[TelaPrincipal]] ➡
