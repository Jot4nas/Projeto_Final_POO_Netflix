---
tags: [netflix, codigo, view]
---

# Conceitos de Swing

*Seção 7.1: Conceitos de Swing usados* · Pasta: [[Pacote view]]


- **`JFrame`:** a janela.
- **`JTable` + `DefaultTableModel`:** o `JTable` só **desenha**; os dados vivem no `DefaultTableModel` ("planilha em memória"). `setRowCount(0)` apaga as linhas e `addRow(Object[])` adiciona uma.
- **`ActionListener`:** "o que fazer quando o botão for clicado", registrado com `botao.addActionListener(...)`. Usamos **lambdas**: `e -> fazerAlgo()` é a forma curta de `new ActionListener() { public void actionPerformed(ActionEvent e) { fazerAlgo(); } }`.
- **`JComboBox`:** lista suspensa (ENUMs, Sim/Nao, chaves estrangeiras).
- **`JPasswordField`:** caixa de texto que mostra `•••` (senha do MySQL).
- **`JFileChooser`:** janela "Salvar como" (relatório .txt).
- **Layouts:** `BorderLayout` (NORTH, CENTER, SOUTH), `GridLayout` (grade), `FlowLayout` (em fila).
- **`JOptionPane`:** janelinhas de mensagem e de confirmação.

---
⬅ [[Pacote view]] · [[00 - Painel]] · [[Main]] ➡
