---
tags: [netflix, codigo, view]
aliases: [TelaPlano, TelaConta, TelaPerfil, TelaTitulo, TelaHistorico]
---

# Telas filhas

*Seção 7.6: As telas filhas (TelaPlano, TelaConta, TelaPerfil, TelaTitulo, TelaHistorico)* · Pasta: [[Pacote view]]


Todas têm a mesma estrutura:
- `extends TelaCrud`: **herança**; ganham layout, botões e fluxo prontos.
- `private final XController controller = new XController();`.
- Combos de FK como atributos: `private final JComboBox<String> comboPlano = new JComboBox<>();` (começam vazios e são preenchidos em `carregarCombos()`).
- Construtor: `super("Título", new String[]{colunas...});`, um `adicionarCampo(...)` por campo e `iniciar();` por último.
- `carregarCombos()`: `preencherCombo(comboPlano, controller.opcoesPlanos());`.
- `carregarTabela()`: `for (Plano p : controller.listar()) { modelo.addRow(new Object[]{...}); }`. **É aqui que o `DefaultTableModel` é preenchido.** Colunas de FK usam [[Conversor]]`.opcao(id, nome)`.
- `inserir()` / `atualizar(id)` / `eliminar(id)`: só `return controller.inserir(valor("Nome"), ...);`. Nenhuma lógica.
- `definirPadroes()`: ex.: `definirValor("País", "BR");`.

| Tela | Combos | Detalhes |
|---|---|---|
| `TelaPlano` | Qualidade máxima, Permite download | valor mensal digitado como texto; **descrição automática** (campo só leitura, ver abaixo) |
| `TelaConta` | **Plano (FK)**, Status | coluna Plano mostra "3 - Premium" (JOIN); padrões: país BR, data/hora atual |
| `TelaPerfil` | **Conta (FK)**, Perfil infantil | coluna Conta mostra "1 - ana.silva@email.com" (JOIN); PIN opcional |
| `TelaTitulo` | Tipo, Classificação, Disponível | duração pode ficar vazia (séries) |
| `TelaHistorico` | **Perfil (FK)**, **Título (FK)**, Concluído, Dispositivo | **CRUD principal**; tabela com o INNER JOIN: "1 - Ana", "1 - Stranger Things" |

**`TelaPlano`: descrição automática.** A descrição não é digitada. A tela guarda os dois combos, o de telas simultâneas (`comboTelas`, com 1, 2 e 4) e o de qualidade (`comboQualidade`), em atributos e liga os dois a `atualizarDescricao()` com `addActionListener(e -> atualizarDescricao())` (também dispara quando o código seleciona o valor ao clicar numa linha da tabela). `atualizarDescricao()` chama `controller.gerarDescricao(...)` e coloca o resultado no campo "Descrição (automática)", que é `setEditable(false)`. A regra de como o texto é montado fica no Controller (MVC).

> **O que sumiu da `TelaHistorico` na V2:** as duas colunas escondidas com os IDs e a sobrescrita de `aoSelecionar()`. Elas existiam porque a tabela mostrava só "Ana" e o combo tinha "1 - Ana". Agora os dois mostram "1 - Ana", então o `aoSelecionar()` padrão da [[TelaCrud]] resolve.

---
⬅ [[TelaCrud]] · [[00 - Painel]] · [[TelaRelatorio]] ➡
