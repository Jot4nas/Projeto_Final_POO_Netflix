---
tags: [netflix, codigo, view, classe]
---

# TelaPrincipal

*Seção 7.4: TelaPrincipal (menu)* · Pasta: [[Pacote view]]


- Sete `JButton`, numerados na ordem da apresentação: 1. Planos, 2. Contas, 3. Perfis, 4. Títulos, 5. Histórico (CRUD principal), 6. Relatório, e **Restaurar dados de exemplo**.
- `btnPlanos.addActionListener(e -> new TelaPlano().setVisible(true));`: cada clique **cria** a tela e a mostra. (Na V1 isso usava `Supplier<JFrame>` e `TelaPlano::new`; agora é direto.)
- `restaurar()`: pede confirmação (`showConfirmDialog`) e chama `conexaoController.restaurarDadosExemplo()`.
- `setDefaultCloseOperation(EXIT_ON_CLOSE)`: fechar o menu encerra o programa.

---
⬅ [[TelaConexao]] · [[00 - Painel]] · [[TelaCrud]] ➡
