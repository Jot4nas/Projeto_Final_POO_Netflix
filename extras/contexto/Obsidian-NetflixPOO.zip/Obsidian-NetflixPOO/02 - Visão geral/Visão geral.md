---
tags: [netflix, projeto, mvc]
---

# Visão geral

*Seção 1 da documentação: Visão geral*

```mermaid
flowchart LR
    V["View<br/>telas Swing"] --> C["Controller<br/>valida e aplica regras"]
    C --> D["DAO<br/>SQL com PreparedStatement"]
    D --> B[("MySQL")]
    M["Model<br/>Plano, Conta, Perfil..."] -.-> V & C & D
```


O programa é um sistema desktop (Java Swing + MySQL) que gerencia um recorte do banco da Netflix: **planos, contas, perfis, títulos** e o **histórico do que cada perfil assistiu**. Cada tela permite **inserir, listar, atualizar e eliminar** registros. A tela de Histórico é o **CRUD principal** e mostra os **nomes** do perfil e do título (INNER JOIN) em vez dos IDs. A tela de **Relatório** filtra as visualizações por período e perfil e calcula totais.

## 1.1 Tecnologias

- **Java 11+** (compilado com `--release 11`) com orientação a objetos (classes, herança, encapsulamento, polimorfismo).
- **Java Swing** para as telas (`JFrame`, `JTable`, `DefaultTableModel`, `JComboBox`, `JTextField`, `JPasswordField`, `JFileChooser`).
- **JDBC** com `PreparedStatement` para falar com o banco.
- **MySQL** com o driver `mysql-connector-j-9.3.0.jar` (vai **dentro** do `Netflix.jar`).

## 1.2 Arquitetura MVC

Cada camada só conversa com a vizinha:

```
View  -->  Controller  -->  DAO  -->  MySQL
(tela)     (regras)        (SQL)     (dados)
               |
             Model  (objetos que carregam os dados entre as camadas)
```

| Pacote | Papel | O que NÃO pode ter |
|---|---|---|
| `model` | Entidades: guardam dados (atributos, getters e setters) | SQL, telas, regras |
| `dao` | Data Access Object: **único lugar com SQL** (`PreparedStatement`) | telas, regras de negócio |
| `controller` | Valida, converte textos, aplica regras de negócio, chama o DAO | telas, SQL |
| `view` | Telas Swing: lê campos, chama o Controller, mostra mensagens e tabelas | SQL, regras de negócio |
| `util` | Apoio: conexão, criação do banco, conversão de textos | regras específicas de uma tela |

## 1.3 O caminho de uma ação (exemplo: inserir um plano)

1. O usuário preenche os campos da [[Telas filhas|TelaPlano]] e clica em **Inserir**.
2. O botão faz `mostrarResultado(inserir())` (na [[TelaCrud]]). Por polimorfismo, `inserir()` executa a versão da [[Telas filhas|TelaPlano]].
3. [[Telas filhas|TelaPlano]]`.inserir()` lê os campos como `String` e chama [[PlanoController]]`.inserir(...)`.
4. O Controller valida e converte (via [[Conversor]]), cria um objeto [[Pacote model|Plano]] e chama [[PlanoDAO]]`.inserir(plano)`.
5. O DAO abre a conexão ([[ConnectionFactory]]), prepara o `INSERT` com `PreparedStatement` e executa.
6. A mensagem de sucesso (ou erro) volta pelo mesmo caminho; `mostrarResultado` mostra um `JOptionPane` e recarrega combos e tabela; o formulário só é limpo quando deu certo (se deu erro, o usuário mantém o que digitou e corrige só o campo errado).

## 1.4 Estrutura de pastas

```
V2/
  Netflix.jar                  (BUILD PRONTA: dois cliques para abrir)
  Abrir Netflix.bat            (alternativa: abre o jar e mostra erros, se houver)
  DOCUMENTACAO.md              (este arquivo)
  Netflix/                     (código-fonte)
    build.bat / build.sh       (geram o Netflix.jar de novo)
    lib/mysql-connector-j-9.3.0.jar  (driver JDBC do MySQL)
    sql/netflix.sql            (cria o banco, as tabelas e os dados de teste)
    src/
      Main.java                (ponto de entrada: abre a TelaConexao)
      model/       Plano, Conta, Perfil, Titulo, HistoricoVisualizacao
      dao/         PlanoDAO, ContaDAO, PerfilDAO, TituloDAO, HistoricoVisualizacaoDAO
      controller/  PlanoController, ContaController, PerfilController, TituloController,
                   HistoricoController, RelatorioController, ConexaoController
      view/        TelaConexao, TelaPrincipal, TelaCrud, TelaPlano, TelaConta, TelaPerfil,
                   TelaTitulo, TelaHistorico, TelaRelatorio
      util/        ConnectionFactory, CriadorBanco, Conversor
  Banco de dados/              (modelo lógico do grupo: .mwb e .pdf)
  Proposta/                    (enunciado do trabalho)
  Fontes/                      (aulas e exemplos do professor)
```

## 1.5 Escopo cumprido (checklist da proposta)

| Exigência | Onde está |
|---|---|
| **4 CRUDs simples** | Plano, Conta, Perfil, Título (telas 1 a 4 do menu) |
| **1 CRUD principal** (com FKs) | `historico_visualizacao`: liga Perfil e Título (tela 5) |
| **Consulta com JOIN** | [[HistoricoVisualizacaoDAO]]`.listarComNomes()` (5 tabelas: histórico, perfil, título, conta e plano). Também em [[ContaDAO]]`.listar()` e [[PerfilDAO]]`.listar()` |
| **Relatório da rotina principal** | Tela 6: [[TelaRelatorio]] → [[RelatorioController]] → [[HistoricoVisualizacaoDAO]]`.listarPorPeriodo()` |
| POO + MVC | pacotes `model`/`dao`/`controller`/`view`; herança [[TelaCrud]] ([[Conceitos de POO\|seção 9]]) |
| MySQL: banco, tabelas, PK, FK, dados, script | `sql/netflix.sql` ([[Banco de dados\|seção 2]]) |
| Fluxo completo: Cadastro → Relacionamento → Rotina Principal → JOIN → Relatório | menu de cima para baixo: 1 → 2 → 3 → 4 → 5 → 6 |

**Convenção de nomes:** atributos em `camelCase` no Java, colunas em `snake_case` no banco; a conversão é feita nos DAOs.

> **Como ler as próximas seções:** cada classe aparece com seus trechos e cada linha (ou grupo de linhas idênticas, como getters e setters) vem com a explicação do que faz e **por quê**. Linhas só com `}` fecham o bloco aberto acima e não são comentadas.

---
⬅ [[O que mudou da V1 para a V2]] · [[00 - Painel]] · [[Banco de dados]] ➡
