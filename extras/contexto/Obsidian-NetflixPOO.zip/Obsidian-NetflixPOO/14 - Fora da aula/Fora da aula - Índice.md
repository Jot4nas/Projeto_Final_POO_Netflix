---
tags: [netflix, fora-da-aula, estudo]
---

# Fora da aula: o que usamos e o professor não passou

> [!warning] Por que esta pasta existe
> O professor avisou que o aluno responde **2 perguntas sobre o código do próprio sistema** (0,5 ponto cada). O material que ele passou (pasta `Fontes`) é **só o básico**: classes, herança, polimorfismo, telas Swing geradas pelo NetBeans e um CRUD de `Aluno` com JDBC. Muita coisa do nosso projeto **não está nesse material**. Se ele perguntar sobre elas, é preciso saber explicar. Cada nota daqui explica **o que é, linha a linha, onde usamos e como responder**.

> [!info] Como este mapa foi montado
> Abri o `Fontes.zip` inteiro: os 3 slides (`.pptx`), os 6 projetos de exemplo (`.java`), o `Persistencia POO mysql.txt` e o `Videos de OO.txt`. "Visto em aula = não" quer dizer **não aparece nesse material**. O professor pode ter falado de algo em sala sem registrar; na dúvida, estude as linhas 🔴.

## O que o professor mostrou (a base)

| Assunto | Onde aparece no material |
|---|---|
| Classe, objeto, atributos, métodos, `new` | slides *OrientacaoObjetos parte1 e parte2* |
| `private` / `public` / protegido, encapsulamento, getters e setters | slides parte 2 |
| Herança com `extends`, superclasse e subclasse | slides parte 2 e projeto `AulaHerança` |
| Polimorfismo (tratar a subclasse como a superclasse) e um exemplo com `abstract class Funcionario` | slides *Polimorfismo* e projeto `AulaPolimorfismo` |
| Mensagem entre objetos, associação, agregação | slides parte 2 |
| Telas `JFrame` **geradas pelo NetBeans** (usam `GroupLayout`), `JTextField`, `JButton`, `JLabel`, `JMenu`, `JRadioButton`, `JTable`, `DefaultTableModel`, `JScrollPane`, `JOptionPane` | projetos `CrudJava10*` |
| `ActionListener` (gerado pelo NetBeans) | projetos `CrudJava10*` |
| JDBC: `DriverManager.getConnection`, `PreparedStatement`, `ResultSet`, `execute()`, `executeQuery()`, `ArrayList`, `try/catch/throws` | `DAO.java` e `ManterAluno.java` (e o `.txt`) |
| `ManterAluno extends DAO` (a classe de persistência herda a de conexão) | `CrudJava10*` |

> [!decisao] A grande diferença
> O professor ligou a **tela direto ao DAO** (o botão chama o DAO). A proposta do trabalho **proíbe** isso ("não será considerado adequado concentrar toda a lógica dentro dos eventos dos botões") e exige MVC. Por isso criamos o **Controller**. Veja [[Diferenças em relação aos exemplos do professor]].

## Mapa: o que usamos que **não** está no material

Risco: 🔴 provável de ser perguntado (aparece em vários lugares ou na hora de explicar o CRUD) · 🟡 médio · 🟢 baixo.

| Recurso | Visto em aula? | Onde usamos | Risco | Nota |
|---|---|---|---|---|
| **Controller** (camada entre tela e DAO) | não | pacote `controller` | 🔴 | [[Diferenças em relação aos exemplos do professor]] |
| **Classe abstrata** + métodos `abstract` + **Template Method** | só o exemplo `abstract class Funcionario` num slide | `TelaCrud` | 🔴 | [[Classe abstrata e Template Method]] |
| **Lambda** `e -> ...` nos botões | não (o NetBeans gera classe anônima) | todas as telas | 🔴 | [[Lambda e eventos]] |
| **try-with-resources** `try (Connection ...)` | não (o professor usa `try/catch` e `fecharBanco`) | todos os DAOs | 🔴 | [[try-with-resources e JDBC além da aula]] |
| **INNER JOIN** | não aparece | `HistoricoVisualizacaoDAO`, `ContaDAO`, `PerfilDAO` | 🔴 | [[SQL além da aula]] |
| **Layouts** `BorderLayout`, `GridLayout`, `FlowLayout` (e `CardLayout`, `BoxLayout` na V3) | não (o NetBeans usa `GroupLayout`) | todas as telas | 🟡 | [[Layouts do Swing]] |
| `JComboBox`, `JPasswordField`, `JFileChooser`, `BorderFactory`, `DocumentListener` | não | `TelaCrud`, `TelaConexao`, `TelaRelatorio`, `TelaPlano` | 🟡 | [[Componentes Swing extras]] |
| **Datas**: `LocalDate`, `LocalDateTime`, `DateTimeFormatter`, `Timestamp` | não | `Conversor`, DAOs | 🟡 | [[Datas e números]] |
| **`BigDecimal`** (dinheiro) | não | `Plano`, `PlanoDAO`, `Conversor` | 🟡 | [[Datas e números]] |
| **Validação com exceção** (`IllegalArgumentException`) | não | `Conversor`, Controllers | 🟡 | [[Validação com exceções]] |
| `Map`/`LinkedHashMap`/`HashMap`, `instanceof`, generics `JComboBox<?>` | só `ArrayList` | `TelaCrud` | 🟡 | [[Coleções, generics e instanceof]] |
| **`Properties`** (`config.properties`), leitura de arquivo, `getResourceAsStream` | não | `ConnectionFactory`, `CriadorBanco` | 🟡 | [[Arquivos, Properties e script SQL]] |
| `static`, `final`, construtor `private`, classes internas, **interface** própria | só `static main` | `Conversor`, `ConnectionFactory`, `Navegador`, `Visao.Acoes` | 🟡 | [[Static, final e classes internas]] |
| `ENUM`, `DECIMAL`, `UNIQUE`, `ON DELETE CASCADE`, `BETWEEN`, `information_schema` | não | `netflix.sql`, DAOs | 🟡 | [[SQL além da aula]] |
| **Build** (`build.bat`, `javac`, `jar`, manifesto) | não | `Netflix/build.bat` | 🟢 | [[Build e jar]] |
| V3: **Java2D** (`Graphics2D`, `paintComponent`, `GradientPaint`) | não | `Tema`, `Capa`, `Visoes` | 🟡 (só na V3) | [[V3 - Java2D e desenho]] |
| V3 e V2: **`javax.swing.Timer`** e **glass pane** (fade) | não | `Navegador` | 🟡 | [[Timer, glass pane e fade]] |
| V3: **Nimbus**, `UIManager`, renderers | não | `Tema` | 🟢 | [[V3 - Nimbus, UIManager e renderers]] |
| V3: **`ImageIO`**, cache, `Scrollable`, `CardLayout` | não | `Capa`, `PainelRolavel`, `TelaCrud` | 🟢 | [[V3 - Imagens, cache e rolagem]] |

## Como estudar

1. Leia **primeiro** as linhas 🔴: [[Diferenças em relação aos exemplos do professor]], [[Classe abstrata e Template Method]], [[Lambda e eventos]], [[try-with-resources e JDBC além da aula]], [[SQL além da aula]].
2. Depois as 🟡, na ordem da tabela.
3. Cada nota termina com **"Como responder"**: uma frase pronta e curta.
4. Para o roteiro de demonstração: [[Roteiro - V2]] e [[Roteiro - V3]].

---
⬅ [[00 - Painel]] · [[Perguntas do professor]] · [[Conceitos de POO]]
