---
tags: [netflix, fora-da-aula, v3, imagens, rolagem]
---

# V3 · Imagens, cache e rolagem (`ImageIO`, `Scrollable`, `CardLayout`)

> [!info] Só na V3
> Nenhum desses recursos aparece no material do professor.

## 1. Ler a imagem da capa (`Capa.imagem`)

```java
private static final Map<String, BufferedImage> CACHE = new HashMap<>();

private static BufferedImage imagem(String nome) {
    if (!CACHE.containsKey(nome)) {
        BufferedImage img = null;
        for (String extensao : new String[]{".jpg", ".png"}) {
            File arquivo = new File("capas", nome + extensao);
            if (arquivo.isFile()) {
                try { img = ImageIO.read(arquivo); }
                catch (java.io.IOException e) { img = null; }
                break;
            }
        }
        CACHE.put(nome, img);
    }
    return CACHE.get(nome);
}
```
| Trecho | O que faz |
|---|---|
| `new File("capas", nome + ".jpg")` | Caminho `capas/NOME DO TÍTULO.jpg` **ao lado do programa** |
| `arquivo.isFile()` | O arquivo existe? |
| `ImageIO.read(arquivo)` | Lê a imagem e devolve um `BufferedImage` (a imagem na memória) |
| `catch (IOException)` | Imagem estragada: `img = null` e usa a capa desenhada |
| **`CACHE`** (`HashMap<String, BufferedImage>`) | Guarda o que já foi lido (**inclusive `null` = "não existe"**), para não reler o disco a cada vez que o Swing redesenha (muitas vezes por segundo) |
| `static` | A cache é **uma só** para todo o programa |

- Se a imagem não existir, o sistema **funciona do mesmo jeito**: `Capa.desenhar` faz um degradê com o nome do título. A pasta `capas` **não** foi para o GitHub (direitos autorais).

### Desenhar em modo "cover"
```java
double escala = Math.max((double) w / img.getWidth(), (double) h / img.getHeight());
g2.drawImage(img, x + (w - lw) / 2, y + (h - lh) / 2, lw, lh, null);
```
- `Math.max` das duas escalas: a imagem **preenche** o retângulo inteiro (corta o que sobra); centralizada. `(double)` evita divisão inteira que arredondaria para 0.

## 2. Rolagem que acompanha a largura (`PainelRolavel implements Scrollable`)

- Um `JPanel` dentro de um `JScrollPane` fica com a **largura que ele quer** e passa a rolar na horizontal. Queríamos só rolagem vertical.
- `implements Scrollable` (**interface** do Swing): o `JScrollPane` pergunta ao painel como rolar. O método-chave:
```java
@Override
public boolean getScrollableTracksViewportWidth() { return true; }  // a largura segue a da janela
```
- `QuebraLayout extends FlowLayout`: sobrescreve `preferredLayoutSize` para o painel **crescer em altura** quando os itens quebram de linha (o `FlowLayout` comum não aumenta a altura, e os de baixo sumiriam). Usado nos avatares dos perfis.

## 3. Alternar "Visual | Tabela" (`CardLayout`)

```java
CardLayout cartas = new CardLayout();
JPanel conteudo = new JPanel(cartas);
conteudo.add(visao, "visual");
conteudo.add(Tema.rolagem(tabela), "tabela");
btnTabela.addActionListener(e -> cartas.show(conteudo, "tabela"));
```
- `CardLayout` empilha painéis e mostra **um por vez**; cada um tem um **nome** (`"visual"`, `"tabela"`). `cartas.show(painel, nome)` troca. A visão e a tabela usam o **mesmo `DefaultTableModel`**.

## 4. A visão avisa a tela por uma interface

- `Visao` (abstrata) recebe um `Visao.Acoes` (interface). Quando o usuário clica num cartão, a visão chama `acoes.selecionar(linha)`; a `TelaCrud` implementa e seleciona a linha da tabela (o que dispara o mesmo código que já preenche o formulário). **Nenhuma duplicação de lógica.** Ver [[Static, final e classes internas]].

> [!codigo] Como responder
> **"Para que serve a cache de imagens?"** — "O Swing redesenha a tela várias vezes por segundo. Sem a cache, leríamos o arquivo do disco toda vez. Guardamos num `HashMap` e só lemos na primeira."
>
> **"E se a imagem não existir?"** — "O sistema não quebra: a classe `Capa` desenha um pôster em código com degradê, um 'N' vermelho e o título."

---
⬅ [[Fora da aula - Índice]] · [[Início e capas]] · [[Visões das abas]]
