---
tags: [netflix, fora-da-aula, poo, static]
---

# `static`, `final`, construtor privado e classes internas

> [!info] O que o professor mostrou
> `static` só em `public static void main`. **Não mostrou métodos/atributos estáticos, `final`, construtor privado, classe aninhada nem `interface`.**

## `static`: pertence à classe, não ao objeto

Um membro `static` existe **uma vez só**, na classe; chama-se `Classe.metodo()` sem `new`.

```java
Conversor.paraInt("12", "Idade");              // sem new Conversor()
ConnectionFactory.getConnection();
Navegador.ir(this, new TelaPlano());
```

| Classe | Por que é toda estática |
|---|---|
| `Conversor` | Só tem funções de conversão; não guarda estado |
| `ConnectionFactory` | Os dados de conexão (servidor, porta, usuário, senha) são **um só para o programa inteiro** |
| `CriadorBanco` | Só executa ações no banco |
| `Navegador` | Só troca de tela |

### Construtor `private`
```java
private Conversor() { }
```
Impede `new Conversor()`: a classe só tem métodos estáticos, então criar objeto não faz sentido. É uma boa prática (classe utilitária).

## `final`

| Uso | Exemplo | Significa |
|---|---|---|
| Atributo `final` | `private final PlanoDAO dao = new PlanoDAO();` | A variável **não pode ser trocada** depois de criada |
| `static final` | `private static final String BANCO = "netflix";` | **Constante**, escrita em MAIÚSCULAS |
| Classe `final` | `public final class Navegador` | **Ninguém pode herdar** dela |

## Classe interna (aninhada)

```java
public final class Navegador {
    private static final class Veu extends JPanel { ... }   // só o Navegador usa
}
```
- Uma classe **dentro** de outra. `private`: só a classe de fora enxerga.
- `static`: não precisa de um objeto `Navegador` para existir.
- No V3: `Tema.Botao`, `Visoes.Perfis`, `TelaPrincipal.CartaDeCapa` e `Destaque` seguem a mesma ideia: peças pequenas que só fazem sentido dentro da classe-mãe.
- `Destaque` (V3) **não** é `static`: precisa chamar `abrirTitulos()` da `TelaPrincipal` que a contém.

## Classe anônima

```java
campoTelas.getDocument().addDocumentListener(new DocumentListener() {
    @Override public void insertUpdate(DocumentEvent e) { atualizarDescricao(); }
    ...
});
```
Cria **na hora** uma classe sem nome que implementa a interface. O NetBeans gera isso nos botões; nós usamos quando a interface tem mais de um método.

## `interface` própria (V3)

```java
public interface Acoes {
    void selecionar(int linha);
    void remover(int linha);
    void novo();
}
```
- **Interface** = lista de métodos **sem corpo** que quem "assina" tem que implementar. É um contrato.
- `Visao.Acoes` é o contrato pelo qual a visão **avisa** a tela. A `TelaCrud` implementa na classe interna `AcoesDaTela`. Assim a visão **não conhece** a `TelaCrud` (baixo acoplamento).
- Diferença para classe abstrata: a interface não tem atributos nem código; uma classe pode implementar várias, mas herdar só de uma.
- O slide do professor cita "interface" como conceito (conjunto de mensagens), mas **nenhum exemplo usa a palavra-chave** `interface`.

## `this` e `super`

- `this`: o próprio objeto (`Navegador.ir(this, ...)` = "esta janela").
- `super(...)`: chama o construtor da mãe (`super("Planos", colunas)`). O professor mostra `this.` nos setters; `super(` não aparece.

> [!codigo] Como responder
> **"Por que `Conversor` tem tudo `static`?"** — "Porque são só funções utilitárias, sem estado. Não faz sentido criar um objeto para converter um texto; chamamos direto `Conversor.paraInt(...)`. O construtor é privado para ninguém instanciar."
>
> **"O que é `final`?"** — "Atributo: não troca de valor. Classe: não pode ser herdada. Método: não pode ser sobrescrito."

---
⬅ [[Fora da aula - Índice]] · [[Visibilidade]] · [[Conversor]] · [[Classe abstrata e Template Method]]
