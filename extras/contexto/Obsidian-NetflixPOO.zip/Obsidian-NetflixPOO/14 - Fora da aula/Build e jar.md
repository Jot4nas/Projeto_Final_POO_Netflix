---
tags: [netflix, fora-da-aula, build, jar]
---

# Build e `.jar` (`build.bat`)

> [!info] O que o professor mostrou
> Rodar pelo NetBeans (botão Run) e adicionar o driver do MySQL às bibliotecas do projeto. **Não mostrou gerar `.jar`.** Fizemos o `Netflix.jar` para o grupo abrir com dois cliques, sem IDE.

## O que o `build.bat` faz (passo a passo)

| # | Comando | O que faz |
|---|---|---|
| 1 | lista todos os `.java` em `build\fontes.txt` | O `javac` precisa receber a lista de arquivos |
| 2 | `javac -encoding UTF-8 --release 11 -cp lib\mysql-connector-j-9.3.0.jar -d build\classes @build\fontes.txt` | **Compila**. `-cp`: onde está o driver. `-d`: pasta de saída dos `.class`. `--release 11`: roda em qualquer Java 11 ou mais novo. `@arquivo`: lê a lista de fontes |
| 3 | `copy sql\netflix.sql build\classes\` | Coloca o script **dentro** do jar (o `CriadorBanco` lê de lá) |
| 4 | `jar xf ..\..\lib\mysql-connector-j-9.3.0.jar` | **Descompacta o driver** na pasta de classes, para o jar final conter tudo (ninguém configura classpath) |
| 5 | escreve `Main-Class: Main` em `manifest.txt` | O **manifesto** diz qual classe tem o `main` |
| 6 | `jar cfm ..\Netflix.jar build\manifest.txt -C build\classes .` | **Empacota**: `c` cria, `f` arquivo de saída, `m` usa o manifesto |

Resultado: `Netflix.jar` com as nossas classes, o driver JDBC e o `netflix.sql`.

## Por que o jar abre com dois cliques?

O Windows associa `.jar` ao Java; ele lê o manifesto, acha `Main-Class: Main` e executa o `main`. Se nada acontece, o `Abrir Netflix.bat` roda `java -jar Netflix.jar` e **mostra o erro** (normalmente falta instalar o Java).

## Detalhes úteis na apresentação

- O `build` só precisa rodar de novo se alguém mudar o código em `src`.
- Precisa do **JDK** (tem `javac`), não só do Java para executar (JRE).
- Com o app aberto, o `.jar` fica **travado** no Windows: feche o programa antes de gerar de novo.
- `config.properties` é criado **ao lado do jar** na primeira conexão (não fica dentro dele).

> [!codigo] Como responder
> **"Como gerou esse `.jar`?"** — "Pelo `build.bat`: compila com `javac`, copia o script SQL e o driver do MySQL para a pasta de classes e empacota com `jar`, indicando no manifesto que a classe principal é `Main`."

---
⬅ [[Fora da aula - Índice]] · [[Gerar a build]] · [[Rodar e testar]]
