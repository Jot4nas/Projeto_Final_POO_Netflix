---
tags: [netflix, fora-da-aula, util, datas]
---

# Datas e números (`LocalDate`, `LocalDateTime`, `BigDecimal`)

> [!info] O que o professor mostrou
> `int` e `String` (idade, nome, e-mail). **Nenhum exemplo usa data ou valor em dinheiro.** Nosso banco tem `DATE`, `DATETIME` e `DECIMAL`, então foi preciso usar as classes abaixo.

## Datas: do texto digitado ao MySQL

O usuário digita `2025-06-01 20:00` (texto). Caminho até o banco:

```
texto  --Conversor.paraDataHora-->  LocalDateTime  --Timestamp.valueOf-->  java.sql.Timestamp  --ps.setTimestamp-->  DATETIME
```

| Tipo | O que guarda | Onde |
|---|---|---|
| `LocalDate` | só a data (2025-06-01) | `plano.data_criacao`, `perfil.data_criacao` |
| `LocalDateTime` | data + hora | `historico.data_inicio`, `data_ultima_visualizacao`, `conta.data_cadastro` |
| `java.sql.Date` / `Timestamp` | os mesmos, no formato que o JDBC entende | só dentro dos DAOs |

```java
private static final DateTimeFormatter DATA_HORA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

public static LocalDateTime paraDataHora(String texto, String campo) {
    try {
        return LocalDateTime.parse(obrigatorio(texto, campo), DATA_HORA);
    } catch (DateTimeParseException e) {
        throw new IllegalArgumentException("O campo '" + campo + "' deve estar no formato aaaa-mm-dd hh:mm.");
    }
}
```
| Trecho | O que faz |
|---|---|
| `DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")` | Define o formato: ano-mês-dia hora:minuto (`MM` = mês, `mm` = minuto) |
| `LocalDateTime.parse(texto, formato)` | Converte o texto em objeto; se o texto estiver errado lança `DateTimeParseException` |
| `catch ... throw new IllegalArgumentException(...)` | Troca o erro técnico por uma mensagem clara para o usuário |
| `LocalDate.parse(texto)` (sem formato) | Aceita direto `aaaa-mm-dd`, o padrão ISO |
| `LocalDate.now()` / `LocalDateTime.now()` | Data/hora de hoje (`Conversor.hoje()` e `agora()`) |
| `dataHora.format(DATA_HORA)` | O caminho inverso: objeto → texto para a tabela |

- No DAO: `ps.setDate(7, Date.valueOf(p.getDataCriacao()))` e `ps.setTimestamp(...)`; ao ler, `rs.getTimestamp("data_inicio").toLocalDateTime()`.
- **Por que `LocalDate` e não `Date`/`SimpleDateFormat`?** São as classes modernas (Java 8+): imutáveis e sem problema de fuso nas contas.

### Fuso horário (detalhe que já deu bug)
Na `ConnectionFactory`: `connectionTimeZone=LOCAL`. Sem isso, o driver usava um fuso fixo e o horário aparecia deslocado (20:00 virava 23:00 em outro computador). Ver [[ConnectionFactory]].

## Dinheiro: `BigDecimal`

```java
private BigDecimal valorMensal;        // Plano.java
public static BigDecimal paraDecimal(String texto, String campo) {
    return new BigDecimal(obrigatorio(texto, campo).replace(',', '.'));
}
ps.setBigDecimal(3, p.getValorMensal());
```
- `double` erra arredondamento (`0.1 + 0.2` = `0.30000000000000004`). Em dinheiro isso não pode acontecer, então usamos `BigDecimal`, que é **exato**, e `DECIMAL(6,2)` no banco.
- `.replace(',', '.')`: aceita "39,90" e "39.90".
- Regra no `PlanoController`: `valor.signum() <= 0` (sinal do número) recusa valor zero ou negativo.

## Números de formulário

`Conversor.paraInt` usa `Integer.parseInt` dentro de `try/catch (NumberFormatException)`. Todo valor da tela chega como `String`; quem converte e valida é o Controller (via `Conversor`).

> [!codigo] Como responder
> **"Por que `BigDecimal` no valor do plano?"** — "Porque `double` tem erro de arredondamento e é impróprio para dinheiro. `BigDecimal` é exato e combina com o `DECIMAL(6,2)` do MySQL."
>
> **"Como a data digitada vira data do banco?"** — "O `Conversor` lê o texto com `LocalDateTime.parse` e um formato; o DAO converte para `Timestamp.valueOf` e grava com `setTimestamp`."

---
⬅ [[Fora da aula - Índice]] · [[Conversor]] · [[Pacote model]] · [[Validação com exceções]]
