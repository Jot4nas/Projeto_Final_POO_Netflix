---
tags: [netflix, fora-da-aula, arquivos, properties]
---

# Arquivos, `Properties` e o script SQL

> [!info] O que o professor mostrou
> A URL, o usuário e a senha **escritos no código** (`String senha = ""`). **Não mostrou ler/gravar arquivo, nem `Properties`.** Nosso sistema pede a senha numa tela e a guarda num arquivo para não digitar toda vez.

## 1. `config.properties` (`ConnectionFactory`)

Um `.properties` é um arquivo de texto `chave=valor`. O Java lê e grava com a classe `Properties`.

### Ler
```java
Properties config = new Properties();
try (FileInputStream arquivo = new FileInputStream(ARQUIVO_CONFIG)) {
    config.load(arquivo);
    servidor = config.getProperty("servidor", servidor);
    porta = Integer.parseInt(config.getProperty("porta", String.valueOf(porta)));
    ...
} catch (IOException | NumberFormatException e) {
    // Arquivo inexistente ou invalido: ficam os valores padrao.
}
```
| Trecho | O que faz |
|---|---|
| `new Properties()` | Cria o "dicionário" chave → texto |
| `new FileInputStream("config.properties")` | Abre o arquivo para leitura (fica ao lado do `.jar`) |
| `config.load(arquivo)` | Lê todas as linhas `chave=valor` |
| `getProperty("servidor", servidor)` | Devolve o valor, ou o **padrão** (2º argumento) se a chave não existir |
| `catch (IOException \| NumberFormatException e)` | Arquivo não existe (1ª execução) ou porta inválida → segue com os valores padrão |

### Gravar
```java
Properties config = new Properties();
config.setProperty("servidor", servidor);
config.setProperty("porta", String.valueOf(porta));
...
try (FileOutputStream arquivo = new FileOutputStream(ARQUIVO_CONFIG)) {
    config.store(arquivo, "Conexao com o MySQL (gerado pelo sistema Netflix)");
}
```
- `setProperty` guarda; `store` escreve o arquivo com o comentário no topo. `String.valueOf(porta)` converte o `int` em texto (a `Properties` só guarda texto).

> [!warning] Detalhe de segurança
> A senha fica em **texto puro** no `config.properties`. Por isso o arquivo está no `.gitignore` (não vai para o GitHub). É assim em projetos simples; num sistema real usaríamos criptografia.

## 2. O script SQL dentro do `.jar` (`CriadorBanco`)

O `netflix.sql` é copiado para dentro do `Netflix.jar` na build. O programa lê de lá:

```java
try (InputStream entrada = CriadorBanco.class.getResourceAsStream("/netflix.sql")) {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    entrada.transferTo(bytes);
    String texto = bytes.toString(StandardCharsets.UTF_8.name());
    ...
```
| Trecho | O que faz |
|---|---|
| `CriadorBanco.class.getResourceAsStream("/netflix.sql")` | Abre um arquivo que está **dentro do jar** (o `/` inicial = raiz do jar) |
| `ByteArrayOutputStream` | Um "balde" de bytes em memória |
| `entrada.transferTo(bytes)` | Despeja o arquivo todo no balde |
| `bytes.toString(UTF_8)` | Converte os bytes em texto, entendendo acentos (UTF-8) |

### Tirar os comentários e executar
```java
StringBuilder semComentarios = new StringBuilder();
for (String linha : texto.split("\n")) {
    int comentario = linha.indexOf("--");
    semComentarios.append(comentario >= 0 ? linha.substring(0, comentario) : linha).append('\n');
}
```
- Corta tudo depois de `--` em cada linha (comentário SQL). `StringBuilder` monta texto sem criar uma `String` nova a cada junção.

```java
for (String comando : script.split(";")) {
    if (!comando.trim().isEmpty()) { st.execute(comando); }
}
```
- O JDBC executa **um comando por vez**. Cortamos o script em cada `;` e rodamos em sequência com `Statement`.
- Limitação conhecida: um `;` dentro de um texto do script quebraria o corte. O nosso script não tem.

### Quando ele roda
`criarSeNaoExistir()`: só se o banco `netflix` **não existe** ou está **vazio**. Banco com tabelas é reaproveitado e nunca apagado. Só o botão **Restaurar dados** apaga.

## 3. Salvar o relatório em `.txt` (`RelatorioController`)

```java
Files.write(Path.of(caminho), texto.toString().getBytes(StandardCharsets.UTF_8));
```
- `Path.of(caminho)`: o caminho escolhido no `JFileChooser`. `Files.write` grava os bytes do texto; `UTF_8` evita que "concluído" saia com símbolo estranho.

> [!codigo] Como responder
> **"Onde fica a senha do MySQL?"** — "Não está no código. A tela de conexão pede, a `ConnectionFactory` guarda em atributos estáticos e grava no `config.properties` com `Properties.store`. Na próxima vez lemos com `Properties.load`."
>
> **"Como o banco é criado sozinho?"** — "O `CriadorBanco` lê o `netflix.sql` de dentro do jar, tira os comentários, corta em cada `;` e executa os comandos um a um."

---
⬅ [[Fora da aula - Índice]] · [[ConnectionFactory]] · [[CriadorBanco]] · [[Gerar a build]]
