---
tags: [netflix, fora-da-aula, colecoes, generics]
---

# Coleções, generics e `instanceof`

> [!info] O que o professor mostrou
> `ArrayList` (ex.: lista de `Aluno`) e `List<...>`. **`Map`, `LinkedHashMap`, `HashMap`, `instanceof` e `JComboBox<?>` não aparecem.**

## Generics: o `<...>`

- `List<Plano>`: lista que só aceita `Plano`. Sem isso teríamos de converter cada item.
- `JComboBox<String>`: combo cujos itens são `String` (os textos "3 - Premium").
- `JComboBox<?>`: combo de **tipo qualquer** (o `?` é "curinga"). Usamos quando a tela guarda vários combos num mesmo campo sem saber o tipo.

## `Map`: pares chave → valor

```java
private final Map<String, JComponent> campos = new LinkedHashMap<>(); // rótulo -> componente
```
- Cada campo do formulário é guardado com o **rótulo** como chave: `campos.put("Nome", textField)`.
- `campos.get("Nome")` devolve o componente. É assim que `valor("Nome")` acha o campo.
- **`LinkedHashMap`** (e não `HashMap`): mantém a **ordem de inserção**. Precisamos disso porque ao clicar numa linha da tabela copiamos as colunas 1, 2, 3... **na ordem dos campos**.

```java
Map<JComboBox<?>, Object> escolhidos = new HashMap<>();
```
- Em `recarregar`: antes de recarregar os combos, guardamos qual item cada combo tinha; depois restauramos. Aqui a chave é o próprio combo e a ordem não importa, então `HashMap`.

```java
for (Map.Entry<JComboBox<?>, Object> e : escolhidos.entrySet()) {
    e.getKey().setSelectedItem(e.getValue());
}
```
- `entrySet()`: percorre cada par. `e.getKey()` é o combo; `e.getValue()` é o item guardado.

## `instanceof` e cast

```java
protected String valor(String rotulo) {
    JComponent c = campos.get(rotulo);
    if (c instanceof JComboBox) {
        Object item = ((JComboBox<?>) c).getSelectedItem();
        return item == null ? "" : item.toString();
    }
    return ((JTextField) c).getText();
}
```
| Trecho | O que faz |
|---|---|
| `JComponent c` | Tipo **genérico**: o mapa guarda campos de texto **e** combos |
| `c instanceof JComboBox` | Pergunta "este objeto **é** um combo?" |
| `((JComboBox<?>) c)` | **Cast**: "trate como combo" (para chamar `getSelectedItem`) |
| `item == null ? "" : item.toString()` | **Operador ternário**: `condição ? valorSeVerdade : valorSeFalso` |
| `((JTextField) c).getText()` | Se não é combo, é campo de texto |

Isso é **polimorfismo + cast**: todo componente é um `JComponent`, mas cada um se lê de um jeito.

## `for` aprimorado

`for (Plano p : controller.listar())`: "para cada plano da lista". É o mesmo que um `for` com índice, mais curto. Usamos em todas as telas para montar as linhas da tabela.

## `ArrayList` x `List`

Declaramos `List<Plano> lista = new ArrayList<>();`: o tipo da variável é a **interface** `List`, o objeto é `ArrayList`. Assim dá para trocar a implementação sem mexer no resto.

> [!codigo] Como responder
> **"Por que `LinkedHashMap`?"** — "Porque a ordem em que os campos foram adicionados importa: as colunas da tabela seguem a mesma ordem dos campos, e ao clicar numa linha copiamos coluna a coluna."
>
> **"O que é esse `instanceof`?"** — "Verifica o tipo real do componente. Os campos são `JTextField` ou `JComboBox`; para ler o valor cada um usa um método diferente."

---
⬅ [[Fora da aula - Índice]] · [[TelaCrud]] · [[Polimorfismo]]
