---
tags: [netflix, fora-da-aula, mvc]
---

# Diferenças em relação aos exemplos do professor

*Os projetos `CrudJava10*` do professor e o nosso fazem o mesmo (CRUD com JDBC), mas organizados de forma diferente. Se ele comparar, é preciso saber justificar.*

## Lado a lado

| Ponto | Exemplo do professor (`CrudJava10`) | Nosso sistema | Por que mudamos |
|---|---|---|---|
| Camadas | `visao` (telas) → `entidade` (`DAO`, `ManterAluno`) | `view` → `controller` → `dao` → MySQL, com `model` | A proposta exige **MVC** e proíbe lógica nos botões |
| Quem valida dados | a própria tela (ex.: `JOptionPane` dentro do DAO: "E-mail já cadastrado") | o **Controller** (`Conversor` + regras) | O DAO só fala com o banco; a tela só mostra |
| Conexão | `DAO.abrirBanco()` guarda `con` como atributo e `fecharBanco()` fecha só o `ps` | `ConnectionFactory.getConnection()` devolve uma conexão nova, fechada pelo `try-with-resources` | Evita conexão esquecida aberta |
| DAO e conexão | `ManterAluno extends DAO` (**herança**) | os DAOs **usam** a `ConnectionFactory` (**composição**/uso) | A conexão não é "um tipo de DAO"; é um serviço usado por eles |
| Driver | `Class.forName("com.mysql.jdbc.Driver")` | **não precisa**: o driver 9.x se registra sozinho | Em JDBC 4+ o `DriverManager` descobre o driver no `.jar` |
| Telas | geradas pelo NetBeans (`GroupLayout`, uma classe grande por tela) | uma tela-base `TelaCrud` (abstrata) e filhas pequenas | Evita repetir o mesmo código 5 vezes |
| Entidade | `Aluno` com atributos e getters/setters | `Plano`, `Conta`, `Perfil`, `Titulo`, `HistoricoVisualizacao` | Igual: é o mesmo conceito de **model** |
| Mensagens | `JOptionPane` espalhado | o Controller **devolve um texto** e a tela mostra | Quem decide a mensagem é a regra, não o botão |

> [!regra] Frase da proposta que justifica o Controller
> "Não será considerado adequado concentrar toda a lógica do sistema diretamente dentro dos eventos dos botões do JFrame." Nosso botão só faz `mostrarResultado(inserir())`.

## O caminho de um clique, comparado

**Professor:** botão → `ManterAluno.inserir(aluno)` → SQL.

**Nós:** botão → `TelaPlano.inserir()` → `PlanoController.inserir(textos)` → valida com `Conversor` → `PlanoDAO.inserir(Plano)` → `PreparedStatement` → MySQL → mensagem volta até a tela.

## O que **continua igual** ao material (pode usar como apoio)

- `PreparedStatement` com `?` e `ps.setString(...)`, `ps.setInt(...)`.
- `ResultSet` e o laço `while (rs.next())`.
- Classe de entidade com atributos `private` e getters/setters (**encapsulamento**).
- `extends` (herança): `TelaPlano extends TelaCrud`, como `ManterAluno extends DAO`.
- `ArrayList` para devolver listas.

> [!codigo] Como responder
> **"Por que vocês não chamaram o DAO direto na tela, como nos exemplos?"** — "Porque a proposta exige MVC e diz que a lógica não pode ficar nos botões. O botão só chama o Controller; o Controller valida e chama o DAO; o DAO só fala SQL."

---
⬅ [[Fora da aula - Índice]] · [[Pacote controller]] · [[Pacote view]] · [[Conceitos de DAO e JDBC]]
