---
tags: [netflix, fora-da-aula, v3, java2d]
---

# V3 · Java2D e desenho (`Graphics2D`, `paintComponent`)

> [!info] Só na V3 (front-end)
> O professor **não mostrou desenho próprio**. Na V3, botões, cartões, avatares, ícones e capas são **desenhados em código**. Cada um continua sendo um componente Swing comum (`JButton`, `JPanel`) com o método de desenho **sobrescrito**.

## A ideia em 4 passos

1. Criamos uma classe que **herda** de um componente (`extends JButton`, `extends JPanel`).
2. **Sobrescrevemos** `paintComponent(Graphics g)`: o método que o Swing chama sempre que precisa desenhar.
3. Dentro dele pegamos um `Graphics2D` e desenhamos formas, cores e texto.
4. Quando algo muda (mouse em cima, seleção), chamamos `repaint()` e o Swing chama `paintComponent` de novo.

É **herança + sobrescrita** (slides do professor) aplicadas ao desenho.

## Linha a linha: o botão `Tema.Botao`

```java
@Override
protected void paintComponent(Graphics g) {
    Graphics2D g2 = (Graphics2D) g.create();
    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    boolean pressionado = getModel().isPressed();
    boolean sobre = getModel().isRollover();
    int w = getWidth(), h = getHeight(), arco = 10;
    ... escolhe a cor `fundo` conforme o tipo e o estado ...
    g2.setColor(fundo);
    g2.fillRoundRect(0, 0, w, h, arco, arco);
    ...
    g2.dispose();
    super.paintComponent(g);   // desenha o texto por cima
}
```
| Linha | O que faz |
|---|---|
| `(Graphics2D) g.create()` | `Graphics2D` é a versão **moderna** de `Graphics` (cast). `create()` faz uma **cópia**, para não bagunçar as configurações do original |
| `setRenderingHint(KEY_ANTIALIASING, ...)` | Liga o **antialiasing** (suaviza as bordas serrilhadas) |
| `getModel().isPressed()` / `isRollover()` | Estado do botão: apertado / mouse em cima |
| `getWidth()`, `getHeight()` | Tamanho atual do componente |
| `g2.setColor(cor)` | Escolhe a cor da "tinta" |
| `fillRoundRect(x, y, w, h, arcoW, arcoH)` | **Preenche** um retângulo com cantos arredondados |
| `drawRoundRect(...)` | Só o **contorno** |
| `new BasicStroke(2f)` | Espessura da linha do contorno |
| `isFocusOwner()` | O botão está com o foco do teclado? Desenhamos um anel branco (acessibilidade) |
| `g2.dispose()` | Libera a cópia |
| `super.paintComponent(g)` | Chama o método da mãe: desenha o **texto** do botão |
| No construtor: `setContentAreaFilled(false)`, `setBorderPainted(false)`, `setOpaque(false)` | Desligam o desenho padrão: quem pinta somos nós |

## Outras ferramentas de desenho usadas

| Recurso | O que faz | Onde |
|---|---|---|
| **`GradientPaint`** | Degradê entre duas cores (`new GradientPaint(x1,y1,cor1, x2,y2,cor2)`) | cabeçalho, capas desenhadas, banner do Início |
| **`Color(r,g,b,alfa)`** | Cor com transparência | escurecer a capa do fundo |
| **`RoundRectangle2D` + `g2.clip(forma)`** | **Recorta** a área onde se pode desenhar (cantos arredondados na imagem) | `Capa.desenhar` |
| **`Path2D`** | Desenha um caminho com `moveTo`/`lineTo` | `Icone` (casa, cartão...) |
| **`g2.translate(x, y)` e `g2.scale(...)`** | Move e escala o desenho: o ícone é feito numa grade 24×24 e escalado para qualquer tamanho | `Icone.desenhar` |
| **`FontMetrics`** | Mede o texto (`stringWidth`) para centralizar e **cortar com "…"** | `cortar`, `quebrar` |
| **`Font.deriveFont`** | Cria variação de uma fonte (negrito, tamanho) | `Tema` |
| **`hashCode()`** do nome | Número fixo para o mesmo texto → a mesma cor sempre (`Capa.cor`) | capas sem imagem |

### O `hashCode` na capa sem imagem
```java
return CORES[Math.abs(nome.hashCode()) % CORES.length];
```
- `"Stranger Things".hashCode()` sempre dá o mesmo número; `% CORES.length` (resto da divisão) escolhe uma das 8 cores. Um título **sempre** tem a mesma cor, sem guardar nada.

## Onde está cada desenho

| Classe | Desenha |
|---|---|
| `Tema` | botões, cabeçalho da tela, "chips" do relatório, barras de rolagem |
| `Capa` | pôster (imagem ou degradê + "N" + título) |
| `Icone` | ícones em linhas (Path2D) |
| `Visoes` | avatares, cartões de conta, linhas do histórico, tabela comparativa de planos |
| `TelaPrincipal` | banner "em destaque" e capas (`CartaDeCapa`) |

> [!warning] Cuidado ao explicar
> Isso é **só aparência**. Controller e DAO não sabem que o visual mudou; os desenhos **leem o `DefaultTableModel`**, o mesmo da tabela.

> [!codigo] Como responder
> **"Como você desenhou esses botões?"** — "Criei uma classe que herda de `JButton` e sobrescrevi o `paintComponent`. Dentro dele uso o `Graphics2D` para preencher um retângulo arredondado com a cor certa para o estado (normal, mouse em cima, pressionado) e chamo o `super` para desenhar o texto por cima."
>
> **"O que é `repaint()`?"** — "Pede ao Swing para desenhar o componente de novo (por exemplo, quando o mouse entra)."

---
⬅ [[Fora da aula - Índice]] · [[Tema]] · [[Visões das abas]] · [[V3 - Tema]]
