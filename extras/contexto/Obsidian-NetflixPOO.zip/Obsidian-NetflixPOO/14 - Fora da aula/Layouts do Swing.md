---
tags: [netflix, fora-da-aula, swing, layout]
---

# Layouts do Swing

> [!info] O que o professor mostrou
> Telas feitas **arrastando componentes no NetBeans**, que gera código com `GroupLayout` (centenas de linhas automáticas). **Nenhum exemplo escreve layout à mão** (`BorderLayout`, `GridLayout`, `FlowLayout`).

## O que é um layout

Um *LayoutManager* decide **onde e com que tamanho** cada componente fica dentro de um painel, e se adapta quando a janela muda de tamanho. Escrevemos no código em vez de arrastar.

## Os que usamos

| Layout | Como organiza | Onde usamos |
|---|---|---|
| **`BorderLayout`** | 5 regiões: `NORTH`, `SOUTH`, `EAST`, `WEST`, `CENTER`. O centro ocupa o que sobrar | O **`JFrame`** já usa por padrão. `TelaCrud`: formulário no `NORTH`, tabela no `CENTER`, botões no `SOUTH` |
| **`GridLayout(linhas, colunas, espaçoH, espaçoV)`** | Grade com células **do mesmo tamanho** | Formulário (`GridLayout(0, 2, 5, 5)`: rótulo + campo, quantas linhas precisar), menu `TelaPrincipal` (`GridLayout(0, 1, 8, 8)`: um botão por linha) |
| **`FlowLayout`** | Um ao lado do outro, quebra para a linha de baixo | Linha de botões Inserir/Atualizar/Remover/Limpar; filtros do relatório |
| **`CardLayout`** (V3) | Empilha painéis e mostra **um por vez** | Alternar "Visual | Tabela" nas abas |
| **`BoxLayout`** (V3) | Em fila vertical ou horizontal | Lista do histórico, botões do destaque |

## Linha a linha: `TelaCrud` (V2)

```java
add(topo, BorderLayout.NORTH);               // barra de navegação + formulário
add(new JScrollPane(tabela), BorderLayout.CENTER); // tabela com rolagem
add(painelBotoes, BorderLayout.SOUTH);       // botões
```
- `add(componente, região)`: coloca o componente numa região do `BorderLayout` do JFrame.
- `JScrollPane` envolve a tabela e dá as barras de rolagem.

```java
private final JPanel painelForm = new JPanel(new GridLayout(0, 2, 5, 5));
```
- `0` linhas = "quantas forem necessárias"; `2` colunas; `5, 5` = espaço horizontal e vertical entre as células.
- `adicionarCampo(rotulo, campo)` faz `painelForm.add(new JLabel(rotulo)); painelForm.add(campo);`, então cada par ocupa uma linha.

```java
JPanel topo = new JPanel(new BorderLayout());
topo.add(new BarraNavegacao(this, nomeNaBarra(), null), BorderLayout.NORTH);
topo.add(painelForm, BorderLayout.CENTER);
```
- **Painéis aninhados:** um `BorderLayout` dentro do `NORTH` de outro. É assim que se monta uma tela sem arrastar nada.

## `pack()`, `setSize` e `setLocationRelativeTo`

- `pack()`: ajusta a janela ao tamanho que os componentes pedem (`TelaPrincipal`, `TelaConexao`).
- `setSize(950, 600)`: tamanho fixo (telas de cadastro).
- `setLocationRelativeTo(null)`: centraliza na tela.

> [!codigo] Como responder
> **"Por que não usaram o editor do NetBeans?"** — "Para ter controle do layout no código e reaproveitar a mesma tela-base nas cinco telas. Escrevemos com `BorderLayout`, `GridLayout` e `FlowLayout`, que se ajustam sozinhos ao tamanho da janela."
>
> **"O que o `BorderLayout.CENTER` faz?"** — "Ocupa todo o espaço que sobrar depois das outras regiões; por isso a tabela cresce com a janela."

---
⬅ [[Fora da aula - Índice]] · [[Conceitos de Swing]] · [[TelaCrud]]
