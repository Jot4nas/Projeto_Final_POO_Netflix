---
tags: [netflix, codigo, util, classe]
---

# ConnectionFactory

*Seção 3.1: ConnectionFactory (mudou na V2)* · Pasta: [[Pacote util]]


**Para que serve:** é a "fábrica" de conexões JDBC. Os dados de acesso (servidor, porta, usuário, senha) ficam em **um único lugar**. Os DAOs só chamam `ConnectionFactory.getConnection()`. **Na V2 esses dados não ficam mais fixos no código:** vêm da [[TelaConexao]] e são salvos no `config.properties`.

**Linha a linha**

- `import java.io.FileInputStream / FileOutputStream / IOException`: ler e gravar o arquivo de configuração.
- `import java.sql.Connection / DriverManager / SQLException`: `Connection` é a conexão aberta; `DriverManager` sabe abrir conexões a partir de uma URL; `SQLException` é o erro de banco.
- `import java.util.Properties`: classe do Java que lê/grava arquivos no formato `chave=valor`.
- `private static final String BANCO = "netflix";`: nome do banco; constante (`final`), da classe (`static`), só esta classe lê (`private`).
- `private static final String ARQUIVO_CONFIG = "config.properties";`: nome do arquivo de configuração, criado ao lado do `Netflix.jar`.
- `private static String servidor = "localhost"; porta = 3306; usuario = "root"; senha = "";`: valores **padrão**. Não são `final` porque mudam quando o usuário conecta.
- `private ConnectionFactory() { }`: construtor **privado**: a classe só tem métodos estáticos, ninguém precisa dar `new`.
- `public static Connection getConnection() throws SQLException`: abre a conexão com o banco `netflix`. `DriverManager.getConnection(montarUrl(BANCO), usuario, senha)` procura o driver que entende a URL e conecta. Se o MySQL estiver desligado ou a senha errada, lança `SQLException`, **que o DAO repassa e o Controller captura** (na V1 virava `RuntimeException`; agora o caminho do erro é o mesmo de qualquer erro de banco).
- `getConnectionServidor()`: conecta ao **servidor** sem escolher banco (URL termina em `/`). É usada para criar o banco `netflix` quando ele ainda não existe.
- `montarUrl(String banco)`: monta `jdbc:mysql://servidor:porta/banco?useSSL=false&allowPublicKeyRetrieval=true&connectionTimeZone=LOCAL&forceConnectionTimeZoneToSession=false`. `useSSL=false` desliga a criptografia (desnecessária localmente), `allowPublicKeyRetrieval=true` evita um erro comum de login no MySQL 8, `connectionTimeZone=LOCAL` faz o driver usar o fuso do próprio computador, então o horário digitado é sempre o horário gravado e mostrado (com o fuso fixo em São Paulo, um computador em outro fuso via 20:00 como 23:00).
- `configurar(...)`: troca os quatro valores (chamado pelo [[ConexaoController]]).
- `carregarConfiguracao()`: `Properties config = new Properties();` cria o "dicionário"; `try (FileInputStream arquivo = new FileInputStream(ARQUIVO_CONFIG))` abre o arquivo (try-with-resources fecha sozinho); `config.load(arquivo)` lê as linhas `chave=valor`; `config.getProperty("servidor", servidor)` devolve o valor salvo ou, se não houver, o padrão. O `catch (IOException | NumberFormatException e)` (multi-catch) ignora a falta do arquivo na primeira execução.
- `salvarConfiguracao()`: o inverso: `setProperty` para cada valor e `config.store(arquivo, comentario)` grava o arquivo.
- `getServidor()`, `getPorta()`, `getUsuario()`, `getSenha()`: getters estáticos usados para preencher a tela de conexão.

> **Por que não tem mais `Class.forName("com.mysql.cj.jdbc.Driver")`?** Desde o JDBC 4 o driver se registra sozinho quando o `.jar` está no classpath (arquivo `META-INF/services/java.sql.Driver` dentro do driver). O exemplo do professor usa `Class.forName` porque é o jeito antigo; os dois funcionam.

---
⬅ [[Pacote util]] · [[00 - Painel]] · [[CriadorBanco]] ➡
