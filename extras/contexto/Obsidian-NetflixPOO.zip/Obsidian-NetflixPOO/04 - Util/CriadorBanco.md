---
tags: [netflix, codigo, util, classe]
---

# CriadorBanco

*Seção 3.2: CriadorBanco (novo na V2)* · Pasta: [[Pacote util]]


**Para que serve:** criar o banco **sozinho**, rodando o `netflix.sql` que vai dentro do `Netflix.jar`. Com isso ninguém do grupo precisa abrir o Workbench.

- `criarSeNaoExistir()`: `if (!bancoExiste() || bancoSemTabelas()) { recriarBanco(); }`. Cria na primeira vez, quando o banco não existe **ou existe vazio** (sem nenhuma tabela). Um banco que já tem tabelas é reaproveitado e nunca é apagado aqui, para não perder dados que alguém cadastrou.
- `bancoSemTabelas()`: roda `SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'netflix'` e devolve `true` se o resultado for 0.
- `bancoExiste()`: roda `SELECT COUNT(*) FROM information_schema.schemata WHERE schema_name = 'netflix'`. `information_schema` é o "banco de informações" do próprio MySQL; `schemata` lista os bancos existentes. `rs.next()` vai para a única linha e `rs.getInt(1) > 0` diz se achou.
- `recriarBanco()`:
  - `String script = lerScript();`: texto do script, já sem comentários.
  - `try (Connection con = ConnectionFactory.getConnectionServidor(); Statement st = con.createStatement())`: conexão com o servidor e um `Statement` (sem `?`, pois o script não tem valores vindos do usuário).
  - `for (String comando : script.split(";"))`: o JDBC executa **um comando por vez**; `split(";")` corta o script em cada `;`.
  - `if (!comando.trim().isEmpty()) { st.execute(comando); }`: ignora pedaços vazios e executa os outros em ordem (DROP, CREATE DATABASE, USE, 5 CREATE TABLE, 5 INSERT = 13 comandos).
- `lerScript()`:
  - `CriadorBanco.class.getResourceAsStream("/netflix.sql")`: lê um arquivo **de dentro do jar** (o `build.bat` copia o script para lá).
  - `entrada.transferTo(bytes)` e `bytes.toString("UTF-8")`: transforma o conteúdo em texto, respeitando acentos.
  - O `for` por linha corta tudo depois de `--` (comentários), para um `;` dentro de comentário não atrapalhar o `split`.

---
⬅ [[ConnectionFactory]] · [[00 - Painel]] · [[Conversor]] ➡
