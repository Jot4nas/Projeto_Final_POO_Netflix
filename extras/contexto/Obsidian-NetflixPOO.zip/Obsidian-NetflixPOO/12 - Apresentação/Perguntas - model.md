---
tags: [netflix, apresentacao]
---

# Perguntas - model

*Seção 12.4: model* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Por que os atributos são `private`? | Encapsulamento: acesso só por `getX`/`setX`. |
| Por que dois construtores? | O vazio é usado pelo DAO ao ler do banco; o completo pelo Controller. É sobrecarga. |
| Por que o construtor completo não recebe o id? | O id é gerado pelo `AUTO_INCREMENT`; o DAO faz `setIdPlano(...)` depois do INSERT. |
| Para que serve o `this`? | Diferencia o atributo (`this.nome`) do parâmetro (`nome`). |
| O que são `nomePlano`, `emailConta`, `nomePerfil`, `nomeTitulo`? | Campos só de exibição, preenchidos pelos SELECT com JOIN. Não existem nas tabelas e não são gravados. |
| Por que [[Pacote model\|Conta]] guarda `int idPlano` e não um [[Pacote model\|Plano]]? | Espelha a tabela (só a FK). O nome vem pelo JOIN quando a tela precisa. |

---
⬅ [[Perguntas - util]] · [[00 - Painel]] · [[Perguntas - dao]] ➡
