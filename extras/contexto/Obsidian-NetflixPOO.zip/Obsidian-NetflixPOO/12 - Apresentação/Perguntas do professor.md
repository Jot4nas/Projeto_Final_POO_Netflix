---
tags: [netflix, apresentacao]
---

# Perguntas do professor

*Seção 12 da documentação: Perguntas prováveis do professor (com respostas)*


Cada aluno responde **2 perguntas de 0,5 ponto**, individualmente, sobre **o código desenvolvido**. **Como responder bem:** (1) diga o que a classe/método faz; (2) aponte o trecho; (3) explique **por que**; (4) nomeie o conceito de POO.

## Notas desta pasta

- [[Perguntas - Fluxo geral]]: Fluxo geral e execução
- [[Perguntas - Banco de dados]]: Banco de dados
- [[Perguntas - util]]: util
- [[Perguntas - model]]: model
- [[Perguntas - dao]]: dao
- [[Perguntas - controller]]: controller
- [[Perguntas - view]]: view
- [[Perguntas - Mostre no código]]: "Mostre no código" (prepare estes trechos)

---
⬅ [[Rodar e testar]] · [[00 - Painel]] · [[Perguntas - Fluxo geral]] ➡
