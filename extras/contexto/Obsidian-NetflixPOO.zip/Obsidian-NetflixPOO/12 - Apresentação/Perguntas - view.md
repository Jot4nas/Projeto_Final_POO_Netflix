---
tags: [netflix, apresentacao]
---

# Perguntas - view

*Seção 12.7: view* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Por que [[TelaCrud]] é `abstract`? | É só o esqueleto; obriga as filhas a implementar `carregarTabela`, `inserir`, `atualizar`, `eliminar`. |
| Onde estão herança e polimorfismo? | `TelaPlano extends TelaCrud extends JFrame`; a [[TelaCrud]] chama `inserir()` e roda a versão da tela aberta. |
| O que é o Template Method? | A base define o passo a passo e deixa "buracos" (abstratos e ganchos) para as filhas. |
| Por que `iniciar()` não está no construtor da [[TelaCrud]]? | No construtor da base o `controller` da filha ainda não existe. |
| Como a tabela é preenchida? | `carregarTabela()` da filha pega a lista do Controller e faz `modelo.addRow(new Object[]{...})`. |
| Como os botões estão ligados? | `btnInserir.addActionListener(e -> mostrarResultado(inserir()));`: a lambda é o `ActionListener`; o clique só chama o método. |
| Como clicar numa linha preenche o formulário, inclusive os combos de FK? | `aoSelecionar()` copia as células para os campos. Como tabela e combo usam o mesmo texto `"3 - Premium"`, `setSelectedItem` acha o item. |
| Por que os combos de FK são atributos e começam vazios? | São preenchidos em `carregarCombos()`, chamado em todo `recarregar()`; assim sempre mostram os dados atuais do banco. |
| Por que [[TelaRelatorio]] não herda de [[TelaCrud]]? | Não é um cadastro (não tem inserir/atualizar/eliminar); herda direto de `JFrame`. |
| Para que serve o `JFileChooser`? | Abre a janela "Salvar como" para escolher onde gravar o `.txt`. |
| `DISPOSE_ON_CLOSE` x `EXIT_ON_CLOSE`? | O primeiro fecha só a janela (telas de CRUD); o segundo encerra o programa (menu e tela de conexão). |
| Por que `SwingUtilities.invokeLater`? | O Swing exige criar a interface na Event Dispatch Thread. |
| Como adicionar um 6º CRUD? | Model, DAO, Controller, uma tela `extends TelaCrud` com os 4 métodos e um botão no menu. |

---
⬅ [[Perguntas - controller]] · [[00 - Painel]] · [[Perguntas - Mostre no código]] ➡
