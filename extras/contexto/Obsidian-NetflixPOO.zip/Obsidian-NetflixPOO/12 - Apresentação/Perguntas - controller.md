---
tags: [netflix, apresentacao]
---

# Perguntas - controller

*Seção 12.6: controller* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Por que os métodos devolvem `String`? | A View só precisa do texto para mostrar. |
| Por que dois `catch`? | `IllegalArgumentException` = validação (antes do banco); `SQLException` = erro do banco (inclui MySQL desligado). |
| Onde estão as regras de negócio? | [[Controllers de Conta, Perfil e Titulo\|ContaController]]`.montar` (país 2 letras), [[Controllers de Conta, Perfil e Titulo\|PerfilController]]`.montar` (PIN 4 dígitos), [[HistoricoController]]`.montar` (datas e minuto), [[RelatorioController]]`.gerar` (período válido) e `resumo` (totais). |
| Por que os totais do relatório ficam no Controller? | São regra de negócio (contar concluídas, somar minutos). A tela só mostra. |
| O que [[ConexaoController]]`.conectar` devolve? | `null` se deu certo; senão a mensagem de erro. A [[TelaConexao]] testa `if (erro == null)`. |
| Por que `listar()` lança `RuntimeException`? | Devolve uma lista, não uma mensagem; a [[TelaCrud]]`.recarregar()` captura e mostra. |

---
⬅ [[Perguntas - dao]] · [[00 - Painel]] · [[Perguntas - view]] ➡
