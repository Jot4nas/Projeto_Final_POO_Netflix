---
tags: [netflix, revisao, qualidade]
---

# Correções da revisão

*Seção 13 da documentação: Correções feitas depois da revisão do código (30/10/2026)*


Uma revisão "adversarial" (que tenta quebrar o sistema) achou 9 falhas (a de valores sem sentido tinha duas partes: o valor do plano e o minuto de parada, por isso a tabela tem 10 linhas). Todas foram reproduzidas com testes contra um MySQL de verdade, corrigidas e testadas de novo.

| # | O que estava errado | Como ficou | Onde |
|---|---|---|---|
| 1 | Qualquer erro (ex.: data inválida) **apagava o formulário inteiro** | O formulário só é limpo quando deu certo. Depois de um erro ficam o texto digitado, a escolha dos combos e a linha selecionada | [[TelaCrud]]`.mostrarResultado`, `recarregar(boolean)` |
| 2 | Se o `config.properties` não pudesse ser gravado (pasta protegida), **ninguém conseguia entrar** | Entra normalmente e mostra um aviso. O [[ConexaoController]] só lê o arquivo na 1ª vez, para o menu não trocar a senha nova pela antiga | [[ConexaoController]]`.conectar`, [[TelaConexao]] |
| 3 | "Salvar .txt" juntava as linhas de um relatório com as datas de outro | Guarda os filtros usados na última geração e salva com eles | [[TelaRelatorio]]`.gerar`, `salvar` |
| 4 | Num computador com outro fuso horário os horários apareciam deslocados (20:00 virava 23:00) | `connectionTimeZone=LOCAL` na URL: o horário digitado é o mostrado em qualquer fuso | [[ConnectionFactory]]`.montarUrl` |
| 5 | Um banco `netflix` já existente mas **vazio** nunca recebia as tabelas | Se o banco não existe ou está sem tabelas, é criado. Banco com tabelas continua sendo reaproveitado (nunca apagado) | [[CriadorBanco]]`.criarSeNaoExistir`, `bancoSemTabelas` |
| 6 | Plano com valor negativo ou zero era aceito | "O valor mensal deve ser maior que zero." | [[PlanoController]]`.montar` |
| 7 | Eliminar/atualizar um registro que já não existe dizia "sucesso" | Os DAOs devolvem `true/false` (`executeUpdate() > 0`) e o Controller avisa "Registro não encontrado" | os 5 DAOs e controllers, [[Conversor]]`.REGISTRO_NAO_ENCONTRADO` |
| 8 | Minuto de parada maior que a duração do título era aceito | "O minuto de parada (X) não pode passar da duração do título (Y min)." Séries (sem duração) aceitam qualquer minuto | [[HistoricoController]]`.montar` |
| 9 | Erro de conta vinha sempre com a dica "(e-mail já cadastrado?)" | Código 1062 → "Já existe uma conta com esse e-mail."; 1452 → "O plano escolhido não existe mais."; outros erros mostram a mensagem do banco | [[Controllers de Conta, Perfil e Titulo\|ContaController]]`.mensagemDeErro` |
| 10 | "Eliminar" sem linha selecionada perguntava "Eliminar o registro?" antes de avisar | Avisa "Selecione um registro" direto | [[TelaCrud]]`.confirmarEliminar` |

**Como foi testado:** 70 verificações das camadas (todas passaram), as 5 telas, o menu e o relatório, mais 39 verificações novas, uma ou mais para cada correção, incluindo cliques simulados. A do fuso horário rodou em três fusos: São Paulo, UTC e Tóquio.

---
⬅ [[Perguntas - Mostre no código]] · [[00 - Painel]]
