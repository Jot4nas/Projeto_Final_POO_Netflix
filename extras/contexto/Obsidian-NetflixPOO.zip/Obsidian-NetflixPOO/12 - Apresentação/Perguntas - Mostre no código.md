---
tags: [netflix, apresentacao]
---

# Perguntas - Mostre no código

*Seção 12.8: "Mostre no código" (prepare estes trechos)* · Pasta: [[Perguntas do professor]]


| Pedido | Abra |
|---|---|
| Um CRUD completo no DAO | [[PlanoDAO]] |
| O INNER JOIN | [[HistoricoVisualizacaoDAO]]`.SELECT_COM_NOMES` / `listarComNomes()` (e [[ContaDAO]]`.listar()`) |
| O relatório | [[TelaRelatorio]]`.gerar()`, [[RelatorioController]]`.gerar()` e `resumo()`, [[HistoricoVisualizacaoDAO]]`.listarPorPeriodo()` |
| Onde a conexão é feita | [[ConnectionFactory]]`.getConnection()` |
| Como o banco é criado | [[CriadorBanco]]`.recriarBanco()` |
| Proteção contra SQL Injection | qualquer DAO: `?` no SQL e `ps.setString(...)` |
| Tratamento de NULL | [[TituloDAO]]`.preencher` (`setNull`) e [[TituloDAO]]`.listar` (`wasNull`) |
| Herança e polimorfismo | `TelaPlano extends TelaCrud`; métodos abstratos da [[TelaCrud]] |
| Encapsulamento | atributos `private` + `getX`/`setX` em qualquer model |
| Sobrecarga e sobrescrita | construtores do [[Pacote model\|Plano]]; `definirValor` (sobrecarga); `carregarTabela` nas filhas (sobrescrita) |
| Onde a tabela é preenchida | `carregarTabela()` e `modelo.addRow(...)` |
| Os botões e eventos | [[TelaCrud]]`.iniciar()` (`addActionListener`) |
| Regras de negócio | [[HistoricoController]]`.montar`, [[Controllers de Conta, Perfil e Titulo\|ContaController]]`.montar`, [[Controllers de Conta, Perfil e Titulo\|PerfilController]]`.montar`, [[RelatorioController]]`.gerar` |
| PK, FK e relacionamentos | `sql/netflix.sql` |

> **Dica para a defesa:** treine abrir [[HistoricoVisualizacaoDAO]], [[PlanoDAO]], [[TelaCrud]], [[Telas filhas|TelaPlano]] e [[RelatorioController]] e explicar linha por linha com as seções 5, 6, 7 e 8. Responda sempre ligando o conceito (ex.: polimorfismo) a um exemplo concreto do projeto.

---
⬅ [[Perguntas - view]] · [[00 - Painel]] · [[Correções da revisão]] ➡
