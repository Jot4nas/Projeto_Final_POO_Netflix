---
tags: [netflix, apresentacao]
---

# Perguntas - dao

*Seção 12.5: dao* · Pasta: [[Perguntas do professor]]


| Pergunta | Resposta |
|---|---|
| Explique [[PlanoDAO]]`.inserir` linha a linha. | INSERT com 7 `?`; abre `Connection` e `PreparedStatement` no `try`; preenche cada `?` na ordem; `executeUpdate()`; `getGeneratedKeys()` e `setIdPlano(...)`. |
| Como a descrição do plano é gerada automaticamente? | O Controller tem `gerarDescricao(telas, qualidade)`: converte o número de telas em palavras ("Uma tela", "Duas telas", "Três telas", "Quatro telas"; acima disso "5 telas") e junta com ", qualidade " + a qualidade. Ex.: `("2", "Full HD")` → "Duas telas, qualidade Full HD". |
| Por que a descrição é gerada no Controller e não na tela? | É regra de negócio (como o texto é montado). A tela só **pede** o texto ao Controller (`controller.gerarDescricao(...)`) para mostrar ao vivo; ao salvar, o próprio Controller gera de novo em `montar(...)`, então a descrição gravada nunca fica diferente das telas e da qualidade. |
| Como a descrição aparece ao vivo na tela de planos? | `comboQualidade.addActionListener(...)` e um `DocumentListener` no campo de telas chamam `atualizarDescricao()` sempre que a qualidade ou o texto de telas muda (inclusive quando o código preenche o campo ao clicar numa linha). O campo de descrição é `setEditable(false)`. |
| E se o UPDATE/DELETE ficar sem `WHERE`? | Alteraria/apagaria **todos** os registros. |
| Por que `PreparedStatement`? | Previne SQL Injection: comando e dados vão separados. |
| O que é o try-with-resources? | Fecha `ps` e `con` automaticamente ao sair do bloco, mesmo com erro. |
| O que faz `while (rs.next())`? | Avança o cursor uma linha por vez; em cada volta cria um objeto. |
| Explique o JOIN de `listarComNomes()`. | `FROM historico_visualizacao h INNER JOIN perfil p ON p.id_perfil = h.id_perfil INNER JOIN titulo t ON t.id_titulo = h.id_titulo INNER JOIN conta c ON c.id_conta = p.id_conta INNER JOIN plano pl ON pl.id_plano = c.id_plano`, com `p.nome AS nome_perfil, t.nome AS nome_titulo, c.email AS email_conta, pl.nome AS nome_plano`, ordenado pela última visualização. |
| Por que `INNER JOIN` e não `LEFT JOIN`? | Só traz linhas com correspondência; as FKs garantem que perfil e título existem, então nenhuma se perde. |
| Como funciona o filtro opcional do relatório? | `if (idPerfil > 0) sql += "AND h.id_perfil = ? ";` e só nesse caso `ps.setInt(3, idPerfil)`. 0 significa "Todos". |
| O que faz `DATE(h.data_inicio) BETWEEN ? AND ?`? | `DATE()` tira a hora; `BETWEEN` inclui as duas datas. |
| Para que serve a constante `SELECT_COM_NOMES`? | O SELECT com JOIN é igual nas duas consultas (`listarComNomes` e `listarPorPeriodo`); escrevemos uma vez só e cada método acrescenta o final (`WHERE`/`ORDER BY`). |
| Por que `setNull(6, Types.INTEGER)` na duração? | `setInt` não aceita `null`; `setNull` grava NULL informando o tipo. |
| O que é `rs.wasNull()`? | `getInt` devolve 0 para NULL; `wasNull()` diz se era NULL de verdade. |
| Por que o DAO declara `throws SQLException`? | Só acessa dados; o Controller decide a mensagem (MVC). |

---
⬅ [[Perguntas - model]] · [[00 - Painel]] · [[Perguntas - controller]] ➡
