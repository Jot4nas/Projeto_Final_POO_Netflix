---
tags: [netflix, banco, sql]
---

# Banco de dados

*Seção 2 da documentação: Banco de dados (sql/netflix.sql)*

```mermaid
erDiagram
    PLANO ||--o{ CONTA : "id_plano"
    CONTA ||--o{ PERFIL : "id_conta"
    PERFIL ||--o{ HISTORICO_VISUALIZACAO : "id_perfil"
    TITULO ||--o{ HISTORICO_VISUALIZACAO : "id_titulo"
```


O script cria o banco `netflix`, 5 tabelas (um recorte das 13 do modelo lógico do grupo) e dados de teste. **Na V2 ninguém precisa rodá-lo na mão:** o sistema o executa sozinho na primeira vez ([[CriadorBanco|seção 3.2]]). Ele continua podendo ser aberto no Workbench.

## 2.1 Como as tabelas se relacionam

```
plano 1 ---< N conta 1 ---< N perfil N >--- historico_visualizacao ---< N titulo
```

- **plano → conta (1:N):** um plano tem várias contas; cada conta tem um plano (FK `id_plano`).
- **conta → perfil (1:N):** uma conta tem vários perfis (FK `id_conta`).
- **perfil ↔ titulo (N:N):** um perfil assiste vários títulos e um título é assistido por vários perfis. Uma relação N:N não cabe em duas tabelas; ela vira uma **tabela associativa** (`historico_visualizacao`) com duas FKs.

## 2.2 Cabeçalho e criação do banco

- `-- ...`: linhas que começam com `--` são comentários; o MySQL as ignora.
- `DROP DATABASE IF EXISTS netflix;`: apaga o banco se ele já existir. O `IF EXISTS` evita erro quando não existe. Por isso o script pode ser rodado várias vezes (é o que o botão **Restaurar dados de exemplo** faz).
- `CREATE DATABASE netflix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`: cria o banco. `utf8mb4` aceita acentos e emojis; `utf8mb4_unicode_ci` define como comparar textos (`ci` = ignora maiúsculas/minúsculas).
- `USE netflix;`: os próximos comandos valem para o banco `netflix`.

## 2.3 Tabela `plano`

- `id_plano INT AUTO_INCREMENT PRIMARY KEY`: número que identifica cada plano. `AUTO_INCREMENT` gera 1, 2, 3... sozinho. **PRIMARY KEY** = identificador único, não repete e não é nulo.
- `nome VARCHAR(40) NOT NULL`: texto de até 40 caracteres, obrigatório.
- `descricao TEXT`: texto longo, opcional (aceita NULL).
- `valor_mensal DECIMAL(6,2) NOT NULL`: até 6 dígitos, 2 depois da vírgula (até 9999,99). DECIMAL, e não FLOAT, para dinheiro: não tem erro de arredondamento.
- `qualidade_maxima ENUM('SD','HD','Full HD','4K UHD') NOT NULL DEFAULT 'HD'`: só aceita um dos valores listados; padrão `'HD'`.
- `telas_simultaneas TINYINT NOT NULL DEFAULT 1`: inteiro pequeno.
- `permite_download TINYINT(1) NOT NULL DEFAULT 0`: o MySQL não tem booleano; `TINYINT(1)` guarda 0 (falso) ou 1 (verdadeiro).
- `data_criacao DATE NOT NULL`: só a data. O Java não preenche: o INSERT usa `CURDATE()`.
- `) ENGINE=InnoDB;`: InnoDB é o motor que **suporta chaves estrangeiras** e transações.

## 2.4 Tabela `conta`

- `id_conta INT AUTO_INCREMENT PRIMARY KEY`: chave primária.
- `id_plano INT NOT NULL`: o plano da conta (FK, definida no final).
- `email VARCHAR(120) NOT NULL UNIQUE`: `UNIQUE` impede duas contas com o mesmo e-mail.
- `senha_hash VARCHAR(255) NOT NULL`: guarda a senha "embaralhada" (hash). Os dados de teste são fictícios.
- `telefone VARCHAR(15)`: opcional.
- `pais CHAR(2) NOT NULL DEFAULT 'BR'`: tamanho fixo de 2 letras.
- `data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP`: data **e hora**; se não informarem, usa o momento atual.
- `status ENUM('Ativa','Suspensa','Cancelada') NOT NULL DEFAULT 'Ativa'`.
- `CONSTRAINT fk_conta_plano FOREIGN KEY (id_plano) REFERENCES plano (id_plano)`: **chave estrangeira**. O valor de `conta.id_plano` precisa existir em `plano.id_plano`. Resultado: não dá para criar conta com plano inexistente nem apagar um plano que ainda tem contas (**integridade referencial**).

## 2.5 Tabela `perfil`

- `id_perfil` (PK), `id_conta` (FK), `nome VARCHAR(50) NOT NULL`, `avatar VARCHAR(60)` (opcional), `data_criacao DATE NOT NULL`, `perfil_infantil TINYINT(1) DEFAULT 0`, `pin CHAR(4)` (opcional).
- `CONSTRAINT fk_perfil_conta FOREIGN KEY (id_conta) REFERENCES conta (id_conta)`: o perfil só existe se a conta existir; não dá para apagar uma conta que ainda tem perfis.

## 2.6 Tabela `titulo`

- `id_titulo` (PK), `nome VARCHAR(150) NOT NULL`, `sinopse TEXT`, `tipo ENUM('Filme','Serie','Documentario','Stand-up') NOT NULL`, `ano_lancamento SMALLINT`, `classificacao_indicativa ENUM('L','10','12','14','16','18') DEFAULT 'L'`.
- `duracao_minutos INT`: **NULL para séries** (a duração fica nos episódios).
- `idioma_original VARCHAR(30)`, `data_adicao_catalogo DATE NOT NULL`, `disponivel TINYINT(1) DEFAULT 1`.

## 2.7 Tabela `historico_visualizacao` (a tabela associativa e o CRUD principal)

- `id_visualizacao INT AUTO_INCREMENT PRIMARY KEY`: identifica cada "sessão assistida".
- `id_perfil INT NOT NULL` e `id_titulo INT NOT NULL`: as duas FKs. Cada linha diz "o perfil X assistiu o título Y".
- `data_inicio DATETIME`, `data_ultima_visualizacao DATETIME`, `minuto_parada INT DEFAULT 0`, `concluido TINYINT(1) DEFAULT 0`, `dispositivo ENUM('TV','Celular','Notebook','Tablet','Console') DEFAULT 'TV'`.
- `CONSTRAINT fk_hist_perfil FOREIGN KEY (id_perfil) REFERENCES perfil (id_perfil) ON DELETE CASCADE`: se o perfil for apagado, o histórico dele é apagado junto (não sobra registro apontando para o nada).
- `CONSTRAINT fk_hist_titulo ... ON DELETE CASCADE`: o mesmo para o título.

## 2.8 Dados de teste (`INSERT`)

Sintaxe: `INSERT INTO tabela (colunas...) VALUES (valores...), (valores...);`. As colunas `id_*` ficam de fora porque o `AUTO_INCREMENT` as gera.

- **plano:** 3 linhas (Basico 20,90 SD; Padrao 39,90 Full HD; Premium 55,90 4K UHD) → ids 1, 2, 3.
- **conta:** 3 contas; o primeiro número é o `id_plano` (3, 2, 1). A terceira tem telefone `NULL` e status 'Suspensa'.
- **perfil:** 5 perfis; o primeiro número é o `id_conta` (1, 1, 1, 2, 3): a conta 1 tem Ana, Pedro e Kids.
- **titulo:** 5 títulos; as séries (Stranger Things, Round 6) têm `NULL` na duração.
- **historico_visualizacao:** 6 linhas entre 01/06/2025 e 10/06/2025 (ex.: perfil 1 assistiu o título 1 até o minuto 55 na TV).

## 2.9 Consulta de teste (comentada no final)

```sql
SELECT h.id_visualizacao, p.nome AS perfil, t.nome AS titulo, h.minuto_parada, h.dispositivo
FROM historico_visualizacao h
INNER JOIN perfil p ON p.id_perfil = h.id_perfil
INNER JOIN titulo t ON t.id_titulo = h.id_titulo;
```

- `SELECT ...`: colunas a mostrar; `p.nome AS perfil` renomeia a coluna na saída.
- `FROM historico_visualizacao h`: tabela principal; `h` é um apelido (alias).
- `INNER JOIN perfil p ON p.id_perfil = h.id_perfil`: junta cada linha do histórico com o perfil de mesmo id. Assim aparece o **nome**, não o número.
- `INNER JOIN titulo t ON t.id_titulo = h.id_titulo`: o mesmo para o título.

Está comentada (`--`) para não rodar sozinha; copie e execute no Workbench para conferir.

---
⬅ [[Visão geral]] · [[00 - Painel]] · [[Pacote util]] ➡
