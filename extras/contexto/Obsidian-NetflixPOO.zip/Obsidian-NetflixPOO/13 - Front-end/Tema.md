---
tags: [netflix, front-end, tema]
---

# Tema (`view/Tema.java`)

*A "folha de estilo" do programa: um lugar só com as cores, fontes e estilos.*

## O que tem

| Item | Valor / função |
|---|---|
| Cores | `FUNDO` #141414 (quase preto), `PAINEL`, `CAMPO`, `SUPERFICIE`, `BORDA`, `TEXTO`, `TEXTO_SUAVE` e `VERMELHO` #e50914 (o único destaque) |
| Fontes | `FONTE`, `FONTE_NEGRITO`, `FONTE_TITULO`, `FONTE_PEQUENA` (Segoe UI se existir) |
| `aplicar()` | Liga o **Nimbus** (aparência moderna que já vem no Java) e troca as cores padrão do Swing; chamado **uma vez** no `Main`, antes de qualquer janela |
| `Tema.Botao` | Botão arredondado: herda de `JButton` e sobrescreve `paintComponent` |
| `estilizarCampo` / `estilizarCombo` | Campo de texto e combo escuros; borda vermelha quando o campo tem foco |
| `estilizarTabela` | Linhas mais altas, listras alternadas, linha selecionada em vermelho (`DefaultTableCellRenderer`) |
| `rolagem`, `rolagemSimples`, `rolagemHorizontal` | `JScrollPane` com barras finas no tema |
| `cabecalho`, `chip` | Faixa de título de cada tela e as "pílulas" de totais do relatório |

## Como o botão é desenhado

1. `super(texto)`: continua sendo um `JButton` (clicável, com teclado).
2. `setContentAreaFilled(false)` e `setBorderPainted(false)`: desligam o desenho padrão; quem pinta somos nós.
3. `paintComponent(Graphics g)`: pega o `Graphics2D`, liga o antialiasing, escolhe a cor pelo **tipo** (`PRINCIPAL` vermelho, `SECUNDARIO` cinza, `PERIGO` contorno vermelho, `FANTASMA` transparente) e pelo estado (`isRollover` = mouse em cima, `isPressed`), e usa `fillRoundRect` (retângulo de cantos arredondados). Por último chama `super.paintComponent(g)` para escrever o texto por cima.
4. Foco do teclado (`isFocusOwner`): anel branco, para quem navega com Tab ver onde está.
5. `setTipo(...)` troca o tipo depois de criado (usado nos botões "Visual | Tabela").

> [!codigo] Pergunta provável
> **Por que um botão próprio?** Cantos arredondados, cor ao passar o mouse e anel de foco. Continua sendo `JButton` (herança): cada tela só faz `new Tema.Botao("Inserir", Tema.TipoBotao.PRINCIPAL)`.

> [!codigo] Pergunta provável
> **O que é o Nimbus?** Um *Look and Feel* (aparência) que vem no Java. O `Tema.aplicar()` o liga com `UIManager.setLookAndFeel(...)` e troca as cores com `UIManager.put(...)`.

## Ícones (`Icone.java`)

Um `enum` com os desenhos (CASA, PLANOS, CONTAS, PERFIS, TITULOS, HISTORICO, RELATORIO, RESTAURAR) feitos de linhas e curvas numa **grade de 24 × 24**. O método `desenhar(g, x, y, tamanho, cor)` aplica `scale(tamanho / 24.0)`, então o mesmo ícone serve em qualquer tamanho sem perder qualidade (e sem arquivo de imagem).

---
⬅ [[Front-end]] · [[00 - Painel]] · [[Início e capas]] ➡
