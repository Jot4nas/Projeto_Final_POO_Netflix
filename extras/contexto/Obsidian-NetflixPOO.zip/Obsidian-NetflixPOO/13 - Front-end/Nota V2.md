---
tags: [netflix, front-end, v2]
---

# Navegação na versão sem front-end (V2)

A V2 tem a **mesma lógica de telas** da versão visual; só muda o visual (botões e janelas padrão do Swing).

- `BarraNavegacao`: o mesmo painel do topo em todas as telas (Início, Planos, Contas, Perfis, Títulos, Histórico), com `JButton` comuns. O botão da tela atual fica desabilitado.
- `Navegador.ir(atual, nova)`: a tela nova abre no mesmo lugar e tamanho, com fade-in (véu no `glass pane` + `Timer` de 16 ms, 9 passos), e a atual é fechada. Só há uma janela por vez; fechar no X encerra o programa.
- `Navegador.trocar(origem, nova)`: só da `TelaConexao` para o menu.
- `TelaPrincipal` (Início) é o menu numerado de antes, com a barra no topo e o botão **Restaurar dados** à direita.
- `TelaCrud` e `TelaRelatorio` colocam a barra acima do formulário/filtros.

Explicação completa do fade: [[Navegação e transição]].

---
⬅ [[Front-end]]
