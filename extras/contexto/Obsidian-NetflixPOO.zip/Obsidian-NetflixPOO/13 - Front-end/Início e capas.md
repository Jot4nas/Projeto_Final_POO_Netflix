---
tags: [netflix, front-end, inicio, capas]
---

# Início e capas (`TelaPrincipal.java` e `Capa.java`)

*A tela principal, inspirada na página inicial do app da Netflix.*

## O que a tela mostra

1. **Barra do topo** com a marca NETFLIX e os botões das telas ([[Navegação e transição]]).
2. **Destaque**: um título do catálogo em tamanho grande (nome, classificação, ano, tipo, idioma, sinopse) e os botões **Ver títulos** e **Ver histórico**.
3. **"Populares na Netflix"**: uma capa para cada título cadastrado, numa fileira que rola para o lado. **Clicar numa capa coloca aquele título no destaque** (a tela volta ao topo e a capa escolhida ganha um contorno branco).
4. **"Continuar assistindo como (perfil)"**: o que o perfil mais recente assistiu, com a barra de progresso vermelha (minuto de parada ÷ duração; série não tem duração e mostra um terço).

> [!regra] MVC
> `carregarDados()` pega as listas dos Controllers (`TituloController.listar()` e `HistoricoController.listarComNomes()`). A tela **não tem SQL**. Se o banco falhar, as fileiras ficam vazias.

## Como cada parte foi feita

| Parte | Técnica |
|---|---|
| Fileira de capas | Um `JPanel` com `FlowLayout` dentro de um `JScrollPane` só horizontal (`Tema.rolagemHorizontal`) |
| Cada capa | `CartaDeCapa extends JButton`: sobrescreve `paintComponent`, chama `Capa.desenhar(...)`, e desenha a barra de progresso e o contorno (hover, foco ou escolhida) |
| Destaque | `Destaque extends JPanel` com `paintComponent` próprio e o método `mostrar(Titulo)`, que troca os textos (`setText`) e chama `repaint()` |
| Fundo do destaque | 1) a capa esticada na metade direita, escurecida com `fillRect` de cor com transparência; 2) degradês (`GradientPaint`) para o texto ficar legível e ligar com o resto; 3) a **capa inteira**, na proporção do pôster (largura = 67% da altura), por cima, para não cortar |
| Restaurar dados | Depois de restaurar, `montarTela()` desenha tudo de novo com os dados novos |

## Capas (`Capa.java`)

- Procura o arquivo `capas/NOME DO TÍTULO.jpg` (ou `.png`) ao lado do programa (nome **igual** ao do título no banco). Usa `ImageIO.read` e guarda em um `HashMap` (cache) para não ler o disco toda hora.
- Se não existir, **desenha a capa**: degradê com a cor escolhida pelo `hashCode` do nome (um título sempre tem a mesma cor), um "N" vermelho e o nome em linhas.
- A imagem é desenhada em modo "cover" (preenche o retângulo cortando o que sobra) com cantos arredondados, usando `g2.clip(new RoundRectangle2D.Float(...))`.

> [!codigo] Pergunta provável
> **E se não houver imagem?** O sistema funciona do mesmo jeito: a capa é desenhada em código. Por isso roda em qualquer computador, com ou sem a pasta `capas`.

> [!warning] Direitos autorais
> As capas são das distribuidoras (baixadas do IMDb para uso local). Não subir a pasta `capas` no GitHub público.

---
⬅ [[Tema]] · [[Front-end]] · [[Navegação e transição]] ➡
