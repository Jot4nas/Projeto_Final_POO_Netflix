---
tags: [netflix, front-end, navegacao]
---

# Navegação e transição (`BarraNavegacao.java` e `Navegador.java`)

*Os botões ao lado do logo e a troca suave de tela.*

## O problema

Antes, cada botão abria **outra janela por cima** da atual: ficavam várias janelas empilhadas, parecendo amador.

## A solução (simples)

### 1. `BarraNavegacao`: a mesma barra em todas as telas
- `extends JPanel`, com a marca NETFLIX e um botão por tela: **Início, Planos, Contas, Perfis, Títulos, Histórico** (o Relatório abre pelo botão da tela de Histórico).
- Recebe no construtor a janela onde está (`dona`) e o nome da tela atual. O botão da tela atual fica branco e em negrito e **não faz nada**.
- Cada botão é só uma linha: `e -> Navegador.ir(dona, new TelaPlano())` (lambda).
- A [[TelaCrud]] e a [[TelaRelatorio]] colocam essa barra no topo (método `barraECabecalho`); a tela Início acrescenta o botão "Restaurar dados" no canto direito.

### 2. `Navegador.ir(atual, nova)`: troca no mesmo lugar
1. `nova.setBounds(atual.getBounds())`: a tela nova abre **na mesma posição e tamanho** (e maximizada, se a atual estava).
2. Coloca um **"véu"** por cima da nova (o `glass pane` do `JFrame`, um `JPanel` que pinta a cor de fundo com transparência).
3. Mostra a nova e **fecha a atual** (`atual.dispose()`): nunca há duas janelas.
4. Um `javax.swing.Timer` (a cada 16 ms, uns 60 quadros por segundo) diminui a opacidade do véu em 9 passos (~150 ms) até sumir: é o **fade-in**. No fim o véu é escondido e a tela volta a receber cliques.

> [!decisao] Por que o fade é feito dentro da janela?
> A forma "óbvia" seria `Window.setOpacity`, mas ela **não funciona em janela com a barra de título do Windows** (lança `IllegalComponentStateException: The frame is decorated`). Testamos. Por isso o fade é um véu pintado por cima do conteúdo.

### 3. Fechar a janela
Como só existe uma janela por vez, fechar no X **encerra o programa** (`EXIT_ON_CLOSE`).

> [!codigo] Pergunta provável
> **O que é um `Timer` do Swing?** Um temporizador que chama o código na thread da interface (EDT) a cada intervalo. É seguro mexer em componentes dentro dele, ao contrário de uma `Thread` comum.

> [!codigo] Pergunta provável
> **O Controller sabe da navegação?** Não. A navegação é só View (`new TelaPlano()` cria a tela, que chama o seu próprio Controller).

---
⬅ [[Início e capas]] · [[Front-end]] · [[Visões das abas]] ➡
