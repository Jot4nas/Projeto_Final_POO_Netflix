---
tags: [netflix, codigo, controller]
aliases: [ContaController, PerfilController, TituloController]
---

# Controllers de Conta, Perfil e Titulo

*Seção 6.2: ContaController, PerfilController, TituloController* · Pasta: [[Pacote controller]]


Mesmo molde. Diferenças:

- **ContaController:** tem também um [[PlanoDAO]] para `opcoesPlanos()`, que devolve [[Conversor]]`.opcao(id, nome)` de cada plano. Regra de negócio em `montar`: país com 2 letras (`paisValido.length() != 2` → erro) e `toUpperCase()`. [[Conversor]]`.extrairId(plano, "Plano")` tira a FK do combo. Erro de banco no `inserir` avisa "e-mail já cadastrado?" (coluna UNIQUE).
- **PerfilController:** [[ContaDAO]] para `opcoesContas()` (`"id - email"`). Regra: PIN opcional, mas se informado `pinValido.matches("\\d{4}")` (expressão regular: exatamente 4 dígitos).
- **TituloController:** [[Conversor]]`.paraIntOuNulo(duracao, ...)`: duração vazia vira `null` (séries).

---
⬅ [[PlanoController]] · [[00 - Painel]] · [[HistoricoController]] ➡
