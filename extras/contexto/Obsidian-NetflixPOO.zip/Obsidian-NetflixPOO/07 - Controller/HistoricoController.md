---
tags: [netflix, codigo, controller, classe]
---

# HistoricoController

*Seção 6.3: HistoricoController (CRUD principal)* · Pasta: [[Pacote controller]]


- Três DAOs: [[HistoricoVisualizacaoDAO]], [[PerfilDAO]] e [[TituloDAO]] (estes dois só para os combos).
- `listarComNomes()`, `opcoesPerfis()`, `opcoesTitulos()` (formato `"id - nome"`).
- `inserir`, `atualizar`, `eliminar`: mesmo molde.
- `montar(...)`: converte as datas e o minuto e aplica **regras de negócio**:
  - Início e última visualização **não são digitados**: o `HistoricoVisualizacaoDAO` grava `NOW()` no INSERT (as duas) e só a última no UPDATE.
  - `if (minuto < 0)` → "O minuto de parada não pode ser negativo."
  - [[Conversor]]`.extrairId(perfil, "Perfil")` e `extrairId(titulo, "Título")`: as FKs.

---
⬅ [[Controllers de Conta, Perfil e Titulo]] · [[00 - Painel]] · [[RelatorioController]] ➡
