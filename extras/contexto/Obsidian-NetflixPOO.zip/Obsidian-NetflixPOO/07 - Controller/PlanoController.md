---
tags: [netflix, codigo, controller, classe]
---

# PlanoController

*Seção 6.1: PlanoController (referência)* · Pasta: [[Pacote controller]]


- `private final PlanoDAO dao = new PlanoDAO();`: o Controller **tem um** DAO (agregação); `final` = a referência não muda.
- `listar()`: `try { return dao.listar(); } catch (SQLException e) { throw new RuntimeException("Erro ao listar planos: " + ..., e); }`. Como `listar` devolve uma **lista** (não uma mensagem), o erro sobe como `RuntimeException` e a [[TelaCrud]]`.recarregar()` mostra.
- `inserir(String nome, String valorMensal, String qualidadeMaxima, String telas, String permiteDownload)`: `dao.inserir(montar(...)); return "Plano inserido com sucesso!";` (não recebe descrição: ela é gerada).
  - `catch (IllegalArgumentException e) { return e.getMessage(); }`: erro de **validação** (Conversor), antes do banco.
  - `catch (SQLException e) { return "Erro no banco de dados: " + e.getMessage(); }`: erro do **banco**, inclusive MySQL desligado (na V2 a [[ConnectionFactory]] lança `SQLException`).
- `atualizar(String id, ...)`: [[Conversor]]`.paraId(id)` (nada selecionado → mensagem), `montar(...)`, `p.setIdPlano(idPlano)`, `dao.atualizar(p)`.
- `eliminar(String id)`: se a FK impedir, devolve "Não foi possível remover (o plano pode estar em uso por uma conta)".
- `gerarDescricao(String telas, String qualidadeMaxima)` (público): **regra de negócio**. Converte `telas` em `int` (se for inválido ou menor que 1, devolve `""`), escolhe o texto do número (`"Uma tela"`, `"Duas telas"`, `"Três telas"`, `"Quatro telas"` ou `n + " telas"`) e devolve `telasTexto + ", qualidade " + qualidadeMaxima`. É chamado pela tela (para mostrar ao vivo) e por `montar(...)` (para gravar).
- `montar(...)` (privado): valida `telas >= 1` ("O plano precisa ter pelo menos 1 tela simultânea.") e cria `new Plano(Conversor.obrigatorio(nome, "Nome"), gerarDescricao(telas, qualidadeMaxima), Conversor.paraDecimal(...), qualidadeMaxima, quantidadeTelas, Conversor.paraBoolean(...), Conversor.paraData(...))`.

---
⬅ [[Pacote controller]] · [[00 - Painel]] · [[Controllers de Conta, Perfil e Titulo]] ➡
