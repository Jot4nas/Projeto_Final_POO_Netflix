---
tags: [netflix, codigo, controller]
---

# Pacote controller

*Seção 6 da documentação: Pacote controller*


O Controller é o "meio de campo":

```
View --(Strings digitadas)--> Controller --(objeto Model)--> DAO --> MySQL
```

Sempre nesta ordem: (1) recebe `String`; (2) valida e converte com o [[Conversor]]; (3) cria o Model e chama o DAO; (4) devolve uma **mensagem** (sucesso ou erro).

## Notas desta pasta

- [[PlanoController]]: PlanoController (referência)
- [[Controllers de Conta, Perfil e Titulo]]: ContaController, PerfilController, TituloController
- [[HistoricoController]]: HistoricoController (CRUD principal)
- [[RelatorioController]]: RelatorioController (novo: relatório da rotina principal)
- [[ConexaoController]]: ConexaoController (novo)

---
⬅ [[HistoricoVisualizacaoDAO]] · [[00 - Painel]] · [[PlanoController]] ➡
