---
tags: [netflix, v3, codigo, indice]
---

# Código da V3 · Índice (explicação de cada parte)

> [!info] O que é a V3
> **Mesma lógica da V2** (Model, DAO, Controller, Util e a mesma navegação), mas com a **View personalizada**: tema escuro, capas, avatares, cartões. Pasta `V3-visual\Netflix\src`. O que mudou está só em `view` (e em `Main`, que chama `Tema.aplicar()`).
>
> Model/DAO/Controller/Util da V3 = os da V2 (ver pastas 04 a 07). Aqui explicamos **só a View nova**.

## Mapa das classes de `view` (V3)

| Classe | Linhas | Faz | Nota |
|---|---|---|---|
| `Main` | pequena | Liga o Nimbus (`Tema.aplicar()`) e abre a `TelaConexao` dentro de `invokeLater` | [[V3 - Nimbus, UIManager e renderers]] |
| `Tema` | 544 | Cores, fontes, botão desenhado, estilos de campo/combo/tabela/rolagem | [[V3 - Tema]] |
| `Icone` | 62 | `enum` com ícones desenhados em código | [[V3 - Capa e Icone]] |
| `Capa` | 117 | Pôster: imagem do disco (com cache) ou capa desenhada | [[V3 - Capa e Icone]] |
| `PainelRolavel` | 129 | `Scrollable` + `QuebraLayout` | [[V3 - Visao, Visoes e PainelRolavel]] |
| `Visao` | 58 | Classe abstrata + interface `Acoes` | [[V3 - Visao, Visoes e PainelRolavel]] |
| `Visoes` | 707 | As 4 visões (Perfis, Contas, Histórico, Planos) | [[V3 - Visao, Visoes e PainelRolavel]] |
| `BarraNavegacao` | 102 | Barra do topo (com `ItemDoMenu`) | [[BarraNavegacao]] (V2 explica a lógica; a V3 só muda o visual) |
| `Navegador` | 66 | Troca de tela com fade | [[Navegador]] · [[Timer, glass pane e fade]] |
| `TelaCrud` | 455 | Tela base do CRUD (Template Method) + layout com visão | [[V3 - TelaCrud]] |
| `TelaPlano/Conta/Perfil/Titulo/Historico` | 60–110 | Telas filhas: campos + chamadas ao Controller + `criarVisao` | [[Telas filhas]] |
| `TelaPrincipal` | 373 | Tela **Início** (destaque + fileiras de capas) | [[V3 - TelaPrincipal (Início)]] |
| `TelaRelatorio` | 188 | Relatório por período com "chips" | [[TelaRelatorio]] |
| `TelaConexao` | 99 | Tela de conexão estilizada | [[TelaConexao]] |

## O que a V3 NÃO mudou (se o professor perguntar)
- **Nenhum SQL, DAO, Controller ou Model foi alterado** para o visual.
- As visões **leem o mesmo `DefaultTableModel`** da tabela. Trocar entre "Visual" e "Tabela" não consulta o banco.
- Os botões **Inserir / Salvar / Remover / Limpar** chamam os mesmos métodos (`inserir()`, `atualizar(id)`, `eliminar(id)`) → Controller → DAO.

## Ordem sugerida para estudar
1. [[V3 - Tema]] → como o tema é aplicado
2. [[V3 - Java2D e desenho]] → como se desenha um componente
3. [[V3 - TelaCrud]] → o layout com visão
4. [[V3 - Visao, Visoes e PainelRolavel]] → as visões
5. [[V3 - Capa e Icone]] → imagens e ícones
6. [[V3 - TelaPrincipal (Início)]]
7. [[V3 - Imagens, cache e rolagem]] (resumo dos recursos extras)

---
⬅ [[00 - Painel]] · [[Fora da aula - Índice]] · [[Front-end]]
