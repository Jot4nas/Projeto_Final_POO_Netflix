---
tags: [netflix, v3, codigo, telacrud]
---

# V3 · `TelaCrud` (a tela base com visão)

> [!info] Continua sendo o Template Method da V2
> Mesma classe abstrata, mesmos métodos abstratos (`carregarTabela`, `inserir`, `atualizar`, `eliminar`) e mesmos ganchos (`carregarCombos`, `definirPadroes`). Ver [[TelaCrud]] e [[Classe abstrata e Template Method]]. **Novidades da V3**: a classe `Visao`, o layout `montarComVisao` e o `AcoesDaTela`.

## Atributos

| Atributo | Para quê |
|---|---|
| `modelo` (`DefaultTableModel`) | A "planilha em memória". `isCellEditable` devolve `false` (tabela só de leitura) |
| `tabela` (`JTable`) | Só **desenha** o modelo; `SINGLE_SELECTION` = uma linha por vez |
| `campos` (`LinkedHashMap<String, JComponent>`) | rótulo → campo, **na ordem em que foram adicionados** (a ordem importa: igual à ordem das colunas) |
| `painelForm` (`GridLayout(0, 2, 20, 14)`) | Formulário: 2 colunas, linhas conforme necessário |
| `recarregandoTabela` (`boolean`) | `true` quando é o **programa** que mexe na seleção; evita sobrescrever o formulário |
| `visao` (`Visao`) | Forma visual opcional (null = só tabela) |

## `iniciar()` passo a passo

| # | O que faz |
|---|---|
| 1 | `painelForm`: margem e **3 colunas se tiver mais de 6 campos** (senão 2) |
| 2 | Cria 4 `Tema.Botao` (Inserir = `PRINCIPAL`, Atualizar = `SECUNDARIO`, Eliminar = `PERIGO`, Limpar = `FANTASMA`) |
| 3 | Liga os eventos com **lambdas**: `btnInserir.addActionListener(e -> mostrarResultado(inserir()))`. O botão **não tem lógica**: chama o método da filha e mostra a mensagem |
| 4 | `tabela.getSelectionModel().addListSelectionListener(...)`: ao clicar numa linha, `aoSelecionar()` copia as células para os campos. `getValueIsAdjusting()` evita disparar duas vezes durante o arraste |
| 5 | `visao = criarVisao(new AcoesDaTela())`: a filha devolve a visão (ou `null`) |
| 6 | Sem visão: topo (barra + cabeçalho + form + botões) e tabela no centro. Com visão: `montarComVisao(painelBotoes)` |
| 7 | `setSize(Math.min(1160, tela.width - 60), ...)`: tamanho máximo, mas nunca maior que a tela |
| 8 | `EXIT_ON_CLOSE` e `recarregar(true)` (lê o banco pela primeira vez) |

> [!warning] Por que `iniciar()` e não o construtor da base?
> Quando o construtor da mãe roda, os atributos da **filha** (o `controller`) ainda **não existem**. Por isso cada filha chama `iniciar()` no **fim** do próprio construtor.

## `montarComVisao`: o layout novo

```
┌───────────── BarraNavegacao + cabeçalho (NORTH) ─────────────┐
│ [Visual][Tabela]               │ Detalhes                    │
│ CardLayout:                    │ formulário (rolável)        │
│   "visual" → a Visao           │                             │
│   "tabela" → a JTable          │ [Inserir][Atualizar]...     │
└────────── CENTER ──────────────┴────────── EAST (480 px) ────┘
```
- `CardLayout` + `cartas.show(conteudo, "tabela")` alterna as duas formas. Ver [[V3 - Imagens, cache e rolagem]].
- `btnVisual.setTipo(...)` troca o estilo do botão (o ativo fica vermelho).
- O formulário vai dentro de `PainelRolavel` + `Tema.rolagemSimples` para rolar na vertical se não couber.

## `AcoesDaTela` (classe interna que implementa `Visao.Acoes`)

| Método | O que faz |
|---|---|
| `selecionar(linha)` | `tabela.setRowSelectionInterval(...)` → dispara o **mesmo** listener que preenche o formulário |
| `remover(linha)` | seleciona e chama `confirmarEliminar()` (a **mesma** pergunta do botão Eliminar) |
| `novo()` | `limpar()` + `visao.marcar(-1)` |

É o padrão **callback via interface**: a visão não conhece a `TelaCrud`, só a interface `Acoes`. Reaproveita toda a lógica existente.

## Os métodos privados

| Método | Faz |
|---|---|
| `confirmarEliminar()` | Sem seleção: o **Controller** devolve o aviso (sem perguntar). Com seleção: `JOptionPane.showConfirmDialog(... YES_NO_OPTION)`; só elimina se for `YES_OPTION` |
| `mostrarResultado(msg)` | `showMessageDialog(msg)`; se contém `"sucesso"`, limpa o formulário; senão **mantém** o que o usuário digitou |
| `recarregar(limpar)` | Guarda escolhas dos combos e a linha, faz `setRowCount(0)`, chama `carregarCombos()` e `carregarTabela()` (num `try/catch` de `RuntimeException`: banco fora do ar vira `JOptionPane`), ajusta colunas, `visao.atualizar()`; restaura ou limpa; `finally` volta `recarregandoTabela = false` |
| `limpar()` | Combos no 1º item, campos de texto vazios, `clearSelection()` e `definirPadroes()` |
| `idSelecionado()` | ID da coluna 0 da linha selecionada, ou `""` |
| `valor(rotulo)` | Lê o campo como `String` (`instanceof JComboBox` ou `JTextField`) |
| `nomeNaBarra()` | Converte "Histórico de Visualização" em "Histórico" para o botão da barra |

> [!codigo] Como responder
> **"A tela tem regra de negócio?"** — "Não. Só lê o que foi digitado, chama o método da filha (que chama o Controller) e mostra a mensagem devolvida."
>
> **"O que é a `Visao`?"** — "Outra forma de mostrar o mesmo modelo (cartões, avatares). Ela não acessa o banco nem o Controller: só avisa a tela, pela interface `Acoes`, quando o usuário clica."
>
> **"Por que `recarregandoTabela`?"** — "Quando recarregamos a tabela a seleção muda; sem o `boolean` o listener copiaria uma linha para o formulário e apagaria o que o usuário digitou."

---
⬅ [[Código V3 - Índice]] · [[TelaCrud]] · [[V3 - Visao, Visoes e PainelRolavel]]
