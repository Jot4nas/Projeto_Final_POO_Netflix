---
tags: [netflix, v3, codigo, visao]
---

# V3 · `Visao`, `Visoes` e `PainelRolavel`

## `Visao` (classe abstrata + interface)

```java
public abstract class Visao extends JPanel {
    public interface Acoes { void selecionar(int linha); void remover(int linha); void novo(); }
    protected final DefaultTableModel modelo;
    protected final Acoes acoes;
    public abstract void atualizar();
    public abstract void marcar(int linha);
```
| Peça | Explicação |
|---|---|
| `abstract class ... extends JPanel` | Uma visão **é** um painel. Abstrata: só as filhas existem |
| `interface Acoes` (aninhada) | Contrato com 3 métodos que a `TelaCrud` implementa. A visão **não conhece** a tela |
| `modelo` | O **mesmo** `DefaultTableModel` da tabela. A visão só **lê** |
| `atualizar()` (abstrato) | Reconstrói os desenhos a partir das linhas do modelo (chamado após recarregar) |
| `marcar(linha)` (abstrato) | Destaca o desenho da linha selecionada (-1 = nenhum) |
| `semId(linha, coluna)` | Tira o "3 - " do começo (`"3 - Premium"` → `"Premium"`): `indexOf(" - ")` + `matches("\\d+")` |
| `texto(linha, coluna)` | Lê a célula como `String` (vazio se `null`) |

## `Visoes` (as 4 visões)

`Visoes` é uma classe **final** com construtor privado, só para agrupar classes aninhadas `static`.

| Classe | Aba | Mostra |
|---|---|---|
| `Visoes.Perfis` (+ `Avatar`) | Perfis | Avatares coloridos com carinha (ou "KiDS"); "Novo perfil" no fim |
| `Visoes.Contas` (+ `CartaoConta`) | Contas | Cartões com e-mail, plano e status |
| `Visoes.Historico` (+ `LinhaHistorico`) | Histórico | Linhas com miniatura, perfil, título, conta, plano, progresso |
| `Visoes.Planos` (+ `Comparativo`) | Planos | Tabela comparativa dos planos |

### A base `Item` (compartilhada)
`private abstract static class Item extends JComponent`: um desenho clicável que representa **uma linha** do modelo.

| Trecho | Faz |
|---|---|
| `linha`, `acoes`, `selecionado`, `sobre` | Qual registro, quem avisar, estados |
| `setFocusable(true)` | Pode receber o foco do teclado |
| `MouseAdapter` (`mouseEntered`/`Exited`/`Pressed`) | Hover (`sobre = true; repaint()`) e clique (`aoClicar` → `acoes.selecionar(linha)`) |
| `KeyAdapter` | **Enter** ou **Espaço** escolhem o item (acessibilidade) |
| `FocusAdapter` | Redesenha ao ganhar/perder o foco (anel branco) |
| `contorno(g, w, h, arco)` | Vermelho = selecionado, branco = foco do teclado |

> `MouseAdapter`, `KeyAdapter` e `FocusAdapter` são classes prontas com os métodos vazios: sobrescrevemos só o que precisamos (em vez de implementar a interface inteira).

### Funções auxiliares (`private static`)
`preparar(g)` (cópia do `Graphics2D` + antialiasing), `cortar` (texto com "…"), `quebrar` (quebra em linhas pela largura), `textoCentralizado`.

### Como `atualizar()` cria os desenhos (exemplo Perfis)
```java
for (int l = 0; l < modelo.getRowCount(); l++) {
    Avatar a = new Avatar(l, acoes, texto(l, 2), semId(l, 1), "Sim".equals(texto(l, 5)),
            AVATARES[Math.abs(texto(l, 0).hashCode()) % AVATARES.length], false);
    avatares.add(a); lista.add(a);
}
lista.add(new Avatar(-1, acoes, "Novo perfil", "Cadastrar", false, AVATARES[0], true));
```
- Lê **colunas do modelo** (2 = nome, 1 = conta, 5 = perfil infantil) e cria um `Avatar` por linha.
- A cor vem do `hashCode()` do **ID** (resto por 4 cores): o mesmo perfil sempre tem a mesma cor.
- O último "Novo perfil" tem `linha = -1` e chama `acoes.novo()`.

## `PainelRolavel` e `QuebraLayout`
Ver [[V3 - Imagens, cache e rolagem]]: `implements Scrollable` (largura segue a janela) e `FlowLayout` que **quebra linha** e cresce em altura.

| Método de `Scrollable` | Valor | Por quê |
|---|---|---|
| `getScrollableTracksViewportWidth` | `true` | sem barra horizontal |
| `getScrollableTracksViewportHeight` | `false` | rola na vertical |
| `getScrollableUnitIncrement` | `24` | pixels por "clique" da roda do mouse |
| `getScrollableBlockIncrement` | `visivel.height - 24` | pixels por "Page Down" |

> [!codigo] Como responder
> **"Por que `Visao` é abstrata?"** — "Define o que toda visão precisa fazer (`atualizar` e `marcar`); cada aba implementa do seu jeito. É herança e polimorfismo: a `TelaCrud` usa só o tipo `Visao`."
>
> **"Por que uma interface `Acoes`?"** — "Para a visão avisar a tela sem depender dela. Quem implementa é a `AcoesDaTela`, dentro da `TelaCrud`, e reaproveita a lógica dos botões."
>
> **"Isso mexe no banco?"** — "Nunca. Lê o `DefaultTableModel`."

---
⬅ [[Código V3 - Índice]] · [[V3 - TelaCrud]] · [[V3 - Java2D e desenho]] · [[Visões das abas]]
