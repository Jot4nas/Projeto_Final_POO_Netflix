---
tags: [netflix, v3, codigo, tema]
---

# V3 · `Tema` (544 linhas, o "arquivo de estilo")

> [!info] Ideia
> Uma classe **só com `static`** (construtor privado) que concentra **cores, fontes e estilos**. Assim mudar o visual é mexer em **um** lugar, e as telas só chamam `Tema.algo(...)`. Ver também [[Tema]] (visão geral) e [[V3 - Nimbus, UIManager e renderers]] (`aplicar()`).

## Blocos da classe

| Bloco | Conteúdo | Para quê |
|---|---|---|
| Cores `public static final Color` | `FUNDO 0x141414`, `PAINEL`, `CAMPO`, `SUPERFICIE`, `BORDA`, `TEXTO`, `TEXTO_SUAVE`, `VERMELHO 0xe50914` e variações (hover/pressionado), `LINHA_ALTERNADA` | Constantes: nenhuma tela escreve número de cor |
| Fontes | `FONTE` (14), `FONTE_NEGRITO`, `FONTE_TITULO` (24), `FONTE_PEQUENA` (12) via `deriveFont` | Uma única fonte base |
| `escolherFonte` | Procura Segoe UI, SF Pro Text... instalada | Funciona em qualquer sistema |
| `aplicar()` | Liga o Nimbus e troca as chaves do `UIManager` | Chamado em `Main` **antes** das janelas |
| `TipoBotao` (`enum`) | `PRINCIPAL`, `SECUNDARIO`, `PERIGO`, `FANTASMA` | Cada tipo tem cores |
| `Botao extends JButton` | Botão arredondado com hover/pressionado/foco | Todos os botões |
| `estilizarCampo` | Cores, borda e `FocusAdapter` (borda vermelha ao focar) | `JTextField` |
| `estilizarCombo` | `BasicComboBoxUI` + renderer escuro | `JComboBox` |
| `estilizarComponente(c)` | Decide se é campo ou combo e chama o certo | `TelaCrud.adicionarCampo` |
| `rotulo(texto)` | `JLabel` pequeno em cinza | rótulos do formulário |
| `cabecalho(titulo, apoio)` | Faixa com degradê, título e texto de apoio | topo de cada tela |
| `chip(rotulo, valor)` | Cartãozinho "Total: 521" | relatório |
| `fundoDaJanela(janela)` | Cor de fundo do `contentPane` | `TelaCrud` |
| `estilizarTabela(tabela)` | Cabeçalho, linhas alternadas, seleção vermelha, altura das linhas | `JTable` |
| `rolagem(tabela)`, `rolagemSimples(componente)`, `rolagemHorizontal(componente)` | `JScrollPane` com `BarraFina` e sem borda | rolagens |
| `BarraFina extends BasicScrollBarUI` | Barra de rolagem fina, sem setas | todas as rolagens |
| `ajustarColunas(tabela)` | Mede o texto de cada coluna (`FontMetrics`) e define largura | depois de carregar |

## Pontos que merecem atenção

- **`public static final`**: constante global (um só valor, da classe, que não muda). Convenção: nome em MAIÚSCULAS.
- **`deriveFont(...)`**: cria uma nova `Font` a partir de outra mudando estilo/tamanho; a original não muda.
- **Hex em `Color`**: `new Color(0x141414)` = RGB em hexadecimal (14,14,14); `0xe50914` = vermelho da Netflix.
- **Por que uma classe de utilidades?** Evita repetir estilo em 6 telas: o *DRY* (don't repeat yourself) do visual.
- **`TelaCrud.adicionarCampo(...)` chama `Tema.estilizarComponente(c)`**: por isso as telas filhas não sabem de cor nenhuma.

> [!codigo] Como responder
> **"O que é a classe `Tema`?"** — "Uma classe utilitária com tudo do visual: cores, fontes e métodos que estilizam botões, campos, tabelas e rolagens. As telas só chamam esses métodos."
>
> **"O que mudaria se quiséssemos outro tema?"** — "Só a `Tema`: trocar as constantes de cor. Nenhuma tela ou Controller muda."

---
⬅ [[Código V3 - Índice]] · [[Tema]] · [[V3 - Java2D e desenho]]
