---
tags: [netflix, v3, codigo, capa, icone]
---

# V3 · `Capa` e `Icone`

## `Capa` (`final class`, métodos `static`)

| Membro | Faz |
|---|---|
| `CORES` (`Color[]` com 8 cores) | Paleta das capas sem imagem |
| `CACHE` (`Map<String, BufferedImage>`) | Imagens já lidas (`null` = não existe). Ver [[V3 - Imagens, cache e rolagem]] |
| `cor(nome)` | `CORES[Math.abs(nome.hashCode()) % CORES.length]` → o mesmo título tem sempre a mesma cor |
| `imagem(nome)` | Procura `capas/NOME.jpg` e `.png`, lê com `ImageIO`, guarda na cache |
| `desenhar(g, nome, x, y, w, h, arco)` | Desenha a capa com cantos arredondados |
| `desenhar(..., comTexto)` | `false` = só o fundo (atrás do texto do destaque) |
| `quebrar(texto, fm, largura)` | Divide o título em linhas que caibam |

### `desenhar` linha a linha
1. `Graphics2D g2 = (Graphics2D) g.create()` → cópia, para não alterar o original.
2. `Shape forma = new RoundRectangle2D.Float(x, y, w, h, arco, arco); g2.clip(forma)` → **recorta** o desenho num retângulo arredondado.
3. `BufferedImage img = imagem(nome)`.
4. Se existe imagem: escala `Math.max(w/larg, h/alt)` ("cover") e `drawImage` centralizada.
5. Se não existe: `GradientPaint` (de `c.brighter()` para `c.darker().darker()`), um **"N" vermelho** no canto e o **título centralizado** em linhas (`FontMetrics` mede o texto).
6. `g2.dispose()`.

> [!tip] Por que funciona sem as imagens?
> As imagens dos pôsteres têm **direitos autorais**, então não estão no GitHub. Sem a pasta `capas`, o sistema desenha as capas em código e funciona igual.

## `Icone` (`enum`)

```java
public enum Icone { CASA, PLANOS, CONTAS, PERFIS, TITULOS, HISTORICO, RELATORIO, RESTAURAR;
    public void desenhar(Graphics2D g, int x, int y, int tamanho, Color cor) { ... switch (this) { ... } }
```
| Trecho | Faz |
|---|---|
| `enum` com **método** | Um `enum` pode ter métodos; cada constante (`Icone.CASA`) é um objeto |
| `g2.translate(x, y)` + `g2.scale(tamanho / 24.0, ...)` | Move a origem e escala: desenhamos sempre numa **grade 24×24**, e funciona em qualquer tamanho |
| `new BasicStroke(2f, CAP_ROUND, JOIN_ROUND)` | Traço de 2 px com pontas e junções arredondadas |
| `switch (this)` | Escolhe o desenho conforme a constante |
| `Path2D.Float` + `moveTo`/`lineTo` | Caminho de linhas (telhado, aba do envelope, ponteiros) |
| `drawRoundRect`, `drawOval`, `drawArc`, `drawLine`, `fillRoundRect` | Formas simples (cartão, cabeça, ombros, tira de filme, barras do gráfico) |

> Na V3 só são usados `CASA`, `PLANOS`, `CONTAS` nos cartões/visões; os demais são para futuros menus (ficaram no `enum`).

> [!codigo] Como responder
> **"Os ícones são imagens?"** — "Não. São desenhados em código com `Path2D` e formas do Java2D numa grade 24×24; assim ficam nítidos em qualquer tamanho e não dependem de arquivos."
>
> **"Por que `enum`?"** — "Porque são um conjunto fixo de valores; cada um sabe se desenhar."

---
⬅ [[Código V3 - Índice]] · [[V3 - Java2D e desenho]] · [[Início e capas]]
