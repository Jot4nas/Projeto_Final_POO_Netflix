---
tags: [painel, netflix]
---

# 🏠 Netflix POO: sistema de gerenciamento

> [!tip] Comece por aqui
> Novo no projeto? Leia [[Visão geral]] e [[Requisitos da proposta]]. Para continuar em outro chat do Claude: [[HANDOFF_CONTEXTO]].
> **Antes da apresentação:** [[Rodar e testar]] e [[Perguntas do professor]].

> [!codigo] O caminho de um clique
> [[TelaCrud]] → [[PlanoController]] → [[PlanoDAO]] → [[ConnectionFactory]] → MySQL. Rotina principal: [[HistoricoVisualizacaoDAO]] (INNER JOIN), [[HistoricoController]] e [[Telas filhas|TelaHistorico]]. Relatório: [[RelatorioController]] e [[TelaRelatorio]].

> [!fonte] Tecnologias
> Java 11+ · Swing (`JFrame`, `JTable`, `DefaultTableModel`) · JDBC com `PreparedStatement` · MySQL 8 · MVC com DAO. Driver: `mysql-connector-j-9.3.0` (já dentro do `Netflix.jar`).

> [!decisao] O que mudou em 30/10/2026
> Pasta `V2` virou `Projeto` no GitHub · descrição do plano gerada automaticamente ([[PlanoController]]`.gerarDescricao`) · `Netflix.jar` refeito · sistema testado contra um MySQL de verdade (79 verificações automáticas passaram).

> [!info] Front-end (pasta `Projeto (front-end)` do GitHub)
> Como foi feito o visual novo, peça por peça: [[Front-end]]. A versão padrão (`Projeto`) tem a mesma navegação: [[Nota V2]].

> [!warning] Ainda falta
> Abrir o `Netflix.jar` e testar a interface com a senha do MySQL de cada computador. Treinar as perguntas: cada aluno responde 2 (0,5 ponto cada).

> [!info] Datas e links
> [Repositório no GitHub](https://github.com/lebedeff-dev/Projeto_Final_POO_Netflix) · Proposta: [[Requisitos da proposta]]

## Mapa do vault
- **01 - Proposta:** [[Requisitos da proposta]]
- **02 - Visão geral:** [[O que mudou da V1 para a V2]], [[Visão geral]]
- **03 - Banco de dados:** [[Banco de dados]]
- **04 - Util:** [[Pacote util]], [[ConnectionFactory]], [[CriadorBanco]], [[Conversor]]
- **05 - Model:** [[Pacote model]]
- **06 - DAO:** [[Pacote dao]], [[Conceitos de DAO e JDBC]], [[PlanoDAO]], [[ContaDAO]], [[PerfilDAO]], [[TituloDAO]], [[HistoricoVisualizacaoDAO]]
- **07 - Controller:** [[Pacote controller]], [[PlanoController]], [[Controllers de Conta, Perfil e Titulo]], [[HistoricoController]], [[RelatorioController]], [[ConexaoController]]
- **08 - View:** [[Pacote view]], [[Conceitos de Swing]], [[Main]], [[TelaConexao]], [[TelaPrincipal]], [[TelaCrud]], [[Telas filhas]], [[TelaRelatorio]]
- **09 - Integração Java-MySQL:** [[Integração Java-MySQL]]
- **10 - Conceitos de POO:** [[Conceitos de POO]], [[Classe e objeto]], [[Encapsulamento]], [[Visibilidade]], [[Herança]], [[Polimorfismo]], [[Classe abstrata]], [[Sobrescrita e sobrecarga]], [[Late binding]], [[Mensagem]], [[Associação e agregação]], [[Abstração]]
- **11 - Uso:** [[Gerar a build]], [[Rodar e testar]]
- **12 - Apresentação:** [[Perguntas do professor]], [[Perguntas - Fluxo geral]], [[Perguntas - Banco de dados]], [[Perguntas - util]], [[Perguntas - model]], [[Perguntas - dao]], [[Perguntas - controller]], [[Perguntas - view]], [[Perguntas - Mostre no código]], [[Correções da revisão]]
- **14 - Fora da aula:** [[Fora da aula - Índice]] (tudo o que usamos e o professor não passou, linha a linha)
- **15 - Roteiro:** [[Roteiro - V2]], [[Roteiro - V3]], [[Perguntas prováveis do professor]]
- **16 - Código V3:** [[Código V3 - Índice]] (explicação de cada classe da `view` da V3)
- **Raiz:** [[LEIA-ME]], [[HANDOFF_CONTEXTO]]

Para abrir o grafo, use `Ctrl+G`. As cores separam as pastas.

## Roteiro de estudo para a apresentação

> [!tip] Rota rápida de véspera
> 1) [[Roteiro - V2]] e [[Roteiro - V3]] (o que clicar e falar) · 2) [[Perguntas prováveis do professor]] · 3) [[Fora da aula - Índice]] (o que ele não ensinou) · 4) [[Código V3 - Índice]] (só se for apresentar a V3).

1. [[Visão geral]]: o que o sistema faz e como o MVC está dividido.
2. [[Banco de dados]]: tabelas, PK, FK e o INNER JOIN.
3. Siga o clique: [[TelaCrud]] → [[PlanoController]] → [[PlanoDAO]] → [[ConnectionFactory]].
4. Rotina principal e relatório: [[HistoricoVisualizacaoDAO]], [[HistoricoController]], [[RelatorioController]], [[TelaRelatorio]].
5. [[Integração Java-MySQL]]: o que o professor mais cobra.
6. [[Conceitos de POO]] e [[Perguntas do professor]].

## Status
- [x] 4 CRUDs simples completos (Plano, Conta, Perfil, Título)
- [x] CRUD principal completo (Histórico de Visualização)
- [x] Consulta com INNER JOIN mostrando nomes
- [x] Relatório da rotina principal (por período e por perfil, com .txt)
- [x] Banco MySQL com PK, FK, dados de exemplo e script SQL
- [x] Tela de conexão e banco criado automaticamente
- [x] `Netflix.jar` pronto e código no GitHub
- [x] Documentação completa e este vault
- [x] Testes automáticos contra MySQL (conexão, CRUDs, regras, JOIN, relatório)
- [ ] Testar a interface (cliques) no computador da apresentação
- [ ] Todos do grupo treinarem as [[Perguntas do professor|perguntas]]
