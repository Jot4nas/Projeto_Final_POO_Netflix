---
tags: [netflix, codigo, model]
aliases: [Plano, Conta, Perfil, Titulo, HistoricoVisualizacao]
---

# Pacote model

*Seção 4 da documentação: Pacote model (entidades)*


Cada classe representa **uma linha** de uma tabela. Só guarda dados: atributos privados (**encapsulamento**), construtores, getters e setters. Nenhuma tem SQL, tela ou regra de negócio.

## 4.1 Padrões que se repetem (explicados uma vez)

- `package model;`: a classe pertence ao pacote `model`.
- `private <tipo> atributo;`: só a própria classe acessa; o resto usa getter/setter. Isso é **encapsulamento**.
- **Construtor vazio** `public Plano() { }`: usado pelo DAO ao ler do banco (cria vazio e preenche com `setX`).
- **Construtor completo (sem o id):** usado pelo Controller; `this.nome = nome;` (o `this` diferencia o atributo do parâmetro). O id fica de fora porque o banco gera. Dois construtores com parâmetros diferentes = **sobrecarga**.
- **Getter** `getX()` (para boolean, `isX()`) e **setter** `setX(valor)`.
- `@Override public String toString()`: sobrescreve o método herdado de `Object` para o objeto aparecer pelo nome.

## 4.2 Mapeamento tipo SQL → tipo Java

| MySQL | Java | Por quê |
|---|---|---|
| INT, SMALLINT, TINYINT | `int` | inteiros |
| VARCHAR, CHAR, TEXT, ENUM | `String` | textos (ENUM vira o texto do valor) |
| DECIMAL | `BigDecimal` | decimal exato; `double` arredonda mal dinheiro |
| TINYINT(1) | `boolean` | 0 = falso, 1 = verdadeiro |
| DATE | `LocalDate` | só data |
| DATETIME | `LocalDateTime` | data e hora |
| INT que aceita NULL | `Integer` | tipo objeto pode ser `null`; `int` não |

## 4.3 As cinco classes

| Classe | Atributos | Observações |
|---|---|---|
| `Plano` | idPlano, nome, descricao, valorMensal (BigDecimal), qualidadeMaxima, telasSimultaneas, permiteDownload (boolean) | `toString()` devolve `nome` |
| `Conta` | idConta, **idPlano (FK)**, email, senhaHash, telefone (pode ser null), pais, status | **novo:** `nomePlano`, campo **só de exibição** preenchido pelo INNER JOIN do [[ContaDAO]]`.listar()` |
| `Perfil` | idPerfil, **idConta (FK)**, nome, avatar, perfilInfantil, pin | **novo:** `emailConta`, só de exibição (INNER JOIN do [[PerfilDAO]]`.listar()`) |
| `Titulo` | idTitulo, nome, sinopse, tipo, anoLancamento (int), classificacaoIndicativa, **duracaoMinutos (Integer)**, idiomaOriginal, dataAdicaoCatalogo, disponivel | `Integer` porque séries têm duração NULL |
| `HistoricoVisualizacao` | idVisualizacao, **idPerfil e idTitulo (FKs)**, dataInicio, dataUltimaVisualizacao, minutoParada, concluido, dispositivo | `nomePerfil`, `nomeTitulo`, `emailConta` e `nomePlano` só de exibição (JOIN). Representa a **tabela associativa** N:N |

> **Campos só de exibição** (`nomePlano`, `emailConta`, `nomePerfil`, `nomeTitulo`): **não existem nas tabelas**. São preenchidos apenas pelos SELECT com JOIN para a tela mostrar nomes. No INSERT/UPDATE são ignorados. Guardamos só o id da FK (e não um objeto `Plano` inteiro) para espelhar exatamente a tabela.

---
⬅ [[Conversor]] · [[00 - Painel]] · [[Pacote dao]] ➡
