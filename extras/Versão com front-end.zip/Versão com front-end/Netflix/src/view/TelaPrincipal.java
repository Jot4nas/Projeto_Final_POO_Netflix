package view;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import controller.ConexaoController;
import controller.HistoricoController;
import controller.TituloController;
import model.HistoricoVisualizacao;
import model.Titulo;
import view.Tema.Botao;
import view.Tema.TipoBotao;

/**
 * INICIO: a tela principal, inspirada na pagina inicial do app da Netflix.
 *  - barra no topo: a marca NETFLIX e um botao para cada tela (Planos, Contas, Perfis, Titulos,
 *    Historico e Relatorio), mais o botao de restaurar os dados de exemplo;
 *  - destaque: um titulo do catalogo, em tamanho grande;
 *  - fileiras de capas: "Populares na Netflix" (todos os titulos) e "Continuar assistindo como ..."
 *    (o que o ultimo perfil assistiu, com a barra de progresso).
 *
 * O Historico de Visualizacao e a rotina principal do sistema, mas aqui ele e uma tela como as outras
 * (botao na barra do topo); o texto "CRUD principal" nao aparece, so na documentacao.
 *
 * MVC: esta tela so MOSTRA o que os Controllers devolvem (listas de Titulo e de historico) e abre as
 * outras telas. Nao tem SQL nem regra de negocio.
 */
public class TelaPrincipal extends JFrame {

    private final ConexaoController conexaoController = new ConexaoController();

    private List<Titulo> titulos = new ArrayList<>();
    private List<HistoricoVisualizacao> historico = new ArrayList<>();

    private Destaque destaque;                 // o banner do topo (muda quando se clica numa capa)
    private JScrollPane rolagemPrincipal;      // para voltar ao topo e mostrar o destaque novo

    public TelaPrincipal() {
        super("Netflix - Sistema de Gerenciamento");
        carregarDados();

        montarTela();

        Dimension tela = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(Math.min(1180, tela.width - 60), Math.min(780, tela.height - 80));
        setMinimumSize(new Dimension(1000, 600));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE); // fechar o Inicio encerra o programa
    }

    /** Monta a barra do topo e o conteudo rolavel (chamado ao abrir e depois de restaurar os dados). */
    private void montarTela() {
        JPanel raiz = new JPanel(new BorderLayout());
        raiz.setBackground(Tema.FUNDO);
        raiz.add(criarBarraSuperior(), BorderLayout.NORTH);
        rolagemPrincipal = Tema.rolagemSimples(criarConteudo());
        rolagemPrincipal.setBorder(BorderFactory.createEmptyBorder());
        raiz.add(rolagemPrincipal, BorderLayout.CENTER);
        setContentPane(raiz);
    }

    /** Busca nos Controllers o que a tela mostra; se o banco falhar, as fileiras ficam vazias. */
    private void carregarDados() {
        try {
            titulos = new TituloController().listar();
            historico = new HistoricoController().listarComNomes();
        } catch (RuntimeException e) {
            titulos = new ArrayList<>();
            historico = new ArrayList<>();
        }
    }

    // =====================================================================================
    // Acoes (uma por tela). Os botoes do topo, o destaque e as capas chamam os mesmos metodos.
    // =====================================================================================

    private void abrirTitulos() { Navegador.ir(this, new TelaTitulo()); }
    private void abrirHistorico() { Navegador.ir(this, new TelaHistorico()); }

    private void restaurar() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Isso apaga TODOS os dados e volta aos dados de exemplo. Continuar?",
                "Restaurar dados de exemplo", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, conexaoController.restaurarDadosExemplo());
            carregarDados();
            montarTela(); // desenha de novo com os dados restaurados
            revalidate();
            repaint();
        }
    }

    // A barra do topo e a mesma de todas as telas (BarraNavegacao); aqui so acrescentamos "Restaurar dados".
    private JPanel criarBarraSuperior() {
        BarraNavegacao.ItemDoMenu restaurar = new BarraNavegacao.ItemDoMenu("Restaurar dados", false);
        restaurar.addActionListener(e -> restaurar());
        return new BarraNavegacao(this, "Início", restaurar);
    }

    // =====================================================================================
    // Conteudo: destaque + fileiras
    // =====================================================================================

    private JPanel criarConteudo() {
        PainelRolavel conteudo = new PainelRolavel(null);
        conteudo.setLayout(new BoxLayout(conteudo, BoxLayout.Y_AXIS));
        conteudo.setOpaque(true);
        conteudo.setBackground(Tema.FUNDO);

        if (!titulos.isEmpty()) {
            destaque = new Destaque(titulos.get(0));
            conteudo.add(destaque);
        }

        // Fileira 1: todos os titulos do catalogo (capa vertical)
        // Clicar numa capa coloca aquele titulo no destaque do topo (nao abre outra tela).
        List<CartaDeCapa> populares = new ArrayList<>();
        for (Titulo t : titulos) {
            CartaDeCapa capa = new CartaDeCapa(t.getNome(), t.getClassificacaoIndicativa() + "+  •  " + t.getAnoLancamento(),
                    -1, 170, 250, null);
            capa.addActionListener(e -> {
                destaque.mostrar(t);
                for (CartaDeCapa c : populares) {
                    c.setEscolhida(c == capa); // contorno branco na capa escolhida
                }
                javax.swing.SwingUtilities.invokeLater(() -> rolagemPrincipal.getViewport().setViewPosition(new java.awt.Point(0, 0)));
            });
            if (t == titulos.get(0)) {
                capa.setEscolhida(true); // o primeiro ja comeca no destaque
            }
            populares.add(capa);
        }
        conteudo.add(fileira("Populares na Netflix", populares));

        // Fileira 2: o que o perfil mais recente assistiu (capa horizontal com a barra de progresso)
        HistoricoVisualizacao ultimo = null;
        for (HistoricoVisualizacao h : historico) {
            if (ultimo == null || h.getDataUltimaVisualizacao().isAfter(ultimo.getDataUltimaVisualizacao())) {
                ultimo = h;
            }
        }
        if (ultimo != null) {
            Map<Integer, Titulo> porId = new HashMap<>();
            for (Titulo t : titulos) {
                porId.put(t.getIdTitulo(), t);
            }
            List<CartaDeCapa> continuar = new ArrayList<>();
            for (HistoricoVisualizacao h : historico) {
                if (h.getIdPerfil() != ultimo.getIdPerfil()) {
                    continue;
                }
                Titulo t = porId.get(h.getIdTitulo());
                Integer duracao = t == null ? null : t.getDuracaoMinutos();
                // progresso: minuto de parada / duracao (series nao tem duracao: mostra um terco)
                double progresso = h.isConcluido() ? 1.0
                        : duracao != null && duracao > 0 ? Math.min(1.0, (double) h.getMinutoParada() / duracao) : 0.33;
                continuar.add(new CartaDeCapa(h.getNomeTitulo(), "parou no minuto " + h.getMinutoParada(),
                        progresso, 290, 164, e -> abrirHistorico()));
            }
            conteudo.add(fileira("Continuar assistindo como " + ultimo.getNomePerfil(), continuar));
        }
        conteudo.add(Box.createVerticalStrut(30));
        return conteudo;
    }

    /** Titulo da fileira e, embaixo, as capas lado a lado. */
    private JPanel fileira(String titulo, List<CartaDeCapa> capas) {
        JLabel rotulo = new JLabel(titulo);
        rotulo.setFont(Tema.FONTE_NEGRITO.deriveFont(19f));
        rotulo.setForeground(Tema.TEXTO);
        rotulo.setBorder(BorderFactory.createEmptyBorder(0, 40, 10, 0));

        JPanel linha = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        linha.setOpaque(false);
        linha.setBorder(BorderFactory.createEmptyBorder(0, 26, 12, 24));
        for (CartaDeCapa c : capas) {
            linha.add(c);
        }

        JPanel secao = new JPanel(new BorderLayout());
        secao.setOpaque(false);
        secao.setBorder(BorderFactory.createEmptyBorder(22, 0, 0, 0));
        secao.add(rotulo, BorderLayout.NORTH);
        secao.add(Tema.rolagemHorizontal(linha), BorderLayout.CENTER); // se nao couber, rola para o lado
        secao.setAlignmentX(Component.LEFT_ALIGNMENT);
        secao.setMaximumSize(new Dimension(Integer.MAX_VALUE, secao.getPreferredSize().height + 40));
        return secao;
    }

    // =====================================================================================
    // Componentes visuais (desenhados com Java2D; continuam sendo JButton/JPanel)
    // =====================================================================================

    /** Capa clicavel: a imagem (ou capa desenhada), nome e uma linha de apoio; opcionalmente uma barra de progresso. */
    private static final class CartaDeCapa extends JButton {
        private final String nome;
        private final String apoio;
        private final double progresso; // -1 = sem barra
        private boolean escolhida;      // true = esta e a capa mostrada no destaque

        CartaDeCapa(String nome, String apoio, double progresso, int largura, int altura, ActionListener acao) {
            super(nome);                       // o texto do JButton e o nome (leitores de tela e testes)
            this.nome = nome;
            this.apoio = apoio;
            this.progresso = progresso;
            setPreferredSize(new Dimension(largura, altura + 44));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            setToolTipText(nome);
            if (acao != null) {
                addActionListener(acao);
            }
        }

        void setEscolhida(boolean valor) {
            escolhida = valor;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight() - 44;
            boolean sobre = getModel().isRollover();
            Capa.desenhar(g2, nome, 0, 0, w, h, 10);
            if (progresso >= 0) {                           // barra de progresso vermelha na base da capa
                g2.setColor(new Color(0, 0, 0, 150));
                g2.fillRect(0, h - 5, w, 5);
                g2.setColor(Tema.VERMELHO);
                g2.fillRect(0, h - 5, (int) (w * progresso), 5);
            }
            if (sobre || isFocusOwner() || escolhida) {     // contorno branco no hover, no foco do teclado e na capa escolhida
                g2.setColor(new Color(255, 255, 255, isFocusOwner() || escolhida ? 255 : 190));
                g2.setStroke(new BasicStroke(isFocusOwner() || escolhida ? 3f : 2f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, 10, 10);
            }
            g2.setColor(Color.WHITE);
            g2.setFont(Tema.FONTE_NEGRITO.deriveFont(14f));
            g2.drawString(cortar(nome, g2.getFontMetrics(), w - 4), 2, h + 20);
            g2.setColor(Tema.TEXTO_SUAVE);
            g2.setFont(Tema.FONTE_PEQUENA);
            g2.drawString(cortar(apoio, g2.getFontMetrics(), w - 4), 2, h + 37);
            g2.dispose();
        }

        private static String cortar(String texto, java.awt.FontMetrics fm, int largura) {
            String cortado = texto;
            while (cortado.length() > 1 && fm.stringWidth(cortado) > largura) {
                cortado = cortado.substring(0, cortado.length() - 1);
            }
            return cortado.equals(texto) ? texto : cortado + "…";
        }
    }

    /** Destaque no topo da pagina: o titulo, a sinopse e botoes, com a capa grande desaparecendo para a esquerda. */
    private final class Destaque extends JPanel {
        private Titulo titulo;
        private final JLabel nome = new JLabel();
        private final JLabel meta = new JLabel();
        private final JLabel sinopse = new JLabel();

        Destaque(Titulo titulo) {
            this.titulo = titulo;
            setOpaque(false);
            setLayout(new BorderLayout());
            setBorder(BorderFactory.createEmptyBorder(40, 40, 30, 40));
            setPreferredSize(new Dimension(100, 330));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 330));
            setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel etiqueta = new JLabel("EM DESTAQUE");
            etiqueta.setFont(Tema.FONTE_PEQUENA.deriveFont(Font.BOLD));
            etiqueta.setForeground(Tema.TEXTO_SUAVE);
            nome.setFont(Tema.FONTE_TITULO.deriveFont(Font.BOLD, 46f));
            nome.setForeground(Color.WHITE);
            meta.setFont(Tema.FONTE_NEGRITO);
            meta.setForeground(new Color(0x46d369)); // verde, como o "97% Match" do app
            sinopse.setFont(Tema.FONTE.deriveFont(16f));
            sinopse.setForeground(Tema.TEXTO);

            Botao ver = new Botao("Ver títulos", TipoBotao.PRINCIPAL);
            ver.addActionListener(e -> abrirTitulos());
            Botao historicoBtn = new Botao("Ver histórico", TipoBotao.SECUNDARIO);
            historicoBtn.addActionListener(e -> abrirHistorico());
            JPanel botoes = new JPanel();
            botoes.setLayout(new BoxLayout(botoes, BoxLayout.X_AXIS));
            botoes.setOpaque(false);
            botoes.add(ver);
            botoes.add(Box.createHorizontalStrut(12));
            botoes.add(historicoBtn);

            JPanel texto = new JPanel();
            texto.setOpaque(false);
            texto.setLayout(new BoxLayout(texto, BoxLayout.Y_AXIS));
            for (JLabel l : new JLabel[]{etiqueta, nome, meta, sinopse}) {
                l.setAlignmentX(Component.LEFT_ALIGNMENT);
                texto.add(l);
                texto.add(Box.createVerticalStrut(10));
            }
            botoes.setAlignmentX(Component.LEFT_ALIGNMENT);
            texto.add(Box.createVerticalStrut(6));
            texto.add(botoes);
            add(texto, BorderLayout.WEST);
            mostrar(titulo);
        }

        /** Troca o titulo do destaque: atualiza os textos e a capa do fundo. */
        void mostrar(Titulo novo) {
            titulo = novo;
            nome.setText(novo.getNome());
            meta.setText(novo.getClassificacaoIndicativa() + "+   •   " + novo.getAnoLancamento()
                    + "   •   " + novo.getTipo() + "   •   " + novo.getIdiomaOriginal());
            sinopse.setText("<html><body style='width:440px'>" + novo.getSinopse() + "</body></html>");
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            g2.setColor(Tema.FUNDO);
            g2.fillRect(0, 0, w, h);
            // 1) fundo: a capa esticada ate preencher a metade direita, bem escurecida (so como "clima")
            int lado = (int) (w * 0.58);
            Capa.desenhar(g2, titulo.getNome(), w - lado, 0, lado, h, 0, false);
            g2.setColor(new Color(20, 20, 20, 175));
            g2.fillRect(w - lado, 0, lado, h);
            // some para a esquerda (para o texto ficar legivel) e para baixo (liga ao resto da pagina)
            g2.setPaint(new GradientPaint(w - lado, 0, Tema.FUNDO, w - lado * 0.35f, 0, new Color(20, 20, 20, 0)));
            g2.fillRect(w - lado, 0, lado, h);
            g2.setPaint(new GradientPaint(0, h * 0.55f, new Color(20, 20, 20, 0), 0, h, Tema.FUNDO));
            g2.fillRect(0, 0, w, h);
            // 2) a capa inteira, sem cortes, na proporcao do pôster (largura = 67% da altura)
            int altura = h - 50, largura = (int) (altura * 0.675);
            Capa.desenhar(g2, titulo.getNome(), w - 70 - largura, 25, largura, altura, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
