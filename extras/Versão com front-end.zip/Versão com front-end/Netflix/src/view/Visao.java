package view;

import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;

/**
 * VISAO = uma forma visual (cartoes, avatares, lista...) de mostrar os MESMOS dados do DefaultTableModel
 * que a tabela mostra. Os dados continuam no modelo; a visao so os desenha de outro jeito.
 *
 * Cada tela de cadastro pode oferecer uma visao (ex.: Perfis mostra avatares coloridos). O usuario
 * alterna entre "Visual" e "Tabela" nos botoes acima da lista.
 *
 * A visao nunca acessa o banco nem o Controller: ela le o modelo e AVISA a tela (pela interface Acoes)
 * quando o usuario clica; quem seleciona, elimina ou limpa e a propria TelaCrud.
 */
public abstract class Visao extends JPanel {

    /** O que a visao pode pedir a tela quando o usuario interage (clique no cartao, no X, em "novo"). */
    public interface Acoes {
        /** O usuario escolheu o registro da linha 'linha' do modelo (para editar). */
        void selecionar(int linha);

        /** O usuario clicou em remover o registro da linha 'linha' (a tela pergunta antes de eliminar). */
        void remover(int linha);

        /** O usuario quer cadastrar um registro novo (limpa o formulario). */
        void novo();
    }

    protected final DefaultTableModel modelo;
    protected final Acoes acoes;

    protected Visao(DefaultTableModel modelo, Acoes acoes) {
        this.modelo = modelo;
        this.acoes = acoes;
        setOpaque(false);
    }

    /** Reconstroi os desenhos a partir das linhas atuais do modelo (chamado depois de carregar os dados). */
    public abstract void atualizar();

    /** Destaca o registro da linha selecionada (-1 = nenhum). */
    public abstract void marcar(int linha);

    /** Texto da celula do modelo, sem o "id - " do inicio ("3 - Premium" vira "Premium"). */
    protected String semId(int linha, int coluna) {
        Object valor = modelo.getValueAt(linha, coluna);
        String texto = valor == null ? "" : valor.toString();
        int corte = texto.indexOf(" - ");
        return corte > 0 && texto.substring(0, corte).matches("\\d+") ? texto.substring(corte + 3) : texto;
    }

    /** Texto da celula do modelo (vazio se for null). */
    protected String texto(int linha, int coluna) {
        Object valor = modelo.getValueAt(linha, coluna);
        return valor == null ? "" : valor.toString();
    }
}
