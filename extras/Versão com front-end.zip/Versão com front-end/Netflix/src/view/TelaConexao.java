package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import controller.ConexaoController;

/**
 * Primeira tela do sistema: pede os dados do MySQL de quem esta rodando.
 * Os campos ja vem com o que foi salvo da ultima vez (config.properties).
 * Ao conectar, o banco "netflix" e criado sozinho se ainda nao existir.
 */
public class TelaConexao extends JFrame {

    private final ConexaoController controller = new ConexaoController();

    private final JTextField campoServidor = new JTextField(controller.servidorSalvo());
    private final JTextField campoPorta = new JTextField(controller.portaSalva());
    private final JTextField campoUsuario = new JTextField(controller.usuarioSalvo());
    private final JPasswordField campoSenha = new JPasswordField(controller.senhaSalva());

    public TelaConexao() {
        super("Netflix - Conectar ao MySQL");

        // Os 4 campos, cada um com o rotulo em cima (servidor e porta lado a lado).
        for (javax.swing.text.JTextComponent campo :
                new javax.swing.text.JTextComponent[]{campoServidor, campoPorta, campoUsuario, campoSenha}) {
            Tema.estilizarCampo(campo);
        }
        JPanel linhaServidor = new JPanel(new BorderLayout(14, 0));
        linhaServidor.setOpaque(false);
        linhaServidor.add(celula("Servidor", campoServidor), BorderLayout.CENTER);
        JPanel colunaPorta = celula("Porta", campoPorta);
        colunaPorta.setPreferredSize(new java.awt.Dimension(110, colunaPorta.getPreferredSize().height));
        linhaServidor.add(colunaPorta, BorderLayout.EAST);

        JPanel painel = new JPanel(new GridLayout(0, 1, 0, 14));
        painel.setOpaque(false);
        painel.add(linhaServidor);
        painel.add(celula("Usuário", campoUsuario));
        painel.add(celula("Senha do MySQL", campoSenha));

        JButton btnConectar = new Tema.Botao("Conectar", Tema.TipoBotao.PRINCIPAL);
        btnConectar.addActionListener(e -> conectar());
        getRootPane().setDefaultButton(btnConectar); // Enter tambem conecta

        JPanel rodape = new JPanel(new BorderLayout());
        rodape.setOpaque(false);
        rodape.setBorder(BorderFactory.createEmptyBorder(22, 0, 0, 0));
        rodape.add(btnConectar, BorderLayout.CENTER);

        JPanel corpo = new JPanel(new BorderLayout());
        corpo.setOpaque(false);
        corpo.setBorder(BorderFactory.createEmptyBorder(22, 28, 28, 28));
        corpo.add(painel, BorderLayout.CENTER);
        corpo.add(rodape, BorderLayout.SOUTH);

        Tema.fundoDaJanela(this);
        add(Tema.cabecalho("Conectar ao MySQL", "Informe os dados do MySQL deste computador."), BorderLayout.NORTH);
        add(corpo, BorderLayout.CENTER);

        pack();
        setSize(Math.max(getWidth(), 460), getHeight());
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    /** Rotulo pequeno em cima e o campo embaixo. */
    private JPanel celula(String rotulo, javax.swing.JComponent campo) {
        JPanel p = new JPanel(new BorderLayout(0, 5));
        p.setOpaque(false);
        p.add(Tema.rotulo(rotulo), BorderLayout.NORTH);
        p.add(campo, BorderLayout.CENTER);
        return p;
    }

    private void conectar() {
        String erro = controller.conectar(campoServidor.getText(), campoPorta.getText(),
                campoUsuario.getText(), new String(campoSenha.getPassword()));
        if (erro == null) {          // deu certo: fecha esta tela e abre o menu
            if (controller.getAviso() != null) {
                JOptionPane.showMessageDialog(this, controller.getAviso(), "Aviso", JOptionPane.WARNING_MESSAGE);
            }
            dispose();
            new TelaPrincipal().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, erro, "Erro de conexão", JOptionPane.ERROR_MESSAGE);
        }
    }
}
