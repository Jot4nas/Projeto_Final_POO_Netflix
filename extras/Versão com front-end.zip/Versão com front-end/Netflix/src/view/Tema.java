package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.plaf.basic.BasicScrollBarUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.text.JTextComponent;

/**
 * TEMA VISUAL do sistema (tudo que e "aparencia" fica aqui, num lugar so).
 *
 * Por que uma classe separada?
 *  - As telas so dizem O QUE mostram (campos, tabela, botoes); a classe Tema diz COMO parece
 *    (cores, fonte, bordas). Mudar o visual = mexer so neste arquivo.
 *  - E parte da View do MVC: nao tem regra de negocio nem SQL.
 *
 * Continua sendo Swing puro (JFrame, JTable, JButton...). Nenhuma biblioteca externa.
 *
 * Decisoes de design:
 *  - Fundo escuro com um unico destaque (vermelho Netflix). O vermelho so aparece onde ha acao
 *    importante (botao principal, selecao, foco), assim o olho sabe para onde ir.
 *  - Contraste alto entre texto e fundo (legibilidade) e foco do teclado sempre visivel.
 *  - Sem animacoes: sao telas de trabalho, usadas muitas vezes; resposta imediata e melhor.
 */
public final class Tema {

    // ---------- cores ----------
    public static final Color FUNDO = new Color(0x141414);          // fundo das janelas
    public static final Color PAINEL = new Color(0x1c1c1c);         // faixas e cartoes
    public static final Color CAMPO = new Color(0x262626);          // fundo de campos e tabela
    public static final Color SUPERFICIE = new Color(0x2e2e2e);     // botoes secundarios
    public static final Color SUPERFICIE_HOVER = new Color(0x3b3b3b);
    public static final Color BORDA = new Color(0x3d3d3d);
    public static final Color TEXTO = new Color(0xf2f2f2);
    public static final Color TEXTO_SUAVE = new Color(0xa6a6a6);    // rotulos e textos de apoio
    public static final Color VERMELHO = new Color(0xe50914);       // vermelho da Netflix
    public static final Color VERMELHO_HOVER = new Color(0xf6313a);
    public static final Color VERMELHO_PRESSIONADO = new Color(0xb20710);
    public static final Color LINHA_ALTERNADA = new Color(0x2b2b2b);

    // ---------- fontes ----------
    public static final Font FONTE = escolherFonte(Font.PLAIN, 14);
    public static final Font FONTE_NEGRITO = FONTE.deriveFont(Font.BOLD);
    public static final Font FONTE_TITULO = FONTE.deriveFont(Font.BOLD, 24f);
    public static final Font FONTE_PEQUENA = FONTE.deriveFont(12f);

    private Tema() {
    }

    /** Usa a fonte do sistema se existir (Segoe UI no Windows); senao, a fonte padrao do Java. */
    private static Font escolherFonte(int estilo, int tamanho) {
        String[] preferidas = {"Segoe UI", "SF Pro Text", "Helvetica Neue", "Ubuntu", "Noto Sans"};
        java.util.Set<String> instaladas = new java.util.HashSet<>(
                java.util.Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String nome : preferidas) {
            if (instaladas.contains(nome)) {
                return new Font(nome, estilo, tamanho);
            }
        }
        return new Font(Font.SANS_SERIF, estilo, tamanho);
    }

    // =====================================================================================
    // Look and Feel: chamado UMA vez no Main, antes de criar qualquer janela
    // =====================================================================================

    /**
     * Liga o Nimbus (aparencia moderna que ja vem no Java) e troca as cores padrao por um tema escuro.
     * O UIManager guarda as "configuracoes globais" do Swing; chaves como "control" e "text"
     * mudam a cor de todos os componentes de uma vez, inclusive dos JOptionPane (as mensagens).
     */
    public static void aplicar() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // Sem Nimbus o sistema continua funcionando com a aparencia padrao.
        }
        UIManager.put("control", PAINEL);
        UIManager.put("info", CAMPO);
        UIManager.put("nimbusBase", new Color(0x2a2a2a));
        UIManager.put("nimbusBlueGrey", new Color(0x3a3a3a));
        UIManager.put("nimbusLightBackground", CAMPO);
        UIManager.put("nimbusFocus", VERMELHO);
        UIManager.put("nimbusSelectionBackground", VERMELHO);
        UIManager.put("nimbusSelectedText", Color.WHITE);
        UIManager.put("text", TEXTO);
        UIManager.put("nimbusBorder", BORDA);
        UIManager.put("defaultFont", FONTE);
        UIManager.put("Panel.background", PAINEL);
        UIManager.put("OptionPane.background", PAINEL);
        UIManager.put("OptionPane.messageForeground", TEXTO);
        UIManager.put("OptionPane.messageFont", FONTE);
        UIManager.put("OptionPane.buttonFont", FONTE);
        UIManager.put("ComboBox.background", CAMPO);
        UIManager.put("ComboBox.foreground", TEXTO);
        UIManager.put("ComboBox.selectionBackground", VERMELHO);
        UIManager.put("ComboBox.selectionForeground", Color.WHITE);
    }

    // =====================================================================================
    // Botoes
    // =====================================================================================

    /** Tipos de botao: o principal (vermelho) chama a acao mais importante da tela. */
    public enum TipoBotao { PRINCIPAL, SECUNDARIO, PERIGO, FANTASMA }

    /**
     * Botao com cantos arredondados desenhado por nos. Ele muda de cor ao passar o mouse (hover) e
     * ao ser pressionado, e mostra um anel quando recebe o foco do teclado (acessibilidade: quem
     * navega com Tab precisa ver onde esta).
     */
    public static final class Botao extends JButton {
        private TipoBotao tipo;

        /** Troca o tipo (cor) do botao; usado nos botoes "Visual | Tabela" para marcar o escolhido. */
        public void setTipo(TipoBotao novo) {
            tipo = novo;
            repaint();
        }

        public Botao(String texto, TipoBotao tipo) {
            super(texto);
            this.tipo = tipo;
            setFont(FONTE_NEGRITO);
            setForeground(tipo == TipoBotao.PERIGO ? new Color(0xff6b73) : TEXTO);
            setContentAreaFilled(false); // quem pinta o fundo somos nos (paintComponent abaixo)
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setRolloverEnabled(true);
            setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
            setBorder(BorderFactory.createEmptyBorder(9, 20, 9, 20));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            boolean pressionado = getModel().isPressed();
            boolean sobre = getModel().isRollover();
            int w = getWidth(), h = getHeight(), arco = 10;

            Color fundo;
            switch (tipo) {
                case PRINCIPAL:
                    fundo = pressionado ? VERMELHO_PRESSIONADO : sobre ? VERMELHO_HOVER : VERMELHO;
                    break;
                case SECUNDARIO:
                    fundo = pressionado ? BORDA : sobre ? SUPERFICIE_HOVER : SUPERFICIE;
                    break;
                case PERIGO:
                    fundo = pressionado ? new Color(0x5a1216) : sobre ? new Color(0x3d1a1d) : new Color(0, 0, 0, 0);
                    break;
                default: // FANTASMA
                    fundo = pressionado ? BORDA : sobre ? SUPERFICIE : new Color(0, 0, 0, 0);
                    break;
            }
            g2.setColor(fundo);
            g2.fillRoundRect(0, 0, w, h, arco, arco);

            if (tipo == TipoBotao.PERIGO) { // contorno vermelho
                g2.setColor(new Color(0xa3262d));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, w - 1, h - 1, arco, arco);
            }
            if (isFocusOwner()) { // anel de foco do teclado
                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, arco, arco);
            }
            g2.dispose();
            super.paintComponent(g); // desenha o texto por cima
        }
    }

    // =====================================================================================
    // Campos de formulario
    // =====================================================================================

    private static Border bordaCampo(boolean comFoco) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(comFoco ? VERMELHO : BORDA, 1, true),
                BorderFactory.createEmptyBorder(7, 10, 7, 10));
    }

    /** Campo de texto escuro; a borda fica vermelha quando o campo esta ativo (foco). */
    public static void estilizarCampo(JTextComponent campo) {
        campo.setFont(FONTE);
        // Campo que o usuario nao edita (ex.: descricao automatica do plano) fica mais escuro.
        campo.setBackground(campo.isEditable() ? CAMPO : PAINEL);
        campo.setForeground(campo.isEditable() ? TEXTO : TEXTO_SUAVE);
        campo.setCaretColor(TEXTO);
        campo.setSelectionColor(VERMELHO);
        campo.setSelectedTextColor(Color.WHITE);
        campo.setDisabledTextColor(TEXTO_SUAVE);
        campo.setBorder(bordaCampo(false));
        campo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                campo.setBorder(bordaCampo(true));
            }

            @Override
            public void focusLost(FocusEvent e) {
                campo.setBorder(bordaCampo(false));
            }
        });
    }

    /**
     * Combo escuro e plano. O Nimbus desenha o combo com um degrade cinza que nao combina com o tema, entao
     * trocamos o "UI" (a classe que desenha o componente) por um BasicComboBoxUI com setinha e fundo lisos.
     * A lista que abre tambem ganha as cores do tema (item sob o mouse em vermelho).
     */
    public static void estilizarCombo(JComboBox<?> combo) {
        combo.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                BasicArrowButton seta = new BasicArrowButton(BasicArrowButton.SOUTH, CAMPO, CAMPO, TEXTO_SUAVE, CAMPO);
                seta.setBorder(BorderFactory.createEmptyBorder());
                return seta;
            }

            @Override
            public void paintCurrentValueBackground(Graphics g, Rectangle area, boolean temFoco) {
                g.setColor(CAMPO);
                g.fillRect(area.x, area.y, area.width, area.height);
            }
        });
        combo.setFont(FONTE);
        combo.setBackground(CAMPO);
        combo.setForeground(TEXTO);
        combo.setBorder(BorderFactory.createLineBorder(BORDA, 1, true));
        combo.setPreferredSize(new Dimension(combo.getPreferredSize().width, 38));
        combo.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        combo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object valor, int indice,
                                                          boolean selecionado, boolean foco) {
                super.getListCellRendererComponent(lista, valor, indice, selecionado, false);
                setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
                setForeground(selecionado ? Color.WHITE : TEXTO);
                setBackground(selecionado ? VERMELHO : CAMPO);
                return this;
            }
        });
        combo.addFocusListener(new FocusAdapter() { // borda vermelha quando o combo esta ativo (teclado)
            @Override
            public void focusGained(FocusEvent e) {
                combo.setBorder(BorderFactory.createLineBorder(VERMELHO, 1, true));
            }

            @Override
            public void focusLost(FocusEvent e) {
                combo.setBorder(BorderFactory.createLineBorder(BORDA, 1, true));
            }
        });
        // Borda e fundo da lista que abre (senao aparece o cinza do Nimbus nas bordas)
        Object popup = combo.getAccessibleContext().getAccessibleChild(0);
        if (popup instanceof JComponent) {
            ((JComponent) popup).setBorder(BorderFactory.createLineBorder(BORDA));
            ((JComponent) popup).setBackground(CAMPO);
        }
    }

    /** Aplica o estilo certo conforme o tipo do componente (usado pelas telas de cadastro). */
    public static void estilizarComponente(JComponent c) {
        if (c instanceof JTextComponent) {
            estilizarCampo((JTextComponent) c);
        } else if (c instanceof JComboBox) {
            estilizarCombo((JComboBox<?>) c);
        }
    }

    // =====================================================================================
    // Textos e paineis
    // =====================================================================================

    /** Rotulo pequeno e discreto que fica em cima do campo. */
    public static JLabel rotulo(String texto) {
        JLabel r = new JLabel(texto);
        r.setFont(FONTE_PEQUENA);
        r.setForeground(TEXTO_SUAVE);
        return r;
    }

    /**
     * Faixa de titulo no topo da janela, no estilo dos destaques do app: degrade vinho -> cinza escuro,
     * a marca NETFLIX pequena em vermelho, o titulo grande, uma linha de apoio e o filete vermelho embaixo.
     */
    public static JPanel cabecalho(String titulo, String apoio) {
        JPanel p = new JPanel(new java.awt.BorderLayout(0, 2)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new java.awt.GradientPaint(0, 0, new Color(0x4a0b11), getWidth() * 0.7f, getHeight(), PAINEL));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 3, 0, VERMELHO),
                BorderFactory.createEmptyBorder(14, 24, 14, 24)));

        JLabel marca = new JLabel("NETFLIX");
        marca.setFont(FONTE_PEQUENA.deriveFont(Font.BOLD, 12f));
        marca.setForeground(VERMELHO);
        JLabel t = new JLabel(titulo);
        t.setFont(FONTE_TITULO.deriveFont(28f));
        t.setForeground(TEXTO);
        JLabel a = new JLabel(apoio);
        a.setFont(FONTE);
        a.setForeground(TEXTO_SUAVE);

        JPanel texto = new JPanel(new java.awt.BorderLayout(0, 2));
        texto.setOpaque(false);
        texto.add(t, java.awt.BorderLayout.CENTER);
        texto.add(a, java.awt.BorderLayout.SOUTH);
        p.add(marca, java.awt.BorderLayout.NORTH);
        p.add(texto, java.awt.BorderLayout.CENTER);
        return p;
    }

    /** "Chip" pequeno e arredondado com um rotulo e um valor (usado nos totais do relatorio). */
    public static JPanel chip(String rotulo, String valor) {
        JPanel c = new JPanel(new java.awt.BorderLayout(0, 2)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(SUPERFICIE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 12, 12);
                g2.dispose();
            }
        };
        c.setOpaque(false);
        c.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        JLabel r = new JLabel(rotulo);
        r.setFont(FONTE_PEQUENA);
        r.setForeground(TEXTO_SUAVE);
        JLabel v = new JLabel(valor);
        v.setFont(FONTE_TITULO.deriveFont(22f));
        v.setForeground(TEXTO);
        c.add(r, java.awt.BorderLayout.NORTH);
        c.add(v, java.awt.BorderLayout.CENTER);
        return c;
    }

    /** Pinta o fundo de uma janela e do seu painel de conteudo com a cor do tema. */
    public static void fundoDaJanela(javax.swing.JFrame janela) {
        janela.getContentPane().setBackground(FUNDO);
    }

    // =====================================================================================
    // Tabela
    // =====================================================================================

    /**
     * Estilo da tabela: linhas mais altas, listras alternadas para facilitar a leitura, linha selecionada
     * em vermelho e cabecalho em destaque. O JTable e o DefaultTableModel continuam os mesmos;
     * so muda o "renderer" (o objeto que desenha cada celula).
     */
    public static void estilizarTabela(JTable tabela) {
        tabela.setFont(FONTE);
        tabela.setRowHeight(32);
        tabela.setShowGrid(false);
        tabela.setIntercellSpacing(new Dimension(0, 0));
        tabela.setFillsViewportHeight(true);
        tabela.setBackground(CAMPO);
        tabela.setForeground(TEXTO);
        tabela.setSelectionBackground(VERMELHO);
        tabela.setSelectionForeground(Color.WHITE);

        tabela.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean selecionada,
                                                           boolean foco, int linha, int coluna) {
                super.getTableCellRendererComponent(t, valor, selecionada, false, linha, coluna);
                setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                setForeground(selecionada ? Color.WHITE : TEXTO);
                setBackground(selecionada ? VERMELHO : (linha % 2 == 0 ? CAMPO : LINHA_ALTERNADA));
                setToolTipText(valor == null ? null : valor.toString()); // passar o mouse mostra o texto inteiro
                return this;
            }
        });

        JTableHeader cab = tabela.getTableHeader();
        cab.setReorderingAllowed(false);
        cab.setPreferredSize(new Dimension(cab.getPreferredSize().width, 36));
        cab.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor, boolean selecionada,
                                                           boolean foco, int linha, int coluna) {
                super.getTableCellRendererComponent(t, valor, false, false, linha, coluna);
                setFont(FONTE_PEQUENA.deriveFont(Font.BOLD));
                setForeground(TEXTO_SUAVE);
                setBackground(PAINEL);
                setHorizontalAlignment(SwingConstants.LEFT);
                setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 1, 0, BORDA),
                        BorderFactory.createEmptyBorder(0, 12, 0, 12)));
                return this;
            }
        });
    }

    /** Rolagem sem a borda cinza padrao, com o fundo da tabela e barras finas no tema. */
    public static JScrollPane rolagem(JTable tabela) {
        JScrollPane r = new JScrollPane(tabela);
        r.setBorder(BorderFactory.createLineBorder(BORDA));
        r.getViewport().setBackground(CAMPO);
        r.getVerticalScrollBar().setUI(new BarraFina());
        r.getHorizontalScrollBar().setUI(new BarraFina());
        r.getVerticalScrollBar().setPreferredSize(new Dimension(12, 0));
        r.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 12));
        JPanel canto = new JPanel(); // quadradinho no canto, junto ao cabecalho da tabela
        canto.setBackground(PAINEL);
        r.setCorner(JScrollPane.UPPER_RIGHT_CORNER, canto);
        return r;
    }

    /** Rolagem para qualquer painel (usada nas visoes): so vertical, fundo escuro e barra fina. */
    public static JScrollPane rolagemSimples(java.awt.Component conteudo) {
        JScrollPane r = new JScrollPane(conteudo, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        r.setBorder(BorderFactory.createLineBorder(BORDA));
        r.getViewport().setBackground(CAMPO);
        r.getVerticalScrollBar().setUI(new BarraFina());
        r.getVerticalScrollBar().setPreferredSize(new Dimension(12, 0));
        r.getVerticalScrollBar().setUnitIncrement(24);
        return r;
    }

    /** Rolagem so na horizontal e transparente (fileiras de capas, como os carrosseis do app). */
    public static JScrollPane rolagemHorizontal(java.awt.Component conteudo) {
        JScrollPane r = new JScrollPane(conteudo, JScrollPane.VERTICAL_SCROLLBAR_NEVER,
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        r.setBorder(BorderFactory.createEmptyBorder());
        r.setOpaque(false);
        r.setViewportBorder(null);
        r.getViewport().setOpaque(false);
        r.getHorizontalScrollBar().setUI(new BarraFina());
        r.getHorizontalScrollBar().setPreferredSize(new Dimension(0, 10));
        r.getHorizontalScrollBar().setUnitIncrement(40);
        return r;
    }

    /** Barra de rolagem lisa: so um trilho escuro e um "polegar" arredondado, sem as setas do Nimbus. */
    private static final class BarraFina extends BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            thumbColor = SUPERFICIE_HOVER;
            trackColor = CAMPO;
        }

        @Override
        protected JButton createDecreaseButton(int orientacao) {
            return botaoVazio();
        }

        @Override
        protected JButton createIncreaseButton(int orientacao) {
            return botaoVazio();
        }

        private JButton botaoVazio() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle area) {
            g.setColor(trackColor);
            g.fillRect(area.x, area.y, area.width, area.height);
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle area) {
            if (area.isEmpty() || !scrollbar.isEnabled()) {
                return;
            }
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(isThumbRollover() ? BORDA.brighter() : thumbColor);
            g2.fillRoundRect(area.x + 2, area.y + 2, area.width - 4, area.height - 4, 8, 8);
            g2.dispose();
        }
    }

    /**
     * Ajusta a largura de cada coluna ao que ela tem de mais largo (titulo ou conteudo), para o texto
     * nao ficar cortado ("Uma tela, qual..."). Chamado depois de carregar os dados. AUTO_RESIZE_ALL_COLUMNS
     * reparte o espaco que sobra (ou falta) proporcionalmente entre todas as colunas.
     */
    public static void ajustarColunas(JTable tabela) {
        FontMetrics corpo = tabela.getFontMetrics(tabela.getFont());
        FontMetrics titulo = tabela.getFontMetrics(FONTE_PEQUENA.deriveFont(Font.BOLD));
        for (int c = 0; c < tabela.getColumnCount(); c++) {
            int maior = titulo.stringWidth(String.valueOf(tabela.getColumnName(c))) + 30;
            for (int l = 0; l < tabela.getRowCount(); l++) {
                Object valor = tabela.getValueAt(l, c);
                maior = Math.max(maior, corpo.stringWidth(valor == null ? "" : valor.toString()) + 30);
            }
            tabela.getColumnModel().getColumn(c).setPreferredWidth(Math.min(maior, 340));
            tabela.getColumnModel().getColumn(c).setMinWidth(Math.min(maior, 56)); // colunas curtas (ID) nao viram "..."
        }
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
    }
}
