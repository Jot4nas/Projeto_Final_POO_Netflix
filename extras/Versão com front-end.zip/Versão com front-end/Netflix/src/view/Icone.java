package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Path2D;

/**
 * Icones do menu, DESENHADOS EM CODIGO (nenhuma imagem externa).
 *
 * Cada icone e feito de linhas e formas simples numa grade de 24 x 24. O metodo desenhar()
 * escala essa grade para o tamanho pedido, entao o mesmo icone serve para tamanho pequeno
 * (barra lateral) e grande (cartoes), sem perder qualidade.
 */
public enum Icone {
    CASA, PLANOS, CONTAS, PERFIS, TITULOS, HISTORICO, RELATORIO, RESTAURAR;

    /** Desenha o icone com o canto superior esquerdo em (x, y), com lado 'tamanho' e a cor dada. */
    public void desenhar(Graphics2D g, int x, int y, int tamanho, Color cor) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g2.translate(x, y);
        g2.scale(tamanho / 24.0, tamanho / 24.0);
        g2.setColor(cor);
        g2.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        switch (this) {
            case CASA: { // telhado + paredes + porta
                Path2D telhado = new Path2D.Float();
                telhado.moveTo(3, 11);
                telhado.lineTo(12, 3);
                telhado.lineTo(21, 11);
                g2.draw(telhado);
                Path2D paredes = new Path2D.Float();
                paredes.moveTo(5, 10);
                paredes.lineTo(5, 20);
                paredes.lineTo(19, 20);
                paredes.lineTo(19, 10);
                g2.draw(paredes);
                g2.drawRect(10, 14, 4, 6);
                break;
            }
            case PLANOS: // cartao (assinatura)
                g2.drawRoundRect(2, 5, 20, 14, 4, 4);
                g2.drawLine(2, 10, 22, 10);
                g2.drawLine(5, 15, 10, 15);
                break;
            case CONTAS: { // envelope (o e-mail identifica a conta)
                g2.drawRoundRect(2, 5, 20, 14, 4, 4);
                Path2D aba = new Path2D.Float();
                aba.moveTo(3, 7);
                aba.lineTo(12, 14);
                aba.lineTo(21, 7);
                g2.draw(aba);
                break;
            }
            case PERFIS: // pessoa: cabeca e ombros
                g2.drawOval(8, 3, 8, 8);
                g2.drawArc(4, 13, 16, 14, 0, 180);
                break;
            case TITULOS: // tira de filme
                g2.drawRoundRect(3, 4, 18, 16, 3, 3);
                g2.drawLine(8, 4, 8, 20);
                g2.drawLine(16, 4, 16, 20);
                g2.drawLine(3, 9, 8, 9);
                g2.drawLine(3, 15, 8, 15);
                g2.drawLine(16, 9, 21, 9);
                g2.drawLine(16, 15, 21, 15);
                break;
            case HISTORICO: { // relogio
                g2.drawOval(3, 3, 18, 18);
                Path2D ponteiros = new Path2D.Float();
                ponteiros.moveTo(12, 7);
                ponteiros.lineTo(12, 12);
                ponteiros.lineTo(16, 14);
                g2.draw(ponteiros);
                break;
            }
            case RELATORIO: // grafico de barras
                g2.fillRoundRect(4, 12, 4, 8, 2, 2);
                g2.fillRoundRect(10, 5, 4, 15, 2, 2);
                g2.fillRoundRect(16, 9, 4, 11, 2, 2);
                break;
            default: { // RESTAURAR: seta circular
                g2.drawArc(4, 4, 16, 16, 60, 270);
                Path2D ponta = new Path2D.Float();
                ponta.moveTo(16.5, 1.5);
                ponta.lineTo(17.5, 6.5);
                ponta.lineTo(12.5, 7);
                g2.draw(ponta);
                break;
            }
        }
        g2.dispose();
    }
}
