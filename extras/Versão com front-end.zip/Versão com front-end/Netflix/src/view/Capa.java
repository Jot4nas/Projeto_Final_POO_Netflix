package view;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

/**
 * Capa (poster) de um titulo. Se existir um arquivo "capas/NOME DO TITULO.jpg" (ou .png) ao lado do
 * programa, a imagem e usada; se nao existir, a capa e DESENHADA em codigo: degrade colorido com o
 * nome do titulo (a cor sai do nome, entao um titulo sempre tem a mesma cor).
 *
 * Assim o sistema funciona em qualquer computador, com ou sem as imagens.
 */
public final class Capa {

    private static final Color[] CORES = {
        new Color(0x8a1a22), new Color(0x1a4a94), new Color(0x6a2090), new Color(0x14766e),
        new Color(0x9a6612), new Color(0x2f6b2f), new Color(0x8a2a5a), new Color(0x3a4a8a)};

    // Guarda as imagens ja lidas (null = nao existe), para nao reler o disco a cada desenho
    private static final Map<String, BufferedImage> CACHE = new HashMap<>();

    private Capa() {
    }

    public static Color cor(String nome) {
        return CORES[Math.abs(nome.hashCode()) % CORES.length];
    }

    private static BufferedImage imagem(String nome) {
        if (!CACHE.containsKey(nome)) {
            BufferedImage img = null;
            for (String extensao : new String[]{".jpg", ".png"}) {
                File arquivo = new File("capas", nome + extensao);
                if (arquivo.isFile()) {
                    try {
                        img = ImageIO.read(arquivo);
                    } catch (java.io.IOException e) {
                        img = null; // arquivo estragado: usa a capa desenhada
                    }
                    break;
                }
            }
            CACHE.put(nome, img);
        }
        return CACHE.get(nome);
    }

    /** Desenha a capa do titulo no retangulo (x, y, w, h) com cantos arredondados. */
    public static void desenhar(Graphics2D g, String nome, int x, int y, int w, int h, int arco) {
        desenhar(g, nome, x, y, w, h, arco, true);
    }

    /** Igual ao anterior; comTexto = false desenha so o fundo colorido (usado atras do texto do destaque). */
    public static void desenhar(Graphics2D g, String nome, int x, int y, int w, int h, int arco, boolean comTexto) {
        Graphics2D g2 = (Graphics2D) g.create();
        Shape forma = new RoundRectangle2D.Float(x, y, w, h, arco, arco);
        g2.clip(forma);
        BufferedImage img = imagem(nome);
        if (img != null) {
            // "cover": preenche o retangulo inteiro cortando o que sobra
            double escala = Math.max((double) w / img.getWidth(), (double) h / img.getHeight());
            int lw = (int) Math.ceil(img.getWidth() * escala), lh = (int) Math.ceil(img.getHeight() * escala);
            g2.drawImage(img, x + (w - lw) / 2, y + (h - lh) / 2, lw, lh, null);
        } else {
            Color c = cor(nome);
            g2.setPaint(new GradientPaint(x, y, c.brighter(), x + w, y + h, c.darker().darker()));
            g2.fillRect(x, y, w, h);
            if (!comTexto) {
                g2.dispose();
                return;
            }
            // "N" vermelho no canto, como nos posters do app
            g2.setColor(Tema.VERMELHO);
            g2.setFont(Tema.FONTE_TITULO.deriveFont(Font.BOLD, Math.max(14f, h / 11f)));
            g2.drawString("N", x + 8, y + 8 + g2.getFontMetrics().getAscent() - 4);
            // nome do titulo no meio, quebrado em linhas
            g2.setColor(Color.WHITE);
            g2.setFont(Tema.FONTE_TITULO.deriveFont(Font.BOLD, Math.max(13f, Math.min(w, h) / 7f)));
            FontMetrics fm = g2.getFontMetrics();
            java.util.List<String> linhas = quebrar(nome, fm, w - 24);
            int topo = y + (h - linhas.size() * fm.getHeight()) / 2 + fm.getAscent();
            for (int i = 0; i < linhas.size(); i++) {
                g2.drawString(linhas.get(i), x + (w - fm.stringWidth(linhas.get(i))) / 2, topo + i * fm.getHeight());
            }
        }
        g2.dispose();
    }

    /** Desenha a imagem "capas/NOME.png|jpg" no retangulo (cortando como "cover"). Devolve false se a imagem nao existe. */
    public static boolean desenharSeExistir(Graphics2D g, String nome, int x, int y, int w, int h, int arco) {
        BufferedImage img = imagem(nome);
        if (img == null) {
            return false;
        }
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g2.clip(new RoundRectangle2D.Float(x, y, w, h, arco, arco));
        double escala = Math.max((double) w / img.getWidth(), (double) h / img.getHeight());
        int lw = (int) Math.ceil(img.getWidth() * escala), lh = (int) Math.ceil(img.getHeight() * escala);
        g2.drawImage(img, x + (w - lw) / 2, y + (h - lh) / 2, lw, lh, null);
        g2.dispose();
        return true;
    }

    private static java.util.List<String> quebrar(String texto, FontMetrics fm, int largura) {
        java.util.List<String> linhas = new java.util.ArrayList<>();
        String atual = "";
        for (String palavra : texto.split(" ")) {
            String tentativa = atual.isEmpty() ? palavra : atual + " " + palavra;
            if (fm.stringWidth(tentativa) <= largura || atual.isEmpty()) {
                atual = tentativa;
            } else {
                linhas.add(atual);
                atual = palavra;
            }
        }
        if (!atual.isEmpty()) {
            linhas.add(atual);
        }
        return linhas;
    }
}
