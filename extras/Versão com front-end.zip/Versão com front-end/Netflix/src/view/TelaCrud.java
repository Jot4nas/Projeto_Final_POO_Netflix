package view;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * Tela base de CRUD (TEMPLATE METHOD): monta o layout padrao (formulario em cima,
 * tabela no meio, botoes embaixo) e liga os botoes. Cada tela filha so informa
 * QUAIS campos tem e CHAMA O SEU CONTROLLER nos metodos abstratos.
 * Heranca evita repetir o mesmo codigo de layout nas 5 telas.
 *
 * Regra do MVC: esta classe NAO tem regra de negocio nem acesso a banco.
 * Ela so le o que o usuario digitou, chama o Controller e mostra a mensagem devolvida.
 *
 * Convencao: as colunas da tabela sao [ID] + [um campo do formulario por coluna,
 * na mesma ordem]. Assim, ao clicar numa linha, copiamos as celulas para os campos.
 * Colunas EXTRAS so de exibicao (ex.: Conta e Plano no Historico) ficam no FIM da tabela:
 * como nao tem campo no formulario, sao ignoradas ao copiar a linha.
 */
public abstract class TelaCrud extends JFrame {

    /**
     * DefaultTableModel = a "planilha em memoria" que o JTable exibe.
     * O JTable apenas DESENHA o que esta no modelo. Para mudar a tabela, mudamos
     * o modelo: setRowCount(0) apaga as linhas e addRow(Object[]) adiciona uma
     * (cada posicao do vetor = uma coluna).
     */
    protected final DefaultTableModel modelo;
    protected final JTable tabela;

    private final Map<String, JComponent> campos = new LinkedHashMap<>(); // rotulo -> componente (mantem a ordem)
    // Formulario em 2 colunas: cada campo ocupa uma celula, com o rotulo em cima (ver adicionarCampo).
    private final JPanel painelForm = new JPanel(new GridLayout(0, 2, 20, 14));

    // true enquanto o programa (e nao o usuario) muda a selecao da tabela; evita que o
    // formulario seja sobrescrito com os valores da linha quando recarregamos a tabela.
    private boolean recarregandoTabela = false;

    private Visao visao; // forma visual opcional de mostrar o modelo (ver criarVisao)

    protected TelaCrud(String titulo, String[] colunas) {
        super(titulo);

        // Modelo com os nomes das colunas e 0 linhas. Sobrescrevemos isCellEditable
        // para a tabela ser so de leitura (a edicao e feita pelo formulario).
        modelo = new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int linha, int coluna) {
                return false;
            }
        };
        tabela = new JTable(modelo);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    // ---------- metodos que cada tela filha implementa ----------

    /** Busca a lista no Controller e preenche o 'modelo' (addRow para cada objeto). */
    protected abstract void carregarTabela();

    /** Le os campos, chama controller.inserir(...) e devolve a mensagem de resultado. */
    protected abstract String inserir();

    /** Idem para atualizar; 'id' e o ID da linha selecionada na tabela. */
    protected abstract String atualizar(String id);

    /** Idem para eliminar. */
    protected abstract String eliminar(String id);

    /** Gancho opcional: a tela filha pode acrescentar botoes proprios ao lado de Inserir, Atualizar, Remover e Limpar. */
    protected void acrescentarBotoes(JPanel painelBotoes) {
    }

    /** Gancho opcional: preenche os combos de chave estrangeira (ex.: lista de planos). */
    protected void carregarCombos() {
    }

    /** Gancho opcional: valores iniciais dos campos (ex.: data de hoje). */
    protected void definirPadroes() {
    }

    // ---------- campos do formulario ----------

    protected void adicionarCampo(String rotulo, JComponent componente) {
        campos.put(rotulo, componente);
        Tema.estilizarComponente(componente); // cores, fonte e borda do tema

        // Uma celula do formulario: rotulo pequeno em cima e o campo embaixo.
        JPanel celula = new JPanel(new BorderLayout(0, 5));
        celula.setOpaque(false);
        celula.add(Tema.rotulo(rotulo), BorderLayout.NORTH);
        celula.add(componente, BorderLayout.CENTER);
        painelForm.add(celula);
    }

    /** Troca os itens de um combo pelos itens da lista (usado nos combos de FK). */
    protected void preencherCombo(JComboBox<String> combo, List<String> opcoes) {
        combo.removeAllItems();
        for (String opcao : opcoes) {
            combo.addItem(opcao);
        }
    }

    /** Le um campo como texto (JTextField ou JComboBox). A View entrega tudo como String ao Controller. */
    protected String valor(String rotulo) {
        JComponent c = campos.get(rotulo);
        if (c instanceof JComboBox) {
            Object item = ((JComboBox<?>) c).getSelectedItem();
            return item == null ? "" : item.toString();
        }
        return ((JTextField) c).getText();
    }

    /** Coloca um texto no campo pelo rotulo (sobrecarga do metodo abaixo). */
    protected void definirValor(String rotulo, String texto) {
        definirValor(campos.get(rotulo), texto);
    }

    private void definirValor(JComponent c, String texto) {
        if (c instanceof JComboBox) {
            // Seleciona no combo o item igual ao texto (ex.: "3 - Premium").
            ((JComboBox<?>) c).setSelectedItem(texto);
        } else {
            ((JTextField) c).setText(texto);
        }
    }

    // ---------- montagem da tela ----------

    /**
     * Deve ser chamado no FINAL do construtor da tela filha (depois dos campos
     * criados). Nao fazemos isso no construtor da base porque os atributos da filha
     * (como o controller) ainda nao existiriam nesse momento.
     */
    protected void iniciar() {
        painelForm.setOpaque(false);
        painelForm.setBorder(BorderFactory.createEmptyBorder(18, 24, 6, 24));
        // Muitos campos? Usa 3 colunas para sobrar mais espaco para a tabela.
        ((GridLayout) painelForm.getLayout()).setColumns(campos.size() > 6 ? 3 : 2);

        // O botao principal (vermelho) e "Inserir"; "Remover" tem contorno de alerta por ser destrutivo.
        JButton btnInserir = new Tema.Botao("Inserir", Tema.TipoBotao.PRINCIPAL);
        JButton btnAtualizar = new Tema.Botao("Atualizar", Tema.TipoBotao.SECUNDARIO);
        JButton btnEliminar = new Tema.Botao("Remover", Tema.TipoBotao.PERIGO);
        JButton btnLimpar = new Tema.Botao("Limpar", Tema.TipoBotao.FANTASMA);

        /*
         * EVENTOS DOS BOTOES (ActionListener):
         * addActionListener registra "o que fazer quando o botao for clicado".
         * "e -> ..." e uma LAMBDA, forma curta de escrever:
         *     new ActionListener() { public void actionPerformed(ActionEvent e) { ... } }
         * O clique NAO tem logica: chama o metodo da tela filha (que chama o
         * Controller) e mostra a mensagem que voltou.
         */
        btnInserir.addActionListener(e -> mostrarResultado(inserir()));
        btnAtualizar.addActionListener(e -> mostrarResultado(atualizar(idSelecionado())));
        btnEliminar.addActionListener(e -> confirmarEliminar());
        btnLimpar.addActionListener(e -> limpar());

        // Clicar numa linha da tabela copia os valores dela para o formulario (para editar).
        tabela.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && !recarregandoTabela) {
                if (tabela.getSelectedRow() >= 0) {
                    aoSelecionar();
                }
                if (visao != null) {
                    visao.marcar(tabela.getSelectedRow()); // destaca o desenho do registro escolhido
                }
            }
        });

        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        painelBotoes.setOpaque(false);
        painelBotoes.setBorder(BorderFactory.createEmptyBorder(8, 24, 14, 24));
        painelBotoes.add(btnInserir);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnEliminar);
        painelBotoes.add(btnLimpar);
        acrescentarBotoes(painelBotoes);

        Tema.estilizarTabela(tabela);
        visao = criarVisao(new AcoesDaTela()); // null nas telas sem visao (ex.: Titulos)
        Tema.fundoDaJanela(this);

        if (visao == null) {
            // Topo da janela: faixa de titulo, formulario e botoes, um embaixo do outro.
            JPanel topo = new JPanel(new BorderLayout());
            topo.setOpaque(false);
            topo.add(barraECabecalho("Clique em uma linha da tabela para editar o registro."), BorderLayout.NORTH);
            JPanel formEBotoes = new JPanel(new BorderLayout());
            formEBotoes.setOpaque(false);
            formEBotoes.add(painelForm, BorderLayout.CENTER);
            formEBotoes.add(painelBotoes, BorderLayout.SOUTH);
            topo.add(formEBotoes, BorderLayout.CENTER);

            // Tabela (JScrollPane da a barra de rolagem), com margem em volta.
            JPanel areaTabela = new JPanel(new BorderLayout());
            areaTabela.setOpaque(false);
            areaTabela.setBorder(BorderFactory.createEmptyBorder(4, 24, 24, 24));
            areaTabela.add(Tema.rolagem(tabela), BorderLayout.CENTER);
            add(topo, BorderLayout.NORTH);
            add(areaTabela, BorderLayout.CENTER);
        } else {
            montarComVisao(painelBotoes);
        }

        // tamanho: ate 1160 x 760, mas nunca maior que a tela (notebooks pequenos)
        java.awt.Dimension tela = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(Math.min(1160, tela.width - 60), Math.min(760, tela.height - 80));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE); // so ha uma janela por vez (o Navegador troca); fechar encerra o programa

        recarregar(true);
    }

    /**
     * Layout com visao: a esquerda a lista (botoes "Visual" e "Tabela" alternam entre os desenhos e a
     * JTable, que usam o MESMO modelo) e a direita o formulario de detalhes, com os botoes embaixo.
     */
    private void montarComVisao(JPanel painelBotoes) {
        // ---- esquerda: alternador + cartas (CardLayout mostra uma de cada vez) ----
        CardLayout cartas = new CardLayout();
        JPanel conteudo = new JPanel(cartas);
        conteudo.setOpaque(false);
        conteudo.add(visao, "visual");
        conteudo.add(Tema.rolagem(tabela), "tabela");

        Tema.Botao btnVisual = new Tema.Botao("Visual", Tema.TipoBotao.PRINCIPAL);
        Tema.Botao btnTabela = new Tema.Botao("Tabela", Tema.TipoBotao.FANTASMA);
        btnVisual.addActionListener(e -> {
            cartas.show(conteudo, "visual");
            btnVisual.setTipo(Tema.TipoBotao.PRINCIPAL);
            btnTabela.setTipo(Tema.TipoBotao.FANTASMA);
        });
        btnTabela.addActionListener(e -> {
            cartas.show(conteudo, "tabela");
            btnTabela.setTipo(Tema.TipoBotao.PRINCIPAL);
            btnVisual.setTipo(Tema.TipoBotao.FANTASMA);
        });
        JPanel alternador = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        alternador.setOpaque(false);
        alternador.add(btnVisual);
        alternador.add(btnTabela);

        JPanel esquerda = new JPanel(new BorderLayout(0, 10));
        esquerda.setOpaque(false);
        esquerda.setBorder(BorderFactory.createEmptyBorder(14, 24, 20, 12));
        esquerda.add(alternador, BorderLayout.NORTH);
        esquerda.add(conteudo, BorderLayout.CENTER);

        // ---- direita: formulario de uma coluna, rolavel, e os botoes ----
        // 7 ou mais campos: 2 colunas (painel mais largo) para o formulario caber sem rolar tanto
        boolean duasColunas = campos.size() > 6;
        ((GridLayout) painelForm.getLayout()).setColumns(duasColunas ? 2 : 1);
        ((GridLayout) painelForm.getLayout()).setVgap(10);
        painelForm.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 12));
        PainelRolavel suporteForm = new PainelRolavel(new BorderLayout());
        suporteForm.add(painelForm, BorderLayout.NORTH);
        JScrollPane rolagemForm = Tema.rolagemSimples(suporteForm);
        rolagemForm.setBorder(BorderFactory.createEmptyBorder());
        rolagemForm.setViewportBorder(null);
        rolagemForm.setOpaque(false);
        rolagemForm.getViewport().setOpaque(false);

        JLabel tituloDetalhes = new JLabel("Detalhes");
        tituloDetalhes.setFont(Tema.FONTE_NEGRITO.deriveFont(16f));
        tituloDetalhes.setForeground(Tema.TEXTO);
        tituloDetalhes.setBorder(BorderFactory.createEmptyBorder(0, 4, 10, 0));

        painelBotoes.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JPanel direita = new JPanel(new BorderLayout());
        direita.setOpaque(false);
        direita.setPreferredSize(new Dimension(duasColunas ? 600 : 480, 0));
        direita.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 1, 0, 0, Tema.BORDA),
                BorderFactory.createEmptyBorder(14, 20, 20, 20)));
        direita.add(tituloDetalhes, BorderLayout.NORTH);
        direita.add(rolagemForm, BorderLayout.CENTER);
        direita.add(painelBotoes, BorderLayout.SOUTH);

        add(barraECabecalho("Clique em um item para editar o registro."), BorderLayout.NORTH);
        add(esquerda, BorderLayout.CENTER);
        add(direita, BorderLayout.EAST);
    }

    /** O que a visao pode pedir a esta tela (clique no desenho, no X ou em "novo"); sempre reaproveita a logica dos botoes. */
    private final class AcoesDaTela implements Visao.Acoes {
        @Override
        public void selecionar(int linha) {
            if (linha >= 0 && linha < modelo.getRowCount()) {
                tabela.setRowSelectionInterval(linha, linha); // dispara o listener, que preenche o formulario
            }
        }

        @Override
        public void remover(int linha) {
            selecionar(linha);
            confirmarEliminar(); // mesma pergunta "Remover o registro selecionado?" do botao Remover
        }

        @Override
        public void novo() {
            limpar();
            if (visao != null) {
                visao.marcar(-1);
            }
        }
    }

    /** Topo de toda tela de cadastro: a barra de navegacao e, embaixo, a faixa com o titulo da tela. */
    private JPanel barraECabecalho(String apoio) {
        JPanel topo = new JPanel(new BorderLayout());
        topo.setOpaque(false);
        topo.add(new BarraNavegacao(this, nomeNaBarra(), null), BorderLayout.NORTH);
        topo.add(Tema.cabecalho(getTitle(), apoio), BorderLayout.CENTER);
        return topo;
    }

    /** Nome do botao da barra que corresponde a esta tela (o titulo da janela e maior: "Histórico de Visualização"). */
    private String nomeNaBarra() {
        return getTitle().startsWith("Hist") ? "Histórico" : getTitle();
    }

    /** Gancho opcional: devolve a visao visual da tela (ou null para mostrar so a tabela). */
    protected Visao criarVisao(Visao.Acoes acoes) {
        return null;
    }

    /** Copia as celulas da linha selecionada para os campos (coluna 0 = ID, nao tem campo). */
    private void aoSelecionar() {
        int linha = tabela.getSelectedRow();
        int coluna = 1;
        for (JComponent c : campos.values()) {
            Object celula = modelo.getValueAt(linha, coluna++);
            definirValor(c, celula == null ? "" : celula.toString());
        }
    }

    /** Pede confirmacao antes de apagar; so elimina se o usuario clicar em "Sim". */
    private void confirmarEliminar() {
        if (idSelecionado().isEmpty()) { // nada selecionado: o Controller devolve o aviso, sem perguntar nada antes
            mostrarResultado(eliminar(""));
            return;
        }
        int resposta = JOptionPane.showConfirmDialog(this, "Remover o registro selecionado?",
                "Confirmação", JOptionPane.YES_NO_OPTION);
        if (resposta == JOptionPane.YES_OPTION) {
            mostrarResultado(eliminar(idSelecionado()));
        }
    }

    /**
     * Depois de toda acao: mostra a mensagem do Controller e recarrega a tabela.
     * O formulario so e limpo quando deu certo (mensagem com "sucesso"). Se deu erro,
     * o usuario mantem o que digitou e so corrige o campo errado.
     */
    private void mostrarResultado(String mensagem) {
        JOptionPane.showMessageDialog(this, mensagem);
        boolean deuCerto = mensagem != null && mensagem.contains("sucesso");
        recarregar(deuCerto);
    }

    /**
     * Busca tudo de novo no banco: combos e tabela. Se o banco estiver fora do ar,
     * o Controller lanca RuntimeException e aqui mostramos a mensagem.
     *
     * limparFormulario = false (depois de um erro): recarregar os combos os volta para o
     * primeiro item e a tabela perde a selecao, entao guardamos a escolha de cada combo e
     * a linha selecionada e restauramos tudo no fim.
     */
    private void recarregar(boolean limparFormulario) {
        Map<JComboBox<?>, Object> escolhidos = new HashMap<>();
        String idSelecionadoAntes = idSelecionado();
        if (!limparFormulario) {
            for (JComponent c : campos.values()) {
                if (c instanceof JComboBox) {
                    escolhidos.put((JComboBox<?>) c, ((JComboBox<?>) c).getSelectedItem());
                }
            }
        }

        recarregandoTabela = true;
        try {
            modelo.setRowCount(0);
            try {
                carregarCombos();
                carregarTabela();
            } catch (RuntimeException e) {
                JOptionPane.showMessageDialog(this, e.getMessage(), "Erro", JOptionPane.ERROR_MESSAGE);
            }

            Tema.ajustarColunas(tabela); // larguras conforme o conteudo
            if (visao != null) {
                visao.atualizar(); // redesenha os cartoes/avatares com as linhas novas
            }
            if (limparFormulario) {
                limpar();
            } else {
                for (Map.Entry<JComboBox<?>, Object> e : escolhidos.entrySet()) {
                    if (e.getValue() != null) {
                        e.getKey().setSelectedItem(e.getValue());
                    }
                }
                for (int linha = 0; linha < modelo.getRowCount(); linha++) {
                    if (modelo.getValueAt(linha, 0).toString().equals(idSelecionadoAntes)) {
                        tabela.setRowSelectionInterval(linha, linha);
                        break;
                    }
                }
            }
        } finally {
            recarregandoTabela = false;
        }
        if (visao != null) {
            visao.marcar(tabela.getSelectedRow());
        }
    }

    private void limpar() {
        for (JComponent c : campos.values()) {
            if (c instanceof JComboBox) {
                JComboBox<?> combo = (JComboBox<?>) c;
                if (combo.getItemCount() > 0) {
                    combo.setSelectedIndex(0);
                }
            } else {
                ((JTextField) c).setText("");
            }
        }
        tabela.clearSelection();
        definirPadroes();
    }

    /** ID (coluna 0) da linha selecionada; "" se nada estiver selecionado (o Controller avisa). */
    private String idSelecionado() {
        int linha = tabela.getSelectedRow();
        return linha < 0 ? "" : modelo.getValueAt(linha, 0).toString();
    }
}
