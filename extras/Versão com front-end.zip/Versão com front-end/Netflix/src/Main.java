import javax.swing.SwingUtilities;

import view.Tema;
import view.TelaConexao;

/**
 * PONTO DE ENTRADA do sistema (o Netflix.jar chama este main).
 * Abre a tela de conexao; depois de conectar, ela abre o menu principal.
 */
public class Main {

    public static void main(String[] args) {
        // O Swing exige que as telas sejam criadas na thread de eventos (Event Dispatch Thread).
        SwingUtilities.invokeLater(() -> {
            Tema.aplicar(); // aparencia (cores, fonte): precisa vir ANTES de criar qualquer janela
            new TelaConexao().setVisible(true);
        });
    }
}
